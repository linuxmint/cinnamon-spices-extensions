// settingsStore.js
// -*- mode: js; js-indent-level: 4; indent-tabs-mode: nil -*-

const Gio = imports.gi.Gio;
const GdkPixbuf = imports.gi.GdkPixbuf;
const Shared = imports.shared;

// ---- Exported keymaps (must use `var` for GJS module exports) ----
var DOCK_SETTINGS_KEYMAP = [
    ["dock-transparency", "transparency"],
    ["dock-color", "dockColor"],
    ["dock-chameleonic-enabled", "chameleonicEnabled"],
    ["dock-per-app-accent-enabled", "perAppAccentEnabled"],
    ["dock-border-radius", "borderRadius"],
    ["dock-icon-size", "iconSize"],
    ["dock-max-height", "dockMaxHeight"],
    ["dock-min-width", "minWidth"],
    ["dock-max-width-percent", "maxWidthPercent"],
    ["dock-zoom-enabled", "zoomEnabled"],
    ["dock-zoom-factor", "zoomFactor"],
    ["dock-auto-hide", "autoHide"],
    ["dock-hide-delay", "hideDelay"],
    ["dock-reveal-delay", "revealDelay"],
    ["dock-intellihide", "intellihide"],
    ["dock-panel-mode", "panelMode"],
    ["dock-show-tooltips", "showTooltips"],
    ["dock-show-trash", "showTrash"],
    ["dock-trash-separator", "trashSeparator"],
    ["dock-lock-launcher", "lockLauncher"],
    ["dock-scroll-switches-windows", "scrollSwitchesWindows"],
    ["dock-group-by-category", "groupByCategory"],
    ["dock-window-effect-enabled", "windowEffectEnabled"],
    ["dock-window-effect", "windowEffect"],
    ["dock-window-close-effect", "windowCloseEffect"],
    ["dock-window-effect-duration", "windowEffectDuration"]
];

var DOCKLETS_SETTINGS_KEYMAP = [
    ["docklet-media-controls-enabled", "mediaControlsEnabled"],
    ["docklet-radio-enabled", "radioEnabled"],
    ["docklet-weather-enabled", "weatherEnabled"],
    ["docklet-blank-screen-enabled", "blankScreenEnabled"],
    ["docklet-kill-window-enabled", "killWindowEnabled"],
    ["docklet-keyboard-enabled", "keyboardEnabled"]
];

var WEATHER_SETTINGS_KEYMAP = [
    ["weather-city", "city"]
];

var EFFECTS_SETTINGS_KEYMAP = [
    ["effects-bubbles-enabled", "bubblesEnabled"],
    ["effects-bubbles-intensity", "bubblesIntensity"]
];

var LAUNCHPAD_SETTINGS_KEYMAP = [
    ["launchpad-theme-mode", "themeMode"],
    ["launchpad-open-shortcut", "openShortcut"],
    ["launchpad-hotcorner-enabled", "hotcornerEnabled"],
    ["launchpad-hotcorner-position", "hotcornerPosition"],
    ["launchpad-show-dock-icon", "showDockIcon"],
    ["launchpad-use-custom-icon", "useCustomIcon"],
    ["launchpad-panel-icon", "panelIcon"],
    ["launchpad-effects-enabled", "effectsEnabled"],
    ["launchpad-frosted-glass-enabled", "frostedGlassEnabled"]
];

// ---- Internal constants (can stay `const`) ----
const DEFAULT_DOCK_SETTINGS = {
    transparency: 30,
    dockColor: "rgba(245, 255, 255, 1.0)",
    chameleonicEnabled: true,
    perAppAccentEnabled: false,
    borderRadius: 18,
    iconSize: 48,
    dockMaxHeight: 74,
    minWidth: 50,
    maxWidthPercent: 92,
    zoomEnabled: true,
    zoomFactor: 1.4,
    autoHide: false,
    hideDelay: 400,
    revealDelay: 220,
    intellihide: true,
    panelMode: false,
    showTooltips: true,
    showTrash: false,
    trashSeparator: true,
    lockLauncher: true,
    scrollSwitchesWindows: true,
    groupByCategory: true,
    windowEffectEnabled: true,
    windowEffect: "wisps",
    windowCloseEffect: "fire",
    windowEffectDuration: 900
};

const DEFAULT_DOCKLETS_SETTINGS = {
    mediaControlsEnabled: true,
    radioEnabled: true,
    weatherEnabled: true,
    blankScreenEnabled: false,
    killWindowEnabled: false,
    keyboardEnabled: false
};

// No API, no network lookups - "city" is just a plain display string the
// user types in, defaulting to Minty's own town.
const DEFAULT_WEATHER_SETTINGS = {
    city: "Chorbane, Mahdia, Tunisia"
};

const DEFAULT_EFFECTS_SETTINGS = {
    bubblesEnabled: false,
    bubblesIntensity: 1.0
};

const DEFAULT_LAUNCHPAD_SETTINGS = {
    themeMode: "dark",
    openShortcut: "Super_L",
    hotcornerEnabled: false,
    hotcornerPosition: "top-left",
    showDockIcon: true,
    useCustomIcon: false,
    panelIcon: "",
    showAppletLabel: false,
    appletLabelText: "Launchpad",
    effectsEnabled: true,
    frostedGlassEnabled: false,
    favoriteApps: [],
    defaultFavoritesSeeded: false
};

const DOCK_MAX_HEIGHT_CEILING = 130;
const DOCK_MIN_HEIGHT_FLOOR = 50;
const ICON_SIZE_FLOOR = 24;
const ICON_SIZE_CEILING = 96;

function clampDockHeight(value) {
    let v = (typeof value === "number" && !isNaN(value)) ? value : 64;
    return Math.max(DOCK_MIN_HEIGHT_FLOOR, Math.min(DOCK_MAX_HEIGHT_CEILING, v));
}

function clampIconSize(value) {
    let v = (typeof value === "number" && !isNaN(value)) ? value : 48;
    return Math.max(ICON_SIZE_FLOOR, Math.min(ICON_SIZE_CEILING, v));
}

// ---- Chameleonic mode: dock/tooltip/thumbnail/coverflow-pill color
// tracks the current wallpaper's dominant color instead of the
// user-picked dock-color swatch. Every one of those surfaces already
// pulls its color through getDockSettings().dockColor (see
// _getDockColorWithAlpha/_isDockColorLight in dock.js and osd.js), so
// overriding dockColor right here - rather than teaching each call site
// about chameleonic mode separately - is enough to repaint all of them
// at once. The user's manually-picked dock-color GSetting is left
// untouched underneath, so switching chameleonic mode back off restores
// it exactly as it was.
const _CHAMELEONIC_SAMPLE_PX = 48; // downscale target; plenty for an average

let _chameleonicCache = { uri: null, color: null };
let _bgSettings = null;
let _bgSignalId = null;

function _getBackgroundSettings() {
    if (_bgSettings) return _bgSettings;
    try {
        _bgSettings = new Gio.Settings({ schema_id: 'org.cinnamon.desktop.background' });
    } catch(e) {
        try {
            _bgSettings = new Gio.Settings({ schema_id: 'org.gnome.desktop.background' });
        } catch(e2) {
            _bgSettings = null;
        }
    }
    return _bgSettings;
}

function _wallpaperPath() {
    let s = _getBackgroundSettings();
    if (!s) return null;
    let uri = '';
    try { uri = s.get_string('picture-uri'); } catch(e) {}
    if (!uri) return null;
    try {
        return Gio.File.new_for_uri(uri).get_path();
    } catch(e) {
        return null;
    }
}

// Downscales the wallpaper to a tiny thumbnail and averages its pixels -
// the same fast approach already used for chameleonic accent extraction
// in Telly/global-settings@brahim - then nudges the result toward a
// slightly richer saturation so muted/hazy photos still read as a real
// color swatch rather than washed-out gray.
function _computeDominantColor(path) {
    try {
        let pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_scale(path, _CHAMELEONIC_SAMPLE_PX, _CHAMELEONIC_SAMPLE_PX, false);
        if (!pixbuf) return null;

        let width = pixbuf.get_width();
        let height = pixbuf.get_height();
        let nChannels = pixbuf.get_n_channels();
        let rowstride = pixbuf.get_rowstride();
        let pixels = pixbuf.get_pixels();

        let rSum = 0, gSum = 0, bSum = 0, count = 0;
        for (let y = 0; y < height; y++) {
            let rowOffset = y * rowstride;
            for (let x = 0; x < width; x++) {
                let offset = rowOffset + x * nChannels;
                rSum += pixels[offset];
                gSum += pixels[offset + 1];
                bSum += pixels[offset + 2];
                count++;
            }
        }
        if (count === 0) return null;

        let r = rSum / count, g = gSum / count, b = bSum / count;

        // Mild saturation boost around the sample's own average luminance,
        // so a dominant hue stays legible instead of collapsing to gray.
        let luminance = 0.299 * r + 0.587 * g + 0.114 * b;
        const boost = 1.25;
        r = Math.max(0, Math.min(255, Math.round(luminance + (r - luminance) * boost)));
        g = Math.max(0, Math.min(255, Math.round(luminance + (g - luminance) * boost)));
        b = Math.max(0, Math.min(255, Math.round(luminance + (b - luminance) * boost)));

        return "rgba(" + r + ", " + g + ", " + b + ", 1.0)";
    } catch(e) {
        return null;
    }
}

function _getChameleonicColor() {
    let path = _wallpaperPath();
    if (!path) return null;

    if (_chameleonicCache.uri === path && _chameleonicCache.color) {
        return _chameleonicCache.color;
    }

    let color = _computeDominantColor(path);
    if (color) {
        _chameleonicCache.uri = path;
        _chameleonicCache.color = color;
    }
    return color;
}

// Invalidates the cache and repaints the live dock the moment the user
// changes wallpaper, rather than waiting for the next unrelated settings
// change to pick up the new dominant color. Tooltips/popups/media card/
// coverflow pill are built fresh on each show so they just pick up the
// new getDockSettings().dockColor next time they appear - no separate
// notification needed for those.
function _watchWallpaperChanges() {
    let s = _getBackgroundSettings();
    if (!s || _bgSignalId) return;
    _bgSignalId = s.connect('changed::picture-uri', function() {
        _chameleonicCache.uri = null;
        _chameleonicCache.color = null;
        try {
            let dockSettings = getDockSettings();
            if (!dockSettings.chameleonicEnabled) return;
            Shared.requireSibling('dock').StandaloneDock.applySettings();
            // The dock repaints on its own applySettings() coalescer above,
            // but Launchpad only re-reads dockColor when ITS applySettings()
            // runs (see launchpad.js's _applyDockTint call site) - if the
            // Launchpad overlay happens to already be open when the
            // wallpaper changes, nudge it too so its tint doesn't lag a
            // stale color until the next unrelated Launchpad setting change.
            let Launchpad = Shared.requireSibling('launchpad').Launchpad;
            if (Launchpad && Launchpad._isOpen) Launchpad.applySettings();
        } catch(e) {}
    });
}

function getDockSettings() {
    let merged = {};
    for (let key in DEFAULT_DOCK_SETTINGS) {
        merged[key] = DEFAULT_DOCK_SETTINGS[key];
    }
    DOCK_SETTINGS_KEYMAP.forEach(function(pair) {
        try {
            let v = Shared.globalSettings.getValue(pair[0]);
            if (v !== undefined && v !== null) merged[pair[1]] = v;
        } catch(e) {}
    });

    if (merged.chameleonicEnabled) {
        _watchWallpaperChanges();
        let chameleonicColor = _getChameleonicColor();
        if (chameleonicColor) merged.dockColor = chameleonicColor;
    }

    return merged;
}

function saveDockSettings(settings) {
    DOCK_SETTINGS_KEYMAP.forEach(function(pair) {
        try {
            if (settings[pair[1]] !== undefined) Shared.globalSettings.setValue(pair[0], settings[pair[1]]);
        } catch(e) {}
    });
}

function getDockletsSettings() {
    let merged = {};
    for (let key in DEFAULT_DOCKLETS_SETTINGS) {
        merged[key] = DEFAULT_DOCKLETS_SETTINGS[key];
    }
    DOCKLETS_SETTINGS_KEYMAP.forEach(function(pair) {
        try {
            let v = Shared.globalSettings.getValue(pair[0]);
            if (v !== undefined && v !== null) merged[pair[1]] = v;
        } catch(e) {}
    });
    return merged;
}

function saveDockletsSettings(settings) {
    DOCKLETS_SETTINGS_KEYMAP.forEach(function(pair) {
        try {
            if (settings[pair[1]] !== undefined) Shared.globalSettings.setValue(pair[0], settings[pair[1]]);
        } catch(e) {}
    });
}

function getEffectsSettings() {
    let merged = {};
    for (let key in DEFAULT_EFFECTS_SETTINGS) {
        merged[key] = DEFAULT_EFFECTS_SETTINGS[key];
    }
    EFFECTS_SETTINGS_KEYMAP.forEach(function(pair) {
        try {
            let v = Shared.globalSettings.getValue(pair[0]);
            if (v !== undefined && v !== null) merged[pair[1]] = v;
        } catch(e) {}
    });
    return merged;
}

function saveEffectsSettings(settings) {
    EFFECTS_SETTINGS_KEYMAP.forEach(function(pair) {
        try {
            if (settings[pair[1]] !== undefined) Shared.globalSettings.setValue(pair[0], settings[pair[1]]);
        } catch(e) {}
    });
}

function getWeatherSettings() {
    let merged = {};
    for (let key in DEFAULT_WEATHER_SETTINGS) {
        merged[key] = DEFAULT_WEATHER_SETTINGS[key];
    }
    WEATHER_SETTINGS_KEYMAP.forEach(function(pair) {
        try {
            let v = Shared.globalSettings.getValue(pair[0]);
            if (v !== undefined && v !== null) merged[pair[1]] = v;
        } catch(e) {}
    });
    return merged;
}

function saveWeatherSettings(settings) {
    WEATHER_SETTINGS_KEYMAP.forEach(function(pair) {
        try {
            if (settings[pair[1]] !== undefined) Shared.globalSettings.setValue(pair[0], settings[pair[1]]);
        } catch(e) {}
    });
}

function getLaunchpadSettings() {
    let merged = {};
    for (let key in DEFAULT_LAUNCHPAD_SETTINGS) {
        merged[key] = DEFAULT_LAUNCHPAD_SETTINGS[key];
    }
    LAUNCHPAD_SETTINGS_KEYMAP.forEach(function(pair) {
        try {
            let v = Shared.globalSettings.getValue(pair[0]);
            if (v !== undefined && v !== null) merged[pair[1]] = v;
        } catch(e) {}
    });
    // favoriteApps / defaultFavoritesSeeded aren't user-facing widgets;
    // they're kept in one hidden "generic" key rather than shown in the
    // settings window.
    try {
        let internal = Shared.globalSettings.getValue("launchpad-internal-state") || {};
        if (internal.favoriteApps) merged.favoriteApps = internal.favoriteApps;
        if (typeof internal.defaultFavoritesSeeded === "boolean") merged.defaultFavoritesSeeded = internal.defaultFavoritesSeeded;
    } catch(e) {}
    // Always fixed; not currently exposed as user-editable.
    merged.showAppletLabel = false;
    merged.appletLabelText = "Launchpad";
    return merged;
}

function saveLaunchpadSettings(settings) {
    LAUNCHPAD_SETTINGS_KEYMAP.forEach(function(pair) {
        try {
            if (settings[pair[1]] !== undefined) Shared.globalSettings.setValue(pair[0], settings[pair[1]]);
        } catch(e) {}
    });
    try {
        Shared.globalSettings.setValue("launchpad-internal-state", {
            favoriteApps: settings.favoriteApps || [],
            defaultFavoritesSeeded: !!settings.defaultFavoritesSeeded
        });
    } catch(e) {}
}

// Remembers which station the radio docklet was last tuned to, across
// enable/disable and Cinnamon restarts - same "hidden generic key" pattern
// as launchpad-internal-state above, since this isn't a user-facing widget.
function getRadioCurrentStation() {
    try {
        return Shared.globalSettings.getValue("radio-current-station") || "";
    } catch(e) {
        return "";
    }
}

function saveRadioCurrentStation(stationId) {
    try {
        Shared.globalSettings.setValue("radio-current-station", stationId || "");
    } catch(e) {}
}

// Remembers the IPC socket path of the currently-running mpv radio
// stream (see radio.js's CinemixRadio._setState/_tryReattach) so that if
// Cinnamon restarts - which re-runs this extension's enable() from
// scratch while any mpv process it previously spawned keeps running
// completely independently in the background - the extension can
// reconnect to that still-alive stream instead of losing track of it
// entirely (which used to leave the dock icon showing "stopped" while
// audio kept playing, and make clicking Stop spawn a second, overlapping
// stream instead of actually stopping anything).
function getRadioRuntimeIpcPath() {
    try {
        return Shared.globalSettings.getValue("radio-runtime-ipc-path") || "";
    } catch(e) {
        return "";
    }
}

function saveRadioRuntimeIpcPath(path) {
    try {
        Shared.globalSettings.setValue("radio-runtime-ipc-path", path || "");
    } catch(e) {}
}

// ---- Internal helper (not exported) ----
const DEFAULT_FAVORITE_CANDIDATES = [
    ["firefox.desktop", "firefox-esr.desktop"],
    ["nemo.desktop", "org.gnome.Nautilus.desktop", "nautilus.desktop"],
    ["org.gnome.Terminal.desktop", "gnome-terminal.desktop", "org.cinnamon.terminal.desktop", "x-terminal-emulator.desktop", "xterm.desktop"],
    ["onboard.desktop"],
    ["cinnamon-screenshot.desktop", "org.gnome.Screenshot.desktop", "gnome-screenshot.desktop"]
];

function _seedDefaultFavoritesIfNeeded(settings) {
    if (settings.defaultFavoritesSeeded) return settings;
    settings.defaultFavoritesSeeded = true;

    if (settings.favoriteApps && settings.favoriteApps.length > 0) {
        return settings;
    }

    let seeded = [];
    try {
        DEFAULT_FAVORITE_CANDIDATES.forEach(function(candidates) {
            for (let i = 0; i < candidates.length; i++) {
                let info = null;
                try { info = Gio.DesktopAppInfo.new(candidates[i]); } catch(e) {}
                if (info) {
                    seeded.push(candidates[i]);
                    return;
                }
            }
        });
    } catch(e) {}

    settings.favoriteApps = seeded;
    return settings;
}
