// utils.js
// -*- mode: js; js-indent-level: 4; indent-tabs-mode: nil -*-

const Main = imports.ui.main;
const Meta = imports.gi.Meta;
const Clutter = imports.gi.Clutter;
const St = imports.gi.St;
const Lang = imports.lang;
const Util = imports.misc.util;
const GLib = imports.gi.GLib;
const Gettext = imports.gettext;

// Safe as a plain top-level import: extension.js is the only file that
// loads sibling xlet files by swapping imports.searchPath (see
// shared.js's requireSibling doc comment), and it always loads shared.js
// first - by the time it loads this file, searchPath is still pointed
// at the extension directory for the duration of that call.
const Shared = imports.shared;

Gettext.bindtextdomain(Shared.UUID, GLib.get_home_dir() + "/.local/share/locale");

function _(str) {
    return Gettext.dgettext(Shared.UUID, str);
}

// ── shell helpers (sync check / async fire, same pattern as
//    global-settings@brahim) ─────────────────────────────────
function _sh(cmd) {
    try {
        let [ok, out] = GLib.spawn_command_line_sync(cmd);
        if (ok && out) return imports.byteArray.toString(out).trim();
    } catch (e) {}
    return '';
}
function _run(cmd) {
    try { GLib.spawn_command_line_async(cmd); } catch (e) {}
}

// Rebuilds an rgb()/rgba() color string with a new alpha value.
//
// Every "apply transparency" call site used to do this with a bare
// regex - colorStr.replace(/[\d.]+\)$/, alpha + ')') - which assumed the
// stored color string always ends in an alpha component to overwrite
// (e.g. "rgba(245, 255, 255, 1.0)"). That assumption held for the
// hardcoded defaults, but GTK's native color chooser (the settings-schema
// "colorchooser" widget used for dock-color/indicatorColor) serializes
// fully-opaque colors as "rgb(r, g, b)" with NO alpha slot at all. Once a
// user picked a custom color, the regex matched the trailing blue-channel
// digits instead and overwrote them with the transparency fraction (e.g.
// "rgb(206, 92, 68)" -> "rgb(206, 92, 0.3)"), corrupting the color and
// making transparency appear to stop working entirely from then on.
//
// This parses out just the r/g/b numbers regardless of whether an alpha
// was present, and always rebuilds an explicit rgba(...) string.
function colorWithAlpha(colorStr, alpha) {
    let match = /rgba?\(\s*([\d.]+)[,\s]+([\d.]+)[,\s]+([\d.]+)/.exec(colorStr || "");
    if (!match) {
        // Not a color we recognize (shouldn't happen) - fall back to the
        // previous behavior rather than throwing.
        return colorStr;
    }
    return "rgba(" + match[1] + ", " + match[2] + ", " + match[3] + ", " + alpha + ")";
}

// Blends a base rgba()/rgb() color string toward an accent {r,g,b} color by
// fraction `t` (0..1). `maxBlend` caps how far the RGB travels toward the
// accent even at t=1, so a hover accent always reads as a tint rather than
// fully replacing the surface color. `minAlpha`, if given, also nudges the
// alpha channel up toward at least that value as t increases - without it,
// a dock/tooltip/Launchpad set to a low transparency would blend the right
// color but stay too faint to actually notice. Used for the per-app hover
// accent on the dock, its tooltip, and the Launchpad overlay.
function blendTowardAccent(baseColorStr, accentRgb, t, maxBlend, minAlpha) {
    let match = /rgba?\(\s*([\d.]+)[,\s]+([\d.]+)[,\s]+([\d.]+)(?:[,\s]+([\d.]+))?\s*\)/.exec(baseColorStr || "");
    if (!match || !accentRgb) return baseColorStr;
    let br = parseFloat(match[1]), bg = parseFloat(match[2]), bb = parseFloat(match[3]);
    let ba = match[4] !== undefined ? parseFloat(match[4]) : 1;
    let amount = Math.max(0, Math.min(1, t)) * (maxBlend !== undefined ? maxBlend : 1);
    let r = Math.round(br + (accentRgb.r - br) * amount);
    let g = Math.round(bg + (accentRgb.g - bg) * amount);
    let b = Math.round(bb + (accentRgb.b - bb) * amount);
    let a = ba;
    if (minAlpha !== undefined && minAlpha > ba) {
        a = Math.round((ba + (minAlpha - ba) * amount) * 100) / 100;
    }
    return "rgba(" + r + ", " + g + ", " + b + ", " + a + ")";
}

function minimizeAllWindows() {
    const minimized = [];
    try {
        const workspace = global.screen.get_active_workspace();
        if (!workspace) return minimized;
        const windows = workspace.list_windows();
        for (let i = 0; i < windows.length; i++) {
            const win = windows[i];
            if (!win || win.minimized) continue;
            if (win.get_window_type && win.get_window_type() !== Meta.WindowType.NORMAL) continue;
            win.minimize();
            minimized.push(win);
        }
    } catch (e) {}
    return minimized;
}

function restoreMinimizedWindows(windows) {
    if (!windows) return;
    for (let i = 0; i < windows.length; i++) {
        try {
            const win = windows[i];
            if (win && win.minimized) win.unminimize();
        } catch (e) {}
    }
}

function HotCorner(corner, cb) {
    this._corner = corner;
    this._cb = cb;
    this._w = null;
    this._sig = null;
}
HotCorner.prototype = {
    enable: function() {
        if (this._w) return;
        let m = Main.layoutManager.primaryMonitor;
        let right = this._corner.indexOf("right") !== -1;
        let bottom = this._corner.indexOf("bottom") !== -1;
        this._w = new St.Widget({
            reactive: true, can_focus: false, track_hover: true,
            width: 4, height: 4, style: "background-color:transparent;"
        });
        this._w.set_position(right ? m.x + m.width - 4 : m.x, bottom ? m.y + m.height - 4 : m.y);
        this._sig = this._w.connect("enter-event", Lang.bind(this, function() { this._cb(); }));
        try {
            Main.layoutManager.addChrome(this._w, { affectsInputRegion: true });
        } catch (e) {
            global.stage.add_actor(this._w);
            this._w.raise_top();
        }
    },
    disable: function() {
        if (!this._w) return;
        this._w.disconnect(this._sig);
        try {
            Main.layoutManager.removeChrome(this._w);
        } catch (e) {
            if (this._w.get_parent()) this._w.get_parent().remove_actor(this._w);
        }
        this._w = null;
        this._sig = null;
    },
    raiseTop: function() {
        if (this._w) this._w.raise_top();
    }
};

function openDockSettingsDialog() {
    try {
        Util.spawnCommandLine("xlet-settings extension " + Shared.UUID);
    } catch(e) {
        try {
            Util.spawnCommandLine("cinnamon-settings extensions " + Shared.UUID);
        } catch(e2) {
            global.logError("dock@brahim: could not open settings window: " + e2);
            global.logError(e2.stack);
        }
    }
}
