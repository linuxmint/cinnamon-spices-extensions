// osd.js
// -*- mode: js; js-indent-level: 4; indent-tabs-mode: nil -*-

const St = imports.gi.St;
const Clutter = imports.gi.Clutter;
const Cairo = imports.cairo;
const Main = imports.ui.main;
const Mainloop = imports.mainloop;

// Loaded via Shared.requireSibling('osd') (see radio.js), which swaps
// imports.searchPath to the extension dir before this file's top-level
// code runs - same pattern dock.js/launchpad.js use for these same
// sibling imports.
const Utils = imports.utils;
const SettingsStore = imports.settingsStore;

// Reads the dock's real, currently-configured background color (same
// color + same transparency the dock itself renders), so the OSD card
// can genuinely match the dock instead of staying hardcoded "light glass".
function _dockColorWithAlpha() {
    try {
        let s = SettingsStore.getDockSettings();
        let transparency = (s.transparency !== undefined ? s.transparency : 30) / 100.0;
        let dockColor = s.dockColor || "rgba(245, 255, 255, 1.0)";
        return Utils.colorWithAlpha(dockColor, transparency);
    } catch (e) {
        return null;
    }
}

// Whether the dock's OWN color reads as visually light, via the standard
// perceptual luminance formula - used to pick a white or near-black icon
// glyph so it stays legible against whatever color the dock actually is.
function _isDockColorLight() {
    try {
        let s = SettingsStore.getDockSettings();
        let dockColor = s.dockColor || "rgba(245, 255, 255, 1.0)";
        let match = /rgba?\(\s*([\d.]+)[,\s]+([\d.]+)[,\s]+([\d.]+)/.exec(dockColor);
        if (!match) return false;
        let r = parseFloat(match[1]), g = parseFloat(match[2]), b = parseFloat(match[3]);
        let luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
        return luminance > 0.55;
    } catch (e) {
        return false;
    }
}

const OSD_SEGMENTS        = 16;
const OSD_NORMAL_SEGMENTS = 11;
const OSD_MAX_VOL         = 150;
const OSD_HIDE_MS         = 1300;

function _volLevel(vol, muted) {
    if (muted || vol <= 0) return { muted: true,  waves: 0 };
    if (vol <= 33)         return { muted: false, waves: 1 };
    if (vol <= 66)         return { muted: false, waves: 2 };
    return                        { muted: false, waves: 3 };
}

function _drawSpeakerGlyph(cr, W, H, waves, muted, r, g, b, a) {
    cr.setOperator(Cairo.Operator.CLEAR); cr.paint();
    cr.setOperator(Cairo.Operator.OVER);

    const boxW = 22, boxH = 31, coneExtra = 23, coneH = 56;
    const apexRun = boxW + coneExtra;
    const waveBaseR = 14, waveStep = 13.5, waveStrokeHalf = 2.5;
    const muteGap = 27, muteSize = 13;

    const maxMuteExtent  = apexRun + muteGap + muteSize;
    const maxWaveExtent  = apexRun + waveBaseR + 2 * waveStep + waveStrokeHalf;
    const fixedExtent    = Math.max(maxMuteExtent, maxWaveExtent);
    const cx0 = (W - fixedExtent) / 2;

    const boxTop = (H - boxH) / 2, boxBottom = boxTop + boxH;
    const apexX   = cx0 + apexRun;
    const coneTop = (H - coneH) / 2, coneBottom = coneTop + coneH;

    cr.newPath();
    cr.moveTo(cx0, boxTop);
    cr.lineTo(cx0 + boxW, boxTop);
    cr.lineTo(apexX, coneTop);
    cr.lineTo(apexX, coneBottom);
    cr.lineTo(cx0 + boxW, boxBottom);
    cr.lineTo(cx0, boxBottom);
    cr.closePath();
    cr.setSourceRGBA(r, g, b, a);
    cr.fill();

    if (muted) {
        const mx = apexX + muteGap, my = H / 2, s = muteSize;
        cr.setLineWidth(5);
        cr.newPath();
        cr.moveTo(mx - s, my - s); cr.lineTo(mx + s, my + s);
        cr.setSourceRGBA(r, g, b, a);
        cr.stroke();
        cr.newPath();
        cr.moveTo(mx + s, my - s); cr.lineTo(mx - s, my + s);
        cr.setSourceRGBA(r, g, b, a);
        cr.stroke();
        cr.$dispose();
        return;
    }

    cr.setLineWidth(5);
    for (let i = 0; i < waves; i++) {
        let radius = waveBaseR + i * waveStep;
        cr.newPath();
        cr.arc(apexX - 1, H / 2, radius, -0.62, 0.62);
        cr.setSourceRGBA(r, g, b, a);
        cr.stroke();
    }
    cr.$dispose();
}

var MacVolumeOSD = class MacVolumeOSD {
    constructor() {
        this._segments  = [];
        this._hideTimer = null;
        this._iconState = { muted: false, waves: 3 };
        this._isDark = true;
        this._build();
    }

    _build() {
        this.actor = new St.Bin({
            style_class: 'gs-macos-osd-wrapper',
            reactive: false,
            x_align: St.Align.MIDDLE,
            y_align: St.Align.END,
            x_fill: false,
            y_fill: false
        });

        // Background/border/icon color are applied dynamically each show()
        // via _applyDockTint(), since the dock's color can change at any
        // time - "gs-macos-osd-card" alone only carries size/radius/padding.
        this._card = new St.Bin({
            style_class: 'gs-macos-osd-card',
            reactive: false,
            x_align: St.Align.MIDDLE,
            y_align: St.Align.MIDDLE,
            x_fill: false,
            y_fill: false
        });
        this._card.set_size(190, 190);

        this._cardInner = new St.BoxLayout({
            style_class: 'gs-macos-osd-inner',
            vertical: true,
            reactive: false
        });

        this._iconArea = new St.DrawingArea({ style_class: 'gs-macos-osd-icon' });
        this._iconArea.connect('repaint', (area) => {
            const cr = area.get_context();
            const box = area.get_allocation_box();
            const W = box.x2 - box.x1, H = box.y2 - box.y1;
            if (W < 2 || H < 2) { cr.$dispose(); return; }
            const rgba = this._isDark ? [1, 1, 1, 1] : [0.11, 0.11, 0.12, 1];
            _drawSpeakerGlyph(cr, W, H, this._iconState.waves, this._iconState.muted,
                               rgba[0], rgba[1], rgba[2], rgba[3]);
        });
        let iconBin = new St.Bin({
            child: this._iconArea,
            style_class: 'gs-macos-osd-icon-bin',
            x_align: St.Align.MIDDLE,
            y_align: St.Align.MIDDLE,
            x_fill: false,
            y_fill: false
        });

        this._segRow = new St.BoxLayout({ style_class: 'gs-macos-osd-segments' });
        for (let i = 0; i < OSD_SEGMENTS; i++) {
            let seg = new St.Bin({ style_class: 'gs-macos-osd-segment' });
            this._segRow.add(seg, { expand: false });
            this._segments.push(seg);
        }

        this._track = new St.Bin({
            style_class: 'gs-macos-osd-track',
            child: this._segRow,
            x_align: St.Align.MIDDLE,
            y_align: St.Align.MIDDLE,
            x_fill: false,
            y_fill: false
        });

        this._cardInner.add(iconBin,     { expand: false, x_fill: false, x_align: St.Align.MIDDLE });
        this._cardInner.add(this._track, { expand: false, x_fill: false, x_align: St.Align.MIDDLE });
        this._card.set_child(this._cardInner);
        this.actor.set_child(this._card);

        this.actor.opacity = 0;
        this.actor.hide();

        Main.layoutManager.addChrome(this.actor, {
            affectsInputRegion: false,
            affectsStruts: false
        });
    }

    _reposition() {
        let monitor = Main.layoutManager.primaryMonitor;
        if (!monitor) return;
        this.actor.set_position(monitor.x, monitor.y);
        this.actor.set_size(monitor.width, monitor.height);
    }

    // Matches the card's color (and picks white vs near-black for the
    // icon glyph) to the dock's ACTUAL rendered color, re-read fresh each
    // time the OSD pops up in case the dock color changed since last time.
    _applyDockTint() {
        this._isDark = !_isDockColorLight();
        this._card.remove_style_class_name('gs-macos-osd-dark');
        this._card.remove_style_class_name('gs-macos-osd-light');
        this._card.add_style_class_name(this._isDark ? 'gs-macos-osd-dark' : 'gs-macos-osd-light');

        let tinted = _dockColorWithAlpha();
        if (tinted) this._card.set_style('background-color: ' + tinted + ' !important;');
    }

    show(vol, muted) {
        this._reposition();
        this._applyDockTint();
        this._updateIcon(vol, muted);
        this._updateSegments(vol, muted);

        this.actor.show();
        this.actor.set_scale(0.94, 0.94);
        if (this.actor.ease) {
            this.actor.ease({
                opacity: 255, scale_x: 1, scale_y: 1,
                duration: 130, mode: Clutter.AnimationMode.EASE_OUT_QUAD
            });
        } else {
            this.actor.opacity = 255;
            this.actor.set_scale(1, 1);
        }

        if (this._hideTimer) {
            Mainloop.source_remove(this._hideTimer);
            this._hideTimer = null;
        }
        this._hideTimer = Mainloop.timeout_add(OSD_HIDE_MS, () => {
            this._hideTimer = null;
            if (this.actor.ease) {
                this.actor.ease({
                    opacity: 0, scale_x: 0.94, scale_y: 0.94,
                    duration: 180, mode: Clutter.AnimationMode.EASE_IN_QUAD,
                    onComplete: () => this.actor.hide()
                });
            } else {
                this.actor.opacity = 0;
                this.actor.hide();
            }
            return false;
        });
    }

    _updateIcon(vol, muted) {
        this._iconState = _volLevel(vol, muted);
        this._iconArea.queue_repaint();
    }

    _updateSegments(vol, muted) {
        let clamped = Math.max(0, Math.min(vol, OSD_MAX_VOL));
        let filled  = muted ? 0 : Math.round((clamped / OSD_MAX_VOL) * OSD_SEGMENTS);
        for (let i = 0; i < OSD_SEGMENTS; i++) {
            let amp = i >= OSD_NORMAL_SEGMENTS;
            let cls = 'gs-macos-osd-segment';
            if (i < filled) cls += amp ? ' gs-macos-osd-segment-amp-filled' : ' gs-macos-osd-segment-filled';
            else if (amp)   cls += ' gs-macos-osd-segment-amp';
            this._segments[i].style_class = cls;
        }
    }
};

var _osdInstance = null;

var showOSD = function(volume, muted) {
    // Temporary debug: log every caller of showOSD (with a stack trace)
    // so we can catch a trigger path that hasn't been found by reading
    // the source - remove once the startup-OSD bug is confirmed fixed.
    try {
        global.log('dock@brahim: brahim-osd-debug: showOSD(' + volume + ', ' + muted + ') called from:\n' + (new Error()).stack);
    } catch(e) {}

    if (volume === undefined) volume = 0;
    if (muted === undefined) muted = false;

    if (!_osdInstance) _osdInstance = new MacVolumeOSD();
    _osdInstance.show(Math.max(0, Math.min(OSD_MAX_VOL, volume)), muted);
};
