// radioIcons.js
// -*- mode: js; js-indent-level: 4; indent-tabs-mode: nil -*-
//
// Minimalist, monoline (SF Symbols-style) glyphs for the radio docklet's
// station picker, drawn with Cairo the same way osd.js draws its speaker
// glyph - a single-color vector shape rendered directly into an
// St.DrawingArea's 'repaint' callback, so it always looks crisp regardless
// of icon theme, and recolors instantly for playing/error/idle states
// without needing separate icon assets per color.
//
// Loaded via Shared.requireSibling('radioIcons') from radio.js.

const Cairo = imports.cairo;

// kind: 'radio' | 'wave' | 'leaf' | 'moon' | 'rain' | 'flame' | 'sun' |
//       'cloud' | 'partly-cloudy' | 'snow' | 'fog' | 'thunder'
// Falls back to 'radio' for any unrecognized kind. The last six were
// added for weather.js's live-condition glyphs (see its WMO
// weather-code -> kind table) - drawn here rather than in weather.js
// itself so every monoline glyph in the extension lives in one place,
// same reasoning the station glyphs already followed.
function drawStationIcon(cr, W, H, kind, r, g, b, a) {
    cr.setOperator(Cairo.Operator.CLEAR);
    cr.paint();
    cr.setOperator(Cairo.Operator.OVER);
    cr.setSourceRGBA(r, g, b, a);

    let cx = W / 2, cy = H / 2;
    let s = Math.min(W, H);

    switch (kind) {
        case "leaf":          _drawLeaf(cr, cx, cy, s);          break;
        case "moon":          _drawMoon(cr, cx, cy, s);          break;
        case "rain":          _drawRain(cr, cx, cy, s);          break;
        case "flame":         _drawFlame(cr, cx, cy, s);         break;
        case "wave":          _drawWave(cr, cx, cy, s);          break;
        case "sun":           _drawSun(cr, cx, cy, s);           break;
        case "cloud":         _drawCloudOnly(cr, cx, cy, s);     break;
        case "partly-cloudy": _drawPartlyCloudy(cr, cx, cy, s);  break;
        case "snow":          _drawSnow(cr, cx, cy, s);          break;
        case "fog":           _drawFog(cr, cx, cy, s);           break;
        case "thunder":       _drawThunder(cr, cx, cy, s);       break;
        case "radio":
        default:      _drawRadio(cr, cx, cy, s); break;
    }

    cr.$dispose();
}

// Shared cloud silhouette (same bezier outline _drawRain already used for
// its cloud) - factored out so sun/snow/fog/thunder/partly-cloudy can all
// stamp the identical cloud shape, filled, at a given center anchor.
function _cloudPath(cr, ccx, top, cw, ch) {
    cr.newPath();
    cr.moveTo(ccx - cw / 2, top + ch);
    cr.curveTo(ccx - cw / 2, top, ccx - cw * 0.15, top - ch * 0.4, ccx - cw * 0.05, top);
    cr.curveTo(ccx + cw * 0.05, top - ch * 0.6, ccx + cw / 2, top - ch * 0.05, ccx + cw / 2, top + ch * 0.35);
    cr.curveTo(ccx + cw / 2 + ch * 0.3, top + ch * 0.35, ccx + cw / 2 + ch * 0.3, top + ch, ccx + cw / 2, top + ch);
    cr.lineTo(ccx - cw / 2, top + ch);
    cr.closePath();
}

// Standalone sun disc + 8 rays, centered - used for clear-sky days.
function _drawSun(cr, cx, cy, s) {
    let sunR = s * 0.22;
    cr.setLineWidth(Math.max(1.5, s * 0.07));
    cr.setLineCap(Cairo.LineCap.ROUND);
    for (let i = 0; i < 8; i++) {
        let angle = (Math.PI * 2 / 8) * i;
        let x1 = cx + Math.cos(angle) * (sunR * 1.35);
        let y1 = cy + Math.sin(angle) * (sunR * 1.35);
        let x2 = cx + Math.cos(angle) * (sunR * 1.85);
        let y2 = cy + Math.sin(angle) * (sunR * 1.85);
        cr.newPath();
        cr.moveTo(x1, y1);
        cr.lineTo(x2, y2);
        cr.stroke();
    }
    cr.newPath();
    cr.arc(cx, cy, sunR, 0, 2 * Math.PI);
    cr.fill();
}

// Plain filled cloud, centered, no rays/drops - used for overcast skies.
function _drawCloudOnly(cr, cx, cy, s) {
    _cloudPath(cr, cx, cy - s * 0.02, s * 0.66, s * 0.28);
    cr.fill();
}

// Sun-partly-behind-a-cloud - the original weather.js default glyph,
// moved here unchanged so it can be selected like any other kind.
function _drawPartlyCloudy(cr, cx, cy, s) {
    let sunCx = cx - s * 0.12, sunCy = cy - s * 0.14, sunR = s * 0.16;
    cr.setLineWidth(Math.max(1.5, s * 0.06));
    cr.setLineCap(Cairo.LineCap.ROUND);
    for (let i = 0; i < 8; i++) {
        let angle = (Math.PI * 2 / 8) * i;
        let x1 = sunCx + Math.cos(angle) * (sunR * 1.4);
        let y1 = sunCy + Math.sin(angle) * (sunR * 1.4);
        let x2 = sunCx + Math.cos(angle) * (sunR * 1.85);
        let y2 = sunCy + Math.sin(angle) * (sunR * 1.85);
        cr.newPath();
        cr.moveTo(x1, y1);
        cr.lineTo(x2, y2);
        cr.stroke();
    }
    cr.newPath();
    cr.arc(sunCx, sunCy, sunR, 0, 2 * Math.PI);
    cr.fill();

    _cloudPath(cr, cx + s * 0.06, cy + s * 0.06, s * 0.62, s * 0.26);
    cr.fill();
}

// Cloud + three short falling snowflake asterisks - used for snow.
function _drawSnow(cr, cx, cy, s) {
    _cloudPath(cr, cx, cy - s * 0.14, s * 0.60, s * 0.24);
    cr.fill();

    let baseY = cy + s * 0.20;
    let xs = [cx - s * 0.16, cx + s * 0.02, cx + s * 0.20];
    cr.setLineWidth(Math.max(1.2, s * 0.045));
    cr.setLineCap(Cairo.LineCap.ROUND);
    for (let i = 0; i < xs.length; i++) {
        let fy = baseY + ((i === 1) ? s * 0.08 : 0);
        let r = s * 0.06;
        for (let a = 0; a < 3; a++) {
            let angle = (Math.PI / 3) * a;
            cr.newPath();
            cr.moveTo(xs[i] - Math.cos(angle) * r, fy - Math.sin(angle) * r);
            cr.lineTo(xs[i] + Math.cos(angle) * r, fy + Math.sin(angle) * r);
            cr.stroke();
        }
    }
}

// Cloud + three short horizontal haze lines beneath it - used for fog.
function _drawFog(cr, cx, cy, s) {
    _cloudPath(cr, cx, cy - s * 0.16, s * 0.58, s * 0.22);
    cr.fill();

    cr.setLineWidth(Math.max(1.5, s * 0.06));
    cr.setLineCap(Cairo.LineCap.ROUND);
    let widths = [0.56, 0.42, 0.30];
    let ys = [cy + s * 0.14, cy + s * 0.27, cy + s * 0.40];
    for (let i = 0; i < 3; i++) {
        let halfW = s * widths[i] / 2;
        cr.newPath();
        cr.moveTo(cx - halfW, ys[i]);
        cr.lineTo(cx + halfW, ys[i]);
        cr.stroke();
    }
}

// Cloud + a jagged lightning bolt beneath it - used for thunderstorms.
function _drawThunder(cr, cx, cy, s) {
    _cloudPath(cr, cx, cy - s * 0.16, s * 0.62, s * 0.24);
    cr.fill();

    let bx = cx, by = cy + s * 0.08;
    cr.newPath();
    cr.moveTo(bx + s * 0.06, by);
    cr.lineTo(bx - s * 0.08, by + s * 0.20);
    cr.lineTo(bx + s * 0.02, by + s * 0.20);
    cr.lineTo(bx - s * 0.10, by + s * 0.42);
    cr.lineTo(bx + s * 0.12, by + s * 0.16);
    cr.lineTo(bx + s * 0.02, by + s * 0.16);
    cr.closePath();
    cr.fill();
}

// Plain radio-set glyph (rounded body, antenna, speaker dots, dial knob) -
// the single, fixed icon used for the dock's radio tile and the media-art
// placeholder, in place of the old per-station mood glyphs below.
function _drawRadio(cr, cx, cy, s) {
    cr.setLineWidth(s * 0.085);
    cr.setLineCap(Cairo.LineCap.ROUND);
    cr.setLineJoin(Cairo.LineJoin.ROUND);

    let bw = s * 0.62, bh = s * 0.42;
    let left = cx - bw / 2, right = cx + bw / 2;
    let top = cy - bh / 2 + s * 0.06, bottom = cy + bh / 2 + s * 0.06;
    let radius = s * 0.07;

    cr.newPath();
    cr.moveTo(left + radius, top);
    cr.lineTo(right - radius, top);
    cr.arc(right - radius, top + radius, radius, -Math.PI / 2, 0);
    cr.lineTo(right, bottom - radius);
    cr.arc(right - radius, bottom - radius, radius, 0, Math.PI / 2);
    cr.lineTo(left + radius, bottom);
    cr.arc(left + radius, bottom - radius, radius, Math.PI / 2, Math.PI);
    cr.lineTo(left, top + radius);
    cr.arc(left + radius, top + radius, radius, Math.PI, 1.5 * Math.PI);
    cr.closePath();
    cr.stroke();

    cr.newPath();
    cr.moveTo(left + bw * 0.22, top);
    cr.lineTo(left + bw * 0.05, top - s * 0.22);
    cr.stroke();

    let dotR = s * 0.035;
    let gy = cy + s * 0.06;
    for (let i = 0; i < 3; i++) {
        let gx = left + bw * 0.20 + i * bw * 0.16;
        cr.newPath();
        cr.arc(gx, gy, dotR, 0, 2 * Math.PI);
        cr.fill();
    }

    let knobR = s * 0.09;
    let kx = right - bw * 0.22, ky = gy;
    cr.newPath();
    cr.arc(kx, ky, knobR, 0, 2 * Math.PI);
    cr.stroke();
    cr.newPath();
    cr.moveTo(kx, ky);
    cr.lineTo(kx, ky - knobR);
    cr.stroke();
}

// Three stacked, tapering wave lines - reads as both "radio waves" and
// "ocean swell", used for the chill/lounge stations.
function _drawWave(cr, cx, cy, s) {
    cr.setLineWidth(s * 0.09);
    cr.setLineCap(Cairo.LineCap.ROUND);
    let widths = [0.62, 0.46, 0.30];
    let ys = [cy - s * 0.18, cy + s * 0.01, cy + s * 0.20];
    for (let i = 0; i < 3; i++) {
        let halfW = s * widths[i] / 2;
        cr.newPath();
        cr.moveTo(cx - halfW, ys[i]);
        cr.curveTo(
            cx - halfW * 0.3, ys[i] - s * 0.09,
            cx + halfW * 0.3, ys[i] + s * 0.09,
            cx + halfW, ys[i]
        );
        cr.stroke();
    }
}

// Simple outlined leaf with a center vein and short stem - used for the
// more organic/chill-sounding stations.
function _drawLeaf(cr, cx, cy, s) {
    cr.setLineWidth(s * 0.08);
    cr.setLineCap(Cairo.LineCap.ROUND);
    cr.setLineJoin(Cairo.LineJoin.ROUND);
    let r = s * 0.30;

    cr.newPath();
    cr.moveTo(cx, cy - r);
    cr.curveTo(cx + r * 1.15, cy - r * 0.55, cx + r * 1.15, cy + r * 0.55, cx, cy + r);
    cr.curveTo(cx - r * 1.15, cy + r * 0.55, cx - r * 1.15, cy - r * 0.55, cx, cy - r);
    cr.closePath();
    cr.stroke();

    cr.newPath();
    cr.moveTo(cx, cy - r * 0.7);
    cr.lineTo(cx, cy + r * 0.8);
    cr.stroke();

    cr.newPath();
    cr.moveTo(cx, cy + r);
    cr.lineTo(cx, cy + r + s * 0.09);
    cr.stroke();
}

// Crescent moon (two overlapping circles, even-odd fill) plus a small
// star - used for the deep-ambient / space-toned stations.
function _drawMoon(cr, cx, cy, s) {
    let r = s * 0.30;
    cr.setFillRule(Cairo.FillRule.EVEN_ODD);
    cr.newPath();
    cr.arc(cx, cy, r, 0, 2 * Math.PI);
    cr.arc(cx + r * 0.55, cy - r * 0.35, r * 0.82, 0, 2 * Math.PI);
    cr.fill();

    cr.newPath();
    cr.arc(cx - r * 0.85, cy - r * 0.9, s * 0.045, 0, 2 * Math.PI);
    cr.fill();
}

// Rounded cloud outline with three short raindrop strokes beneath it -
// reserved for a literal rain/nature-sound station.
function _drawRain(cr, cx, cy, s) {
    cr.setLineWidth(s * 0.08);
    cr.setLineCap(Cairo.LineCap.ROUND);
    cr.setLineJoin(Cairo.LineJoin.ROUND);

    let w = s * 0.60, h = s * 0.26;
    let top = cy - s * 0.20;

    cr.newPath();
    cr.moveTo(cx - w / 2, top + h);
    cr.curveTo(cx - w / 2, top, cx - w * 0.15, top - h * 0.4, cx - w * 0.05, top);
    cr.curveTo(cx + w * 0.05, top - h * 0.6, cx + w / 2, top - h * 0.05, cx + w / 2, top + h * 0.35);
    cr.curveTo(cx + w / 2 + h * 0.3, top + h * 0.35, cx + w / 2 + h * 0.3, top + h, cx + w / 2, top + h);
    cr.lineTo(cx - w / 2, top + h);
    cr.closePath();
    cr.stroke();

    let dropY0 = top + h + s * 0.10;
    let xs = [cx - s * 0.16, cx + s * 0.02, cx + s * 0.20];
    for (let i = 0; i < xs.length; i++) {
        let yOff = (i === 1) ? s * 0.06 : 0;
        cr.newPath();
        cr.moveTo(xs[i], dropY0 + yOff);
        cr.lineTo(xs[i] - s * 0.05, dropY0 + yOff + s * 0.14);
        cr.stroke();
    }
}

// Teardrop flame outline with a small inner flicker line - reserved for
// a cozy/fireplace-toned station.
function _drawFlame(cr, cx, cy, s) {
    cr.setLineWidth(s * 0.08);
    cr.setLineCap(Cairo.LineCap.ROUND);
    cr.setLineJoin(Cairo.LineJoin.ROUND);
    let r = s * 0.30;

    cr.newPath();
    cr.moveTo(cx, cy - r * 1.35);
    cr.curveTo(cx + r * 1.3, cy - r * 0.3, cx + r * 0.9, cy + r * 0.9, cx, cy + r * 1.1);
    cr.curveTo(cx - r * 0.9, cy + r * 0.9, cx - r * 1.3, cy - r * 0.3, cx, cy - r * 1.35);
    cr.closePath();
    cr.stroke();

    cr.newPath();
    cr.moveTo(cx, cy - r * 0.15);
    cr.curveTo(cx + r * 0.35, cy + r * 0.15, cx + r * 0.15, cy + r * 0.55, cx, cy + r * 0.65);
    cr.stroke();
}
