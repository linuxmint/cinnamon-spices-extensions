// windowEffects.js
// -*- mode: js; js-indent-level: 4; indent-tabs-mode: nil -*-
//
// Window minimize/restore effects for the dock, adapted from Kevin
// Langman's CinnamonBurnMyWindows@klangman (itself a Cinnamon port of
// Simon Schneegans' Burn-My-Windows GNOME Shell extension - SPDX
// attributions kept where code was copied close to verbatim). Four
// effects are ported: Glide (default), Fire, Wisps, Apparition. Their
// .frag files (resources/shaders/*.frag) were copied unmodified from an
// existing CinnamonBurnMyWindows install; common.glsl was reconstructed
// from scratch (see the big warning comment at the top of that file -
// it's the one piece of this feature that couldn't be verified here).
//
// Unlike the original extension - which hooks EVERY window's minimize/
// unminimize globally via Main.wm._shouldAnimate - this module is only
// triggered from dock.js's _activate() (clicking a running app's dock
// icon), via minimizeWindow()/unminimizeWindow() below. Each call:
//   1. Clones the window actor's current on-screen appearance into an
//      overlay actor in Main.uiGroup.
//   2. Arms shouldAnimateManager.js to suppress Cinnamon's OWN default
//      animation for that one specific actor+transition, so it doesn't
//      play underneath/alongside ours.
//   3. Performs the real win.minimize()/win.unminimize() (state changes
//      instantly since the default animation is suppressed).
//   4. Runs the chosen shader over the clone via a Clutter.Timeline,
//      then destroys the clone.
// Minimizes/unminimizes triggered any other way (window control buttons,
// Alt-F9, etc.) are untouched and keep Cinnamon's normal animation.

const Main = imports.ui.main;
const Mainloop = imports.mainloop;
const Clutter = imports.gi.Clutter;
const Cinnamon = imports.gi.Cinnamon;
const GObject = imports.gi.GObject;
const Gio = imports.gi.Gio;
const GLib = imports.gi.GLib;
const Meta = imports.gi.Meta;

const Shared = imports.shared;
const SettingsStore = imports.settingsStore;
const SAM = imports.shouldAnimateManager;

// Apparition's math expects extra transparent padding around the window
// so the "suck inward" motion doesn't just clip against the actor edge -
// the real extension expressed this as getActorScale() returning 2.0 and
// relying on extension.js to size the actor accordingly. We reproduce
// that here per-effect by rendering into a padded container instead of
// cloning the window actor directly (see _playEffect below).
const ACTOR_SCALE = { glide: 1.0, fire: 1.0, wisps: 1.0, apparition: 2.0 };

const VALID_NICKS = ['glide', 'fire', 'wisps', 'apparition'];

// Fixed per-effect look. dock@brahim only exposes a single on/off +
// effect-choice setting (see settings-schema.json's "Window Effects"
// section) rather than full per-parameter tuning like upstream's own
// prefs dialog - these mirror upstream's own defaults where the source
// made them obvious (e.g. Fire's "Default Fire" preset), and are
// otherwise reasonable middle-of-the-road values for a dock-triggered
// transition.
const EFFECT_DEFAULTS = {
    glide: { scale: 2.5, squish: 0.5, tilt: 0.5, shift: 0.5 },
    fire: {
        scale: 1.0,
        movementSpeed: 0.5,
        threeDNoise: false,
        randomColor: false,
        colors: [
            'rgba(76, 51, 25, 0.0)',
            'rgba(180, 55, 30, 0.7)',
            'rgba(255, 76, 38, 0.9)',
            'rgba(255, 166, 25, 1.0)',
            'rgba(255, 255, 255, 1.0)'
        ]
    },
    wisps: {
        scale: 1.0,
        colors: ['rgb(255, 255, 255)', 'rgb(120, 170, 255)', 'rgb(190, 130, 255)']
    },
    apparition: { shake: 0.5, twirl: 1.0, suction: 1.0, randomness: 0.5 }
};

function _parseColor(str) {
    let m = /rgba?\(\s*([\d.]+)[,\s]+([\d.]+)[,\s]+([\d.]+)(?:[,\s]+([\d.]+))?\s*\)/.exec(str || '');
    if (!m) return [1, 1, 1, 1];
    return [parseFloat(m[1]) / 255, parseFloat(m[2]) / 255, parseFloat(m[3]) / 255,
            m[4] !== undefined ? parseFloat(m[4]) : 1];
}

// ---------------------------------------------------------------- shaders

function _loadShaderResource(relPath) {
    let dir = Shared.EXTENSION_DIR;
    let commonFile = Gio.File.new_for_path(dir + '/resources/shaders/common.glsl');
    let [, commonBytes] = commonFile.load_contents(null);
    let common = imports.byteArray.toString(commonBytes);

    let file = Gio.File.new_for_path(dir + '/resources/shaders/' + relPath);
    let [, bytes] = file.load_contents(null);
    let code = imports.byteArray.toString(bytes);

    return common + '\n' + code + '\n';
}

function _buildPipelineForNick(nick, effectInstance) {
    try {
        let code = _loadShaderResource(nick + '.frag');
        let regex = /void main *\(\) *\{([\s\S]+)\}/;
        let match = regex.exec(code);
        if (!match) {
            global.logError('dock@brahim: windowEffects - could not find void main() in ' + nick + '.frag');
            return;
        }
        let declarations = code.substr(0, match.index);
        let main = match[1];
        effectInstance.add_glsl_snippet(Cinnamon.SnippetHook.FRAGMENT, declarations, main, true);
    } catch (e) {
        global.logError('dock@brahim: windowEffects - failed to build shader pipeline for "' + nick + '": ' + e);
        if (e && e.stack) global.logError(e.stack);
    }
}

// Shell/Cinnamon's GLSLEffect caches compiled shader source PER GOBJECT
// CLASS, not per instance - so each effect nick needs its own registered
// subclass (this mirrors ShaderFactory.js's ShaderImp/Shader.Shader
// split from the original extension).
let _baseShaderClass = null;
let _shaderClasses = {};
let _freeShaders = {};

function _getBaseShaderClass() {
    if (_baseShaderClass) return _baseShaderClass;
    const typeName = `DockBrahimWindowEffectShaderBase_${Math.floor(Math.random() * 100000) + 1}`;
    _baseShaderClass = GObject.registerClass({ GTypeName: typeName },
        class extends Cinnamon.GLSLEffect {
            _init(nick) {
                this._nick = nick;
                super._init();
                this._uForOpening = this.get_uniform_location('uForOpening');
                this._uProgress   = this.get_uniform_location('uProgress');
                this._uDuration   = this.get_uniform_location('uDuration');
                this._uSize       = this.get_uniform_location('uSize');
                this._uPadding    = this.get_uniform_location('uPadding');
            }
            vfunc_build_pipeline() {
                _buildPipelineForNick(this._nick, this);
            }
        });
    return _baseShaderClass;
}

function _getShaderClassForNick(nick) {
    if (_shaderClasses[nick]) return _shaderClasses[nick];
    const Base = _getBaseShaderClass();
    const typeName = `DockBrahimWindowEffectShader_${nick}`;
    _shaderClasses[nick] = GObject.registerClass({ GTypeName: typeName },
        class extends Base {
            _init() { super._init(nick); }
        });
    return _shaderClasses[nick];
}

function _bindEffectUniforms(nick, shader) {
    if (nick === 'glide') {
        shader._uScale  = shader.get_uniform_location('uScale');
        shader._uSquish = shader.get_uniform_location('uSquish');
        shader._uTilt   = shader.get_uniform_location('uTilt');
        shader._uShift  = shader.get_uniform_location('uShift');
    } else if (nick === 'fire') {
        shader._uGradient = [1, 2, 3, 4, 5].map((i) => shader.get_uniform_location('uGradient' + i));
        shader._u3DNoise       = shader.get_uniform_location('u3DNoise');
        shader._uScale         = shader.get_uniform_location('uScale');
        shader._uMovementSpeed = shader.get_uniform_location('uMovementSpeed');
        shader._uRandomColor   = shader.get_uniform_location('uRandomColor');
        shader._uSeed          = shader.get_uniform_location('uSeed');
    } else if (nick === 'wisps') {
        shader._uSeed  = shader.get_uniform_location('uSeed');
        shader._uScale = shader.get_uniform_location('uScale');
        shader._uColor = [1, 2, 3].map((i) => shader.get_uniform_location('uColor' + i));
    } else if (nick === 'apparition') {
        shader._uSeed       = shader.get_uniform_location('uSeed');
        shader._uShake      = shader.get_uniform_location('uShake');
        shader._uTwirl      = shader.get_uniform_location('uTwirl');
        shader._uSuction    = shader.get_uniform_location('uSuction');
        shader._uRandomness = shader.get_uniform_location('uRandomness');
    }
}

function _applyEffectUniforms(nick, shader, forOpening, width, height, durationMs) {
    let d = EFFECT_DEFAULTS[nick];

    if (nick === 'glide') {
        shader.set_uniform_float(shader._uScale, 1, [d.scale]);
        shader.set_uniform_float(shader._uSquish, 1, [d.squish]);
        shader.set_uniform_float(shader._uTilt, 1, [d.tilt]);
        shader.set_uniform_float(shader._uShift, 1, [d.shift]);
    } else if (nick === 'fire') {
        for (let i = 0; i < 5; i++) {
            let c = _parseColor(d.colors[i]);
            shader.set_uniform_float(shader._uGradient[i], 4, c);
        }
        shader.set_uniform_float(shader._u3DNoise, 1, [d.threeDNoise ? 1 : 0]);
        shader.set_uniform_float(shader._uRandomColor, 1, [d.randomColor ? 1 : 0]);
        shader.set_uniform_float(shader._uSeed, 1, [Math.random()]);
        shader.set_uniform_float(shader._uScale, 1, [d.scale]);
        shader.set_uniform_float(shader._uMovementSpeed, 1, [d.movementSpeed]);
    } else if (nick === 'wisps') {
        shader.set_uniform_float(shader._uSeed, 2, [Math.random(), Math.random()]);
        shader.set_uniform_float(shader._uScale, 1, [d.scale]);
        for (let i = 0; i < 3; i++) {
            let c = _parseColor(d.colors[i]);
            shader.set_uniform_float(shader._uColor[i], 3, [c[0], c[1], c[2]]);
        }
    } else if (nick === 'apparition') {
        shader.set_uniform_float(shader._uSeed, 2, [Math.random(), Math.random()]);
        shader.set_uniform_float(shader._uShake, 1, [d.shake]);
        shader.set_uniform_float(shader._uTwirl, 1, [d.twirl]);
        shader.set_uniform_float(shader._uSuction, 1, [d.suction]);
        shader.set_uniform_float(shader._uRandomness, 1, [d.randomness]);
    }

    shader.set_uniform_float(shader._uForOpening, 1, [forOpening ? 1 : 0]);
    shader.set_uniform_float(shader._uDuration, 1, [Math.max(1, durationMs) * 0.001]);
    shader.set_uniform_float(shader._uSize, 2, [width, height]);
    shader.set_uniform_float(shader._uPadding, 1, [0]);
}

function _getShader(nick) {
    _freeShaders[nick] = _freeShaders[nick] || [];
    if (_freeShaders[nick].length > 0) return _freeShaders[nick].pop();
    let Klass = _getShaderClassForNick(nick);
    let shader = new Klass();
    _bindEffectUniforms(nick, shader);
    return shader;
}

function _returnShader(nick, shader) {
    _freeShaders[nick] = _freeShaders[nick] || [];
    _freeShaders[nick].push(shader);
}

// ------------------------------------------------------------ playback

// Clones `sourceActor`'s current appearance into an overlay (padded to
// ACTOR_SCALE[nick]x its size, centered, for apparition), applies the
// chosen shader to that overlay, and animates uProgress 0 -> 1 over
// durationMs. Calls onDone once when finished (including via a timeout
// safety net, in case 'completed' never fires - e.g. the actor was
// destroyed mid-animation).
function _playEffect(nick, sourceActor, forOpening, durationMs, onDone) {
    let scale = ACTOR_SCALE[nick] || 1.0;
    let w = sourceActor.width, h = sourceActor.height;
    let [x, y] = sourceActor.get_position();

    let container = new Clutter.Actor();
    container.set_size(w * scale, h * scale);
    container.set_position(x - (w * scale - w) / 2, y - (h * scale - h) / 2);

    let clone = new Clutter.Clone({ source: sourceActor });
    clone.set_size(w, h);
    clone.set_position((w * scale - w) / 2, (h * scale - h) / 2);
    container.add_child(clone);

    Main.uiGroup.add_child(container);
    container.raise_top();

    let shader = _getShader(nick);
    _applyEffectUniforms(nick, shader, forOpening, w * scale, h * scale, durationMs);
    container.add_effect_with_name('dock-brahim-window-effect', shader);

    let finished = false;
    let finish = function() {
        if (finished) return;
        finished = true;
        try { container.remove_effect(shader); } catch (e) {}
        _returnShader(nick, shader);
        try { container.destroy(); } catch (e) {}
        if (onDone) onDone();
    };

    let timeline = new Clutter.Timeline({ duration: Math.max(50, durationMs) });
    timeline.connect('new-frame', function(t) {
        try {
            shader.set_uniform_float(shader._uProgress, 1, [t.get_progress()]);
            shader.queue_repaint();
        } catch (e) {}
    });
    timeline.connect('completed', finish);
    // Safety net - see comment above.
    Mainloop.timeout_add(Math.max(50, durationMs) + 800, function() {
        finish();
        return GLib.SOURCE_REMOVE;
    });
    timeline.start();
}

// --------------------------------------------------------- suppression

let _sam = null;
let _suppressActor = null;
let _suppressEvent = 0;
let _samOwner = null;

// Minimize/Unminimize stay dock-triggered-only (see file header comment) -
// they only fire when minimizeWindow()/unminimizeWindow() below pre-armed
// _suppressActor for this exact actor right before calling
// win.minimize()/win.unminimize() themselves.
//
// MapWindow/DestroyWindow can't use that same pre-arm pattern: there's no
// actor to pre-arm before requesting a new window (app.open_new_window()
// is async and hands nothing back synchronously), and window-close can be
// triggered from places other than our own code (the dock's "Quit" menu
// item, a titlebar close button, Alt+F4, etc.) - all of which should still
// get the close effect. So these two events are handled as a genuine
// global hook instead, exactly like CinnamonBurnMyWindows' own
// _shouldAnimateHandler: play directly on whatever actor Muffin passes to
// this call (SAM's handler() already filters to normal/dialog windows
// only), no pre-arming required.
function _shouldAnimateHandler(actor, types, event) {
    if ((event & (SAM.Events.Minimize | SAM.Events.Unminimize)) !== 0) {
        if (_suppressActor && actor === _suppressActor && (event & _suppressEvent) !== 0) {
            return false;
        }
        return SAM.RUN_ORIGINAL_FUNCTION;
    }

    if ((event & (SAM.Events.MapWindow | SAM.Events.DestroyWindow)) !== 0) {
        let settings = _currentSettings();
        if (!settings.enabled) return SAM.RUN_ORIGINAL_FUNCTION;
        let forOpening = (event & SAM.Events.MapWindow) !== 0;
        let nick = forOpening ? settings.nick : settings.closeNick;
        _playEffect(nick, actor, forOpening, settings.duration, function() {});
        return false;
    }

    return SAM.RUN_ORIGINAL_FUNCTION;
}

// ----------------------------------------------------------------- API

function _currentSettings() {
    let s;
    try { s = SettingsStore.getDockSettings(); } catch (e) { s = {}; }
    let nick = s.windowEffect;
    if (VALID_NICKS.indexOf(nick) === -1) nick = 'wisps';
    let closeNick = s.windowCloseEffect;
    if (VALID_NICKS.indexOf(closeNick) === -1) closeNick = 'fire';
    return {
        enabled: s.windowEffectEnabled !== false,
        nick: nick,
        closeNick: closeNick,
        duration: s.windowEffectDuration || 900
    };
}

function minimizeWindow(win) {
    let settings = _currentSettings();
    if (!settings.enabled) {
        try { win.minimize(); } catch (e) {}
        return;
    }

    let actor = null;
    try { actor = win.get_compositor_private(); } catch (e) {}
    if (!actor) {
        try { win.minimize(); } catch (e) {}
        return;
    }

    _suppressActor = actor;
    _suppressEvent = SAM.Events.Minimize;

    _playEffect(settings.nick, actor, false, settings.duration, function() {
        _suppressActor = null;
        _suppressEvent = 0;
    });

    try {
        win.minimize();
    } catch (e) {
        _suppressActor = null;
        _suppressEvent = 0;
    }
}

function unminimizeWindow(win) {
    let settings = _currentSettings();
    if (!settings.enabled) {
        try { win.unminimize(); } catch (e) {}
        return;
    }

    let actor = null;
    try { actor = win.get_compositor_private(); } catch (e) {}
    if (!actor) {
        try { win.unminimize(); } catch (e) {}
        return;
    }

    _suppressActor = actor;
    _suppressEvent = SAM.Events.Unminimize;

    try {
        win.unminimize();
    } catch (e) {
        _suppressActor = null;
        _suppressEvent = 0;
        return;
    }

    // The actor is instantly at its restored appearance now (Cinnamon's
    // own reveal animation was suppressed) - clone that and play the
    // materialize effect on top of it.
    _playEffect(settings.nick, actor, true, settings.duration, function() {
        _suppressActor = null;
        _suppressEvent = 0;
    });
}

// Plays the close effect over the window's current appearance, then
// actually closes it. Mirrors minimizeWindow()'s suppress-then-transition
// pattern, but arms SAM for DestroyWindow instead of Minimize, since
// that's the event type Cinnamon's WM fires _shouldAnimate for when a
// window is being destroyed (see _destroyWindow@ in the shouldAnimate
// stack-trace check in shouldAnimateManager.js's handler()).
// The close effect now plays automatically for ANY window close (see
// _shouldAnimateHandler's global MapWindow/DestroyWindow branch above),
// not just ones triggered from here - so this is just a plain passthrough
// kept for call-site clarity/symmetry with minimizeWindow/unminimizeWindow.
function closeWindow(win) {
    try { win.delete(global.get_current_time()); } catch (e) {}
}

function enable() {
    _sam = new SAM.ShouldAnimateManager(Shared.UUID);
    _samOwner = _sam.connect(SAM.Events.Minimize | SAM.Events.Unminimize | SAM.Events.MapWindow | SAM.Events.DestroyWindow, _shouldAnimateHandler);
    if (_samOwner) {
        global.logError('dock@brahim: windowEffects - minimize/unminimize animation hook is already owned by "' +
            _samOwner + '"; dock window effects will play alongside that extension\'s own animation instead of replacing it.');
    }
}

function disable() {
    if (_sam) {
        try { _sam.disconnect(); } catch (e) {}
    }
    _sam = null;
    _samOwner = null;
    _suppressActor = null;
    _suppressEvent = 0;
    _freeShaders = {};
}

var WindowEffects = {
    enable: enable,
    disable: disable,
    minimizeWindow: minimizeWindow,
    unminimizeWindow: unminimizeWindow,
    closeWindow: closeWindow
};
