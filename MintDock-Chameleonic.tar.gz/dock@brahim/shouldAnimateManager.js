// shouldAnimateManager.js
// -*- mode: js; js-indent-level: 4; indent-tabs-mode: nil -*-
//
// Ported from Kevin Langman's CinnamonBurnMyWindows@klangman (same file,
// same license) so dock@brahim can suppress Cinnamon's own default
// minimize/unminimize animation for a single, specific window transition
// and substitute its own effect (see windowEffects.js). Copied verbatim
// except for one fix: the original file declared `class
// ShouldAnimateManager {...}` and `const Events = {...}` at module scope
// with no `var`, which GJS's legacy imports system does NOT expose as
// module properties (only top-level `var`/`function` declarations are -
// see shared.js's own comment on this pattern, and every other sibling
// file in this codebase, e.g. `var DOCK_SETTINGS_KEYMAP = [...]` in
// settingsStore.js). Re-declared both as `var` here so
// `imports.shouldAnimateManager.ShouldAnimateManager` and `.Events` /
// `.RUN_ORIGINAL_FUNCTION` actually resolve from windowEffects.js.
//
// Coordinates with any OTHER extension doing the same thing (e.g. a real
// install of CinnamonBurnMyWindows itself) via the shared
// `Main.wm._shouldAnimateManager` array - if that extension already
// claims the Minimize/Unminimize events, connect() below returns its
// uuid instead of null and windowEffects.js logs a warning rather than
// fighting over the same monkey-patched function.

const Main = imports.ui.main;
const Meta = imports.gi.Meta;

var Events = {
   Minimize:      1,
   Unminimize:    2,
   MapWindow:     4,
   DestroyWindow: 8
}

var RUN_ORIGINAL_FUNCTION = 2

var ShouldAnimateManager = class ShouldAnimateManager {

   constructor(uuid) {
      this._uuid = uuid;
   }

   connect(event, handler) {
      if (Main.wm._shouldAnimateManager) {
         for (let i=0 ; i<Main.wm._shouldAnimateManager.length ; i++) {
            if ((Main.wm._shouldAnimateManager[i].event & event) != 0) {
               return Main.wm._shouldAnimateManager[i].owner;
            }
         }
         log( `Adding new ShouldAnimateManager handler for ${this._uuid} events ${event}` );
         Main.wm._shouldAnimateManager.push( {event: event, handler: handler, owner: this._uuid, override: this.handler} );
      } else {
         log( `Installed ShouldAnimateManager handler for ${this._uuid} events ${event}` );
         Main.wm._shouldAnimateManager = [ {event: event, handler: handler, owner: this._uuid, override: this.handler} ];
         Main.wm._shouldAnimateManager_Original_Function = Main.wm._shouldAnimate;
         Main.wm._shouldAnimate = this.handler;
      }
      return null;
   }

   disconnect(event=null) {
      if (!Main.wm._shouldAnimateManager) return;
      for (let i=0 ; i<Main.wm._shouldAnimateManager.length ; i++) {
         if (Main.wm._shouldAnimateManager[i].owner == this._uuid && (!event || event == Main.wm._shouldAnimateManager[i].event)) {
            Main.wm._shouldAnimateManager.splice( i, 1 );
            i--; // We removed an entry so 'i' needs to be decremented so we don't skip over an entry!
            // Setup a new _shouldAnimate override or restore the original if there are no manager entries left.
            if (Main.wm._shouldAnimateManager.length === 0) {
               log( `Removing the last ShouldAnimateManager entry (for ${this._uuid}), reinstalling the original handler function` );
               Main.wm._shouldAnimate = Main.wm._shouldAnimateManager_Original_Function;
               Main.wm._shouldAnimateManager_Original_Function = null;
               Main.wm._shouldAnimateManager = null;
               return;
            } else {
               log( `Removing the ShouldAnimateManager handler for ${this._uuid} and installing the override provided by ${Main.wm._shouldAnimateManager[0].owner}` );
               Main.wm._shouldAnimate = Main.wm._shouldAnimateManager[0].override;
            }
         }
      }
   }

   handler(actor, types) {
      if (actor) {
         const isNormalWindow = actor.meta_window.window_type == Meta.WindowType.NORMAL;
         const isDialogWindow = actor.meta_window.window_type == Meta.WindowType.MODAL_DIALOG || actor.meta_window.window_type == Meta.WindowType.DIALOG;

         if (isNormalWindow || isDialogWindow) {
            let stack = (new Error()).stack;
            let event  = (stack.includes('_minimizeWindow@'  )) ? Events.Minimize      : 0;
            event     += (stack.includes('_unminimizeWindow@')) ? Events.Unminimize    : 0;
            event     += (stack.includes('_mapWindow@'       )) ? Events.MapWindow     : 0;
            event     += (stack.includes('_destroyWindow@'   )) ? Events.DestroyWindow : 0;

            for (let i=0 ; i<Main.wm._shouldAnimateManager.length ; i++) {
               if (event && event === (Main.wm._shouldAnimateManager[i].event & event)) {
                  let ret = Main.wm._shouldAnimateManager[i].handler(actor, types, event);
                  if (ret != RUN_ORIGINAL_FUNCTION) {
                     return ret;
                  }
               }
            }
         }
      }
      return Main.wm._shouldAnimateManager_Original_Function.apply(this, [actor, types]);
   }

}
