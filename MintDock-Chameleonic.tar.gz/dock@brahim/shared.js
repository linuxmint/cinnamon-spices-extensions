// -*- mode: js; js-indent-level: 4; indent-tabs-mode: nil -*-
//
// Small mutable state container shared across dock@brahim's split-out
// files (utils.js, settingsStore.js, launchpad.js, mediaDocklet.js,
// dock.js). Plain `var` bindings so that other files can both read AND
// write through the SAME live object (`Shared.EXTENSION_DIR = ...` from
// extension.js's init() is visible to everyone else that reads
// `Shared.EXTENSION_DIR` afterwards).
//
// Also hosts requireSibling(), the one place that does the
// searchPath-swap dance (same trick extension.js already used for
// coverflowSwitcher.js) needed to `imports.foo` a same-directory sibling
// file. Business-logic files use this - instead of importing each other
// directly with a top-level `const` - to sidestep circular imports
// between launchpad.js / dock.js / mediaDocklet.js (Launchpad and
// StandaloneDock reference each other; MediaControlsDocklet references
// StandaloneDock). Calling requireSibling() lazily, inside a function
// body rather than at module top-level, is safe because by the time any
// of those functions actually run, extension.js has already loaded all
// sibling files once, so the result is just a cheap cache lookup.

var UUID = "dock@brahim";

// The only supported mode going forward - StandaloneDock (an
// independent floating dock widget) rather than the older "center an
// existing Cinnamon panel" mode. Kept as a flag (rather than deleting
// every check of it) because a few call sites still branch on it.
var STANDALONE_DOCK_MODE = true;

// Set once in extension.js's init().
var EXTENSION_DIR = "";

// Set once in extension.js's enable(); cleared in disable().
var globalSettings = null;

function requireSibling(name) {
    let oldSearchPath = imports.searchPath.slice();
    imports.searchPath = [EXTENSION_DIR];
    let mod = imports[name];
    imports.searchPath = oldSearchPath;
    return mod;
}
