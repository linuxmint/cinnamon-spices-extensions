// mediaDocklet.js
// -*- mode: js; js-indent-level: 4; indent-tabs-mode: nil -*-

const Clutter = imports.gi.Clutter;
const GLib = imports.gi.GLib;
const GdkPixbuf = imports.gi.GdkPixbuf;
const Gio = imports.gi.Gio;
const Interfaces = imports.misc.interfaces;
const Pango = imports.gi.Pango;
const St = imports.gi.St;
const Lang = imports.lang;

const Shared = imports.shared;
const RadioIcons = Shared.requireSibling('radioIcons');

// ---- MPRIS D-Bus constants ----
const MPRIS_BUS_NAME_REGEX = /^org\.mpris\.MediaPlayer2\./;
const MPRIS_ROOT_IFACE = 'org.mpris.MediaPlayer2';
const MPRIS_PLAYER_IFACE = 'org.mpris.MediaPlayer2.Player';
const MPRIS_PATH = '/org/mpris/MediaPlayer2';

// Lazy accessor for the sibling dock.js module
function _dock() {
    return Shared.requireSibling('dock').StandaloneDock;
}

// ---- DockMediaPlayer class (unchanged) ----
class DockMediaPlayer {
    constructor(busName, onChanged) {
        this.busName = busName;
        this.identity = busName;
        this.mediaServer = null;
        this.mediaServerPlayer = null;
        this.prop = null;
        this.propChangeId = null;
        this.isPlaying = false;
        this.songArtist = "";
        this.songTitle = "";
        this.artUrl = "";
        this._ready = false;
        this._onChanged = onChanged || function() {};
        this._initDBus();
    }

    _initDBus() {
        Interfaces.getDBusProxyWithOwnerAsync(MPRIS_ROOT_IFACE, this.busName, (proxy, error) => {
            if (error) { return; }
            this.mediaServer = proxy;
            try { this.identity = proxy.Identity || this.busName; } catch(e) {}
            this._onChanged();
        });

        Interfaces.getDBusProxyWithOwnerAsync(MPRIS_PLAYER_IFACE, this.busName, (proxy, error) => {
            if (error) { return; }
            this.mediaServerPlayer = proxy;
            this._setStatus(proxy.PlaybackStatus);
            this._setMetadata(proxy.Metadata);
            this._ready = true;
            this._onChanged();
        });

        Interfaces.getDBusPropertiesAsync(this.busName, MPRIS_PATH, (proxy, error) => {
            if (error) { return; }
            this.prop = proxy;
            this.propChangeId = this.prop.connectSignal('PropertiesChanged', (proxy, sender, [iface, props]) => {
                if (props.PlaybackStatus) { this._setStatus(props.PlaybackStatus.unpack()); }
                if (props.Metadata) { this._setMetadata(props.Metadata.deep_unpack()); }
                this._onChanged();
            });
        });
    }

    _setStatus(status) {
        if (!status) return;
        this.isPlaying = (status === "Playing");
    }

    _setMetadata(metadata) {
        if (!metadata) return;

        this.songArtist = "";
        if (metadata['xesam:artist']) {
            try {
                switch (metadata['xesam:artist'].get_type_string()) {
                    case 's':
                        this.songArtist = metadata['xesam:artist'].unpack();
                        break;
                    case 'as':
                        this.songArtist = metadata['xesam:artist'].deep_unpack().join(", ");
                        break;
                }
            } catch(e) {}
        }

        this.songTitle = "";
        if (metadata['xesam:title']) {
            try { this.songTitle = metadata['xesam:title'].unpack(); } catch(e) {}
        }

        this.artUrl = "";
        if (metadata['mpris:artUrl']) {
            try { this.artUrl = metadata['mpris:artUrl'].unpack(); } catch(e) {}
        }
    }

    destroy() {
        if (this.prop && this.propChangeId) {
            try { this.prop.disconnectSignal(this.propChangeId); } catch(e) {}
            this.propChangeId = null;
        }
    }
}

// ---- Album art resolver/cache ----
const DockAlbumArt = {
    _cacheDir: null,

    _ensureCacheDir: function() {
        if (DockAlbumArt._cacheDir) return DockAlbumArt._cacheDir;
        let dir = GLib.build_filenamev([GLib.get_user_cache_dir(), "dock@brahim", "albumart"]);
        try {
            let dirFile = Gio.File.new_for_path(dir);
            if (!dirFile.query_exists(null)) {
                dirFile.make_directory_with_parents(null);
            }
        } catch(e) {
            global.logError("dock@brahim: media docklet: failed to create art cache dir: " + e);
        }
        DockAlbumArt._cacheDir = dir;
        return dir;
    },

    resolve: function(url, callback) {
        if (!url) { callback(null); return; }

        if (url.indexOf("file://") === 0) {
            try {
                callback(Gio.File.new_for_uri(url).get_path());
            } catch(e) {
                callback(null);
            }
            return;
        }

        if (url.indexOf("http://") !== 0 && url.indexOf("https://") !== 0) {
            callback(null);
            return;
        }

        let dir = DockAlbumArt._ensureCacheDir();
        let hash = GLib.compute_checksum_for_string(GLib.ChecksumType.MD5, url, -1);
        let destPath = GLib.build_filenamev([dir, hash + ".img"]);
        let destFile = Gio.File.new_for_path(destPath);

        if (destFile.query_exists(null)) {
            callback(destPath);
            return;
        }

        try {
            let srcFile = Gio.File.new_for_uri(url);
            srcFile.copy_async(destFile, Gio.FileCopyFlags.OVERWRITE, GLib.PRIORITY_DEFAULT, null, null,
                (srcObj, result) => {
                    try {
                        srcObj.copy_finish(result);
                        callback(destPath);
                    } catch(e) {
                        callback(null);
                    }
                });
        } catch(e) {
            callback(null);
        }
    },

    getDominantColor: function(path, callback) {
        if (!path) { callback(null); return; }
        try {
            let pixbuf = GdkPixbuf.Pixbuf.new_from_file(path);
            let tiny = pixbuf.scale_simple(1, 1, GdkPixbuf.InterpType.BILINEAR);
            if (!tiny) { callback(null); return; }
            let pixels = tiny.get_pixels();
            callback({ r: pixels[0], g: pixels[1], b: pixels[2] });
        } catch(e) {
            callback(null);
        }
    }
};

// ---- MediaControlsDocklet (exposing DockAlbumArt) ----
var MediaControlsDocklet = {
    _dbus: null,
    _ownerChangedId: null,
    _players: {},
    _activeName: null,
    widget: null,
    _playPauseButton: null,
    _playPauseIcon: null,
    _builtIconSize: 0,
    _builtArtSize: 0,
    _artBin: null,
    _artIcon: null,
    _artBaseStyle: "",
    _lastArtUrl: null,
    _lastArtPath: null,
    _titleLabel: null,
    _buttonsRow: null,

    // Expose the album-art helper so dock.js can use it for chameleonic tint
    DockAlbumArt: DockAlbumArt,

    enable: function() {
        MediaControlsDocklet._players = {};
        MediaControlsDocklet._activeName = null;

        Interfaces.getDBusAsync((proxy, error) => {
            if (error) {
                global.logError("dock@brahim: media docklet: failed to get DBus proxy: " + error);
                return;
            }
            MediaControlsDocklet._dbus = proxy;

            proxy.ListNamesRemote((names) => {
                for (let n in names[0]) {
                    let name = names[0][n];
                    if (MPRIS_BUS_NAME_REGEX.test(name)) {
                        MediaControlsDocklet._addPlayer(name);
                    }
                }
            });

            MediaControlsDocklet._ownerChangedId = proxy.connectSignal('NameOwnerChanged',
                (proxy, sender, [name, oldOwner, newOwner]) => {
                    if (!MPRIS_BUS_NAME_REGEX.test(name)) return;
                    if (newOwner && !oldOwner) {
                        MediaControlsDocklet._addPlayer(name);
                    } else if (oldOwner && !newOwner) {
                        MediaControlsDocklet._removePlayer(name);
                    }
                }
            );
        });
    },

    disable: function() {
        for (let name in MediaControlsDocklet._players) {
            try { MediaControlsDocklet._players[name].destroy(); } catch(e) {}
        }
        MediaControlsDocklet._players = {};
        MediaControlsDocklet._activeName = null;

        if (MediaControlsDocklet._dbus && MediaControlsDocklet._ownerChangedId) {
            try { MediaControlsDocklet._dbus.disconnectSignal(MediaControlsDocklet._ownerChangedId); } catch(e) {}
        }
        MediaControlsDocklet._ownerChangedId = null;
        MediaControlsDocklet._dbus = null;

        if (MediaControlsDocklet.widget) {
            try { MediaControlsDocklet.widget.destroy(); } catch(e) {}
        }
        MediaControlsDocklet.widget = null;
        MediaControlsDocklet._playPauseButton = null;
        MediaControlsDocklet._playPauseIcon = null;
        MediaControlsDocklet._builtIconSize = 0;
        MediaControlsDocklet._builtArtSize = 0;
        MediaControlsDocklet._artBin = null;
        MediaControlsDocklet._artIcon = null;
        MediaControlsDocklet._artBaseStyle = "";
        MediaControlsDocklet._lastArtUrl = null;
        MediaControlsDocklet._lastArtPath = null;
        MediaControlsDocklet._titleLabel = null;
        MediaControlsDocklet._buttonsRow = null;
    },

    _addPlayer: function(name) {
        if (MediaControlsDocklet._players[name]) return;

        let hadNone = (MediaControlsDocklet._activeName === null);

        let player = new DockMediaPlayer(name, () => {
            MediaControlsDocklet._updateWidget();
        });
        MediaControlsDocklet._players[name] = player;

        if (hadNone) {
            MediaControlsDocklet._activeName = name;
        }

        MediaControlsDocklet._notifyDockOfListChange();
    },

    _removePlayer: function(name) {
        let player = MediaControlsDocklet._players[name];
        if (!player) return;

        try { player.destroy(); } catch(e) {}
        delete MediaControlsDocklet._players[name];

        if (MediaControlsDocklet._activeName === name) {
            let remaining = Object.keys(MediaControlsDocklet._players);
            MediaControlsDocklet._activeName = remaining.length ? remaining[remaining.length - 1] : null;
        }

        MediaControlsDocklet._notifyDockOfListChange();
    },

    _notifyDockOfListChange: function() {
        try { _dock().refresh(); } catch(e) {}
    },

    hasPlayer: function() {
        return !!MediaControlsDocklet._activeName && !!MediaControlsDocklet._players[MediaControlsDocklet._activeName];
    },

    _activePlayer: function() {
        return MediaControlsDocklet._activeName ? MediaControlsDocklet._players[MediaControlsDocklet._activeName] : null;
    },

    getTile: function() {
        let baseSize = _dock()._renderIconSize || _dock()._iconSize || 44;
        let desiredArtSize = Math.max(20, baseSize);
        let desiredIconSize = Math.max(10, Math.round(baseSize * 0.30));

        if (!MediaControlsDocklet.widget
            || MediaControlsDocklet._builtIconSize !== desiredIconSize
            || MediaControlsDocklet._builtArtSize !== desiredArtSize) {
            if (MediaControlsDocklet.widget) {
                try { MediaControlsDocklet.widget.destroy(); } catch(e) {}
            }
            MediaControlsDocklet.widget = MediaControlsDocklet._buildWidget(desiredArtSize, desiredIconSize);
            MediaControlsDocklet._builtIconSize = desiredIconSize;
            MediaControlsDocklet._builtArtSize = desiredArtSize;
            MediaControlsDocklet._lastArtUrl = null;
        }
        MediaControlsDocklet._updateWidget();
        return MediaControlsDocklet.widget;
    },

    _buildWidget: function(artSize, iconSize) {
        let pill = new St.BoxLayout({
            vertical: false,
            reactive: true,
            track_hover: true,
            style_class: "brahim-media-pill"
        });

        let artRadius = Math.round(artSize / 2);
        let artBaseStyle = "width: " + artSize + "px; height: " + artSize + "px; border-radius: " + artRadius + "px;";
        let artBin = new St.Bin({
            style_class: "brahim-media-art",
            style: artBaseStyle,
            reactive: false
        });
        MediaControlsDocklet._artBin = artBin;
        MediaControlsDocklet._artBaseStyle = artBaseStyle;

        MediaControlsDocklet._artIcon = new St.Icon({
            icon_name: "audio-x-generic-symbolic",
            icon_size: Math.max(10, Math.round(artSize * 0.5)),
            style_class: "brahim-media-art-placeholder-icon"
        });

        // Shown instead of the generic placeholder above whenever the
        // active player is CinemixRadio (see _updateArt) - the radio never
        // has real mpris:artUrl metadata, so it gets its own glyph rather
        // than falling back to the generic note icon.
        let radioIconSize = Math.max(10, Math.round(artSize * 0.5));
        MediaControlsDocklet._artRadioIcon = new St.DrawingArea({ style_class: "brahim-media-art-placeholder-icon" });
        MediaControlsDocklet._artRadioIcon.set_size(radioIconSize, radioIconSize);
        MediaControlsDocklet._artRadioIcon.connect("repaint", function(area) {
            let cr = area.get_context();
            let box = area.get_allocation_box();
            let W = box.x2 - box.x1, H = box.y2 - box.y1;
            if (W < 2 || H < 2) { cr.$dispose(); return; }
            RadioIcons.drawStationIcon(cr, W, H, "radio", 1, 1, 1, 0.55);
        });

        artBin.set_child(MediaControlsDocklet._artIcon);

        pill.add(artBin, { x_fill: false, y_fill: false, y_align: St.Align.MIDDLE });

        let column = new St.BoxLayout({
            vertical: true,
            style_class: "brahim-media-info-column"
        });

        let titleLabel = new St.Label({
            text: "",
            style_class: "brahim-media-title"
        });
        titleLabel.clutter_text.set_line_wrap(false);
        titleLabel.clutter_text.set_ellipsize(imports.gi.Pango.EllipsizeMode.END);
        MediaControlsDocklet._titleLabel = titleLabel;

        let buttonsRow = new St.BoxLayout({
            vertical: false,
            style_class: "brahim-media-buttons-row"
        });

        let makeButton = (iconName, action) => {
            let btn = new St.Button({
                style_class: "brahim-media-btn",
                reactive: true,
                track_hover: true,
                can_focus: true
            });
            let icon = new St.Icon({
                icon_name: iconName,
                icon_size: iconSize,
                style_class: "brahim-media-icon"
            });
            btn.set_child(icon);
            btn.connect("clicked", () => MediaControlsDocklet._sendAction(action));
            return btn;
        };

        let prevButton = makeButton("media-skip-backward-symbolic", "previous");
        let playPauseButton = makeButton("media-playback-start-symbolic", "playpause");
        let nextButton = makeButton("media-skip-forward-symbolic", "next");

        MediaControlsDocklet._playPauseButton = playPauseButton;
        MediaControlsDocklet._playPauseIcon = playPauseButton.get_child();

        buttonsRow.add(prevButton, { x_fill: false, y_fill: false, y_align: St.Align.MIDDLE });
        buttonsRow.add(playPauseButton, { x_fill: false, y_fill: false, y_align: St.Align.MIDDLE });
        buttonsRow.add(nextButton, { x_fill: false, y_fill: false, y_align: St.Align.MIDDLE });
        MediaControlsDocklet._buttonsRow = buttonsRow;

        let buttonWidth = iconSize + 12;
        let rowWidth = buttonWidth * 3;
        titleLabel.set_style("max-width: " + rowWidth + "px;");

        column.add(titleLabel, { x_fill: false, x_align: St.Align.START });
        column.add(buttonsRow, { x_fill: false, x_align: St.Align.START });

        pill.add(column, { x_fill: false, y_fill: false, y_align: St.Align.END });

        pill.connect("enter-event", () => {
            let text = MediaControlsDocklet._tooltipText();
            if (text) _dock()._scheduleTooltip(pill, text);
            _dock()._scheduleMediaPreview(pill);
            return Clutter.EVENT_PROPAGATE;
        });
        pill.connect("leave-event", () => {
            _dock()._cancelTooltip();
            _dock()._cancelMediaPreview();
            return Clutter.EVENT_PROPAGATE;
        });

        return pill;
    },

    _tooltipText: function() {
        let p = MediaControlsDocklet._activePlayer();
        if (!p) return "";
        let desc = p.songTitle || "";
        if (p.songArtist) desc += (desc ? " — " : "") + p.songArtist;
        return desc ? ((p.identity || "") + ": " + desc) : (p.identity || "");
    },

    _updateWidget: function() {
        if (!MediaControlsDocklet._playPauseIcon) return;
        let p = MediaControlsDocklet._activePlayer();
        MediaControlsDocklet._playPauseIcon.icon_name = (p && p.isPlaying)
            ? "media-playback-pause-symbolic"
            : "media-playback-start-symbolic";

        if (MediaControlsDocklet._titleLabel) {
            MediaControlsDocklet._titleLabel.text = p ? (p.songTitle || p.identity || "") : "";
        }

        MediaControlsDocklet._updateArt(p);
    },

    _updateArt: function(p) {
        if (!MediaControlsDocklet._artBin) return;
        let isRadio = !!(p && p.isRadio);
        let url = (p && p.artUrl) || "";
        let cacheKey = (isRadio ? "radio:" : "") + url;

        if (cacheKey === MediaControlsDocklet._lastArtUrl) return;
        MediaControlsDocklet._lastArtUrl = cacheKey;

        if (!url) {
            // No logo to try (radio station without a logoUrl, or a real
            // MPRIS player with no mpris:artUrl) - fall back to the
            // radio glyph or the generic note icon as appropriate.
            MediaControlsDocklet._setArtImage(null, isRadio);
            return;
        }

        DockAlbumArt.resolve(url, (path) => {
            if (MediaControlsDocklet._lastArtUrl !== cacheKey) return;
            // If the download/copy failed, path is null and _setArtImage
            // falls back to the appropriate placeholder glyph on its own.
            MediaControlsDocklet._setArtImage(path, isRadio);
        });
    },

    _setArtImage: function(path, isRadio) {
        if (!MediaControlsDocklet._artBin) return;
        MediaControlsDocklet._lastArtPath = path;
        let base = MediaControlsDocklet._artBaseStyle || "";
        if (path) {
            MediaControlsDocklet._artBin.set_child(null);
            MediaControlsDocklet._artBin.style = base + " background-image: url(\"file://" + path + "\"); background-size: cover;";
        } else {
            MediaControlsDocklet._artBin.style = base;
            let wantChild = isRadio ? MediaControlsDocklet._artRadioIcon : MediaControlsDocklet._artIcon;
            if (wantChild && wantChild.get_parent() !== MediaControlsDocklet._artBin) {
                MediaControlsDocklet._artBin.set_child(wantChild);
            }
        }
    },

    _sendAction: function(action) {
        let p = MediaControlsDocklet._activePlayer();
        if (!p) return;
        if (p.isRadio) {
            // The radio isn't a real MPRIS player - it's a single live
            // stream, so only play/pause (toggle) makes sense; previous/
            // next stay no-ops.
            if (action === "playpause") {
                try { Shared.requireSibling('radio').CinemixRadio._toggle(); } catch(e) {}
            }
            return;
        }
        if (!p.mediaServerPlayer) return;
        try {
            if (action === "previous") p.mediaServerPlayer.PreviousRemote();
            else if (action === "next") p.mediaServerPlayer.NextRemote();
            else if (action === "playpause") p.mediaServerPlayer.PlayPauseRemote();
        } catch(e) {
            global.logError("dock@brahim: media docklet: action '" + action + "' failed: " + e);
        }
    }
};
