// welcome.js
// -*- mode: js; js-indent-level: 4; indent-tabs-mode: nil -*-

const St = imports.gi.St;
const Clutter = imports.gi.Clutter;
const Main = imports.ui.main;
const Tweener = imports.ui.tweener;
const Mainloop = imports.mainloop;
const Gio = imports.gi.Gio;
const Meta = imports.gi.Meta;
const GLib = imports.gi.GLib;

const Shared = imports.shared;
const EndSessionDialogModule = imports.ui.endSessionDialog;

const LOG_PREFIX = '[welcome-screen@brahim]';

// macOS-style dynamic desktop hues
const PALETTE = [
    [28, 146, 210],   // macOS blue
    [95, 44, 130],    // deep purple
    [235, 51, 73],    // sunset red/pink
    [244, 92, 67],    // orange
    [17, 153, 142],   // teal/green
];
const SEGMENT_MS = 1200;
const PERSIST_MS = 8000;
const FADE_OUT_MS = 2500;
const CLICK_FADE_MS = 700;

let welcomeOverlay = null;
let goodbyeOverlay = null;
let colorTimerId = null;
let persistTimerId = null;
let goodbyeTimerId = null;
let startTime = 0;
let fading = false;
let goodbyeFading = false;
let sessionManagerId = 0;
let isEnabled = false;
let _origEndSessionOpen = null;
let _endSessionDialogClass = null;
let dockSlideCompleted = false;

function _log(msg) {
    global.log(`${LOG_PREFIX} ${msg}`);
}

function _lerp(a, b, t) {
    return Math.round(a + (b - a) * t);
}

let _tickCount = 0;

function _tickColor() {
    if (!welcomeOverlay && !goodbyeOverlay) {
        _log('brahim-welcome-debug: _tickColor self-stopping after ' + _tickCount + ' ticks (no overlay left)');
        colorTimerId = null;
        _tickCount = 0;
        // FIX: Use GLib.SOURCE_REMOVE constant
        return GLib.SOURCE_REMOVE;
    }

    _tickCount++;
    if (_tickCount === 1 || _tickCount % 60 === 0) {
        _log('brahim-welcome-debug: tick #' + _tickCount + ' colorTimerId=' + colorTimerId);
    }

    let elapsed = Date.now() - startTime;
    let total = PALETTE.length;
    let segIndex = Math.floor(elapsed / SEGMENT_MS) % total;
    let nextIndex = (segIndex + 1) % total;
    let frac = (elapsed % SEGMENT_MS) / SEGMENT_MS;
    let smoothFrac = frac * frac * (3 - 2 * frac);

    let c0 = PALETTE[segIndex];
    let c1 = PALETTE[nextIndex];

    let r = _lerp(c0[0], c1[0], smoothFrac);
    let g = _lerp(c0[1], c1[1], smoothFrac);
    let b = _lerp(c0[2], c1[2], smoothFrac);

    let colorString = `rgb(${r}, ${g}, ${b})`;

    if (welcomeOverlay) {
        welcomeOverlay.set_style(`background-color: ${colorString} !important;`);
    }
    if (goodbyeOverlay) {
        goodbyeOverlay.set_style(`background-color: ${colorString} !important;`);
    }

    // FIX: Use GLib.SOURCE_CONTINUE constant
    return GLib.SOURCE_CONTINUE;
}

function _buildWelcomeOverlay(monitor) {
    let overlay = new St.Bin({
        style_class: 'welcome-screen-overlay',
        style: 'background-color: rgb(28, 146, 210) !important;',
        reactive: true,
        can_focus: true,
        x: monitor.x,
        y: monitor.y,
        width: monitor.width,
        height: monitor.height
    });

    let box = new St.BoxLayout({
        vertical: true,
        x_align: Clutter.ActorAlign.CENTER,
        y_align: Clutter.ActorAlign.CENTER,
        x_expand: true,
        y_expand: true
    });

    let label = new St.Label({
        style_class: 'welcome-screen-label',
        style: 'font-size: 110px; font-weight: bold; color: #ffffff; '
             + 'text-align: center; text-shadow: 0 4px 24px rgba(0,0,0,0.45);',
        text: 'Welcome to Linux'
    });

    let hint = new St.Label({
        style_class: 'welcome-screen-hint',
        style: 'font-size: 24px; color: rgba(255,255,255,0.85); '
             + 'text-align: center; margin-top: 22px; '
             + 'text-shadow: 0 2px 12px rgba(0,0,0,0.4);',
        text: 'Click anywhere to continue'
    });

    box.add_child(label);
    box.add_child(hint);
    overlay.set_child(box);

    overlay.connect('button-press-event', () => {
        _startFadeOut(CLICK_FADE_MS);
        return Clutter.EVENT_STOP;
    });
    overlay.connect('key-press-event', () => {
        _startFadeOut(CLICK_FADE_MS);
        return Clutter.EVENT_STOP;
    });

    return overlay;
}

function _buildGoodbyeOverlay(monitor, message) {
    let overlay = new St.Bin({
        style_class: 'goodbye-screen-overlay',
        style: 'background-color: rgb(28, 146, 210) !important;',
        reactive: false,
        can_focus: false,
        x: monitor.x,
        y: monitor.y,
        width: monitor.width,
        height: monitor.height
    });

    let box = new St.BoxLayout({
        vertical: true,
        x_align: Clutter.ActorAlign.CENTER,
        y_align: Clutter.ActorAlign.CENTER,
        x_expand: true,
        y_expand: true
    });

    let label = new St.Label({
        style_class: 'goodbye-screen-label',
        style: 'font-size: 110px; font-weight: bold; color: #ffffff; '
             + 'text-align: center; text-shadow: 0 4px 24px rgba(0,0,0,0.45);',
        text: message || 'Goodbye'
    });

    let hint = new St.Label({
        style_class: 'goodbye-screen-hint',
        style: 'font-size: 24px; color: rgba(255,255,255,0.85); '
             + 'text-align: center; margin-top: 22px; '
             + 'text-shadow: 0 2px 12px rgba(0,0,0,0.4);',
        text: 'See you soon!'
    });

    box.add_child(label);
    box.add_child(hint);
    overlay.set_child(box);

    return overlay;
}

function _clearTimers() {
    if (colorTimerId) {
        _log('brahim-welcome-debug: clearing colorTimerId=' + colorTimerId);
        try { Mainloop.source_remove(colorTimerId); } catch(e) { _log('brahim-welcome-debug: colorTimerId remove failed: ' + e); }
        colorTimerId = null;
    }
    if (persistTimerId) {
        _log('brahim-welcome-debug: clearing persistTimerId=' + persistTimerId);
        try { Mainloop.source_remove(persistTimerId); } catch(e) { _log('brahim-welcome-debug: persistTimerId remove failed: ' + e); }
        persistTimerId = null;
    }
    if (goodbyeTimerId) {
        _log('brahim-welcome-debug: clearing goodbyeTimerId=' + goodbyeTimerId);
        try { Mainloop.source_remove(goodbyeTimerId); } catch(e) { _log('brahim-welcome-debug: goodbyeTimerId remove failed: ' + e); }
        goodbyeTimerId = null;
    }
}

function _hideDockAndPanels() {
    _log('Hiding dock and panels');
    // Deliberately opacity/reactive ONLY - never toggle .visible here. The
    // dock/panel actors are tracked by Cinnamon's layoutManager for
    // click-through input-region calculation, and toggling .visible
    // directly leaves that computed region stale for a while after
    // they're shown again - visually back, but not yet receiving input.
    // That's the dock/top-panel freeze after the welcome screen.
    try {
        let dock = Shared.requireSibling('dock').StandaloneDock;
        if (dock && dock.widget) {
            dock.widget.opacity = 0;
            dock.widget.reactive = false;
            _log('Dock hidden');
        }
    } catch(e) {
        _log('Could not hide dock: ' + e);
    }

    try {
        let panels = Main.panelManager ? Main.panelManager.panels : [];
        panels.forEach(function(panel) {
            if (panel && panel.actor) {
                panel.actor.opacity = 0;
                panel.actor.reactive = false;
                panel.actor._welcomeHidden = true;
            }
        });
    } catch(e) {}

    // Per Cinnamon's own js/ui/layout.js (_trackActor): chrome actors only
    // get their real click-input region recomputed on 'notify::visible' or
    // 'notify::allocation' - opacity/reactive changes are invisible to it.
    // Since we deliberately never touch .visible above, nothing tells
    // layoutManager the dock/panels just went non-interactive, so ask it
    // directly instead of relying on a signal that will never fire.
    try { Main.layoutManager._chrome.updateRegions(); } catch(e) {}
}

function _slideDockAndPanelsFromBottom() {
    if (dockSlideCompleted) {
        _log('Dock slide already completed');
        return;
    }
    
    _log('Sliding dock and panels from bottom');
    try {
        let monitor = Main.layoutManager.primaryMonitor;
        let slideDistance = monitor ? monitor.height : 200;
        
        let dock = Shared.requireSibling('dock').StandaloneDock;
        if (dock && dock.widget) {
            dock.widget.opacity = 255;
            dock.widget.reactive = true;
            dock.widget.translation_y = slideDistance;
            
            Tweener.addTween(dock.widget, {
                translation_y: 0,
                time: 0.8,
                transition: 'easeOutBack',
                onComplete: () => {
                    dockSlideCompleted = true;
                    _log('Dock slide complete');
                    // Same reasoning as _hideDockAndPanels: opacity/reactive
                    // flipping back on doesn't trigger layoutManager's own
                    // region recompute, so the dock stays visually back but
                    // un-clickable until something unrelated (hot corner,
                    // right-click) happens to trigger Cinnamon's own
                    // _windowsRestacked() path. Ask for the recompute
                    // directly instead of waiting on that.
                    try { Main.layoutManager._chrome.updateRegions(); } catch(e) {}
                }
            });
        }
        
        try {
            let panels = Main.panelManager ? Main.panelManager.panels : [];
            panels.forEach(function(panel) {
                if (panel && panel.actor && panel.actor._welcomeHidden) {
                    panel.actor.reactive = true;
                    panel.actor.opacity = 255;
                    panel.actor.translation_y = slideDistance;
                    Tweener.addTween(panel.actor, {
                        translation_y: 0,
                        time: 0.7,
                        transition: 'easeOutBack',
                        onComplete: () => {
                            panel.actor._welcomeHidden = false;
                            try { Main.layoutManager._chrome.updateRegions(); } catch(e) {}
                        }
                    });
                }
            });
        } catch(e) {}
    } catch(e) {
        _log('Could not slide: ' + e);
    }
}

function _startFadeOut(durationMs) {
    if (!welcomeOverlay || fading)
        return;

    fading = true;
    if (persistTimerId) {
        Mainloop.source_remove(persistTimerId);
        persistTimerId = null;
    }

    _log(`fading out over ${durationMs}ms`);

    Tweener.addTween(welcomeOverlay, {
        opacity: 0,
        time: durationMs / 1000,
        transition: 'easeInQuad',
        onComplete: () => {
            _clearTimers();
            if (welcomeOverlay) {
                Main.uiGroup.remove_actor(welcomeOverlay);
                welcomeOverlay.destroy();
                welcomeOverlay = null;
            }
            fading = false;
            _log('Welcome screen removed - sliding dock from bottom');
            _slideDockAndPanelsFromBottom();
        }
    });
}

function _startGoodbyeFadeOut(durationMs) {
    if (!goodbyeOverlay || goodbyeFading)
        return;

    goodbyeFading = true;
    if (goodbyeTimerId) {
        Mainloop.source_remove(goodbyeTimerId);
        goodbyeTimerId = null;
    }

    _log(`goodbye fading out over ${durationMs}ms`);

    Tweener.addTween(goodbyeOverlay, {
        opacity: 0,
        time: durationMs / 1000,
        transition: 'easeInQuad',
        onComplete: () => {
            if (goodbyeOverlay) {
                Main.uiGroup.remove_actor(goodbyeOverlay);
                goodbyeOverlay.destroy();
                goodbyeOverlay = null;
            }
            goodbyeFading = false;
            if (!welcomeOverlay && !goodbyeOverlay) {
                _clearTimers();
            }
        }
    });
}

function _showWelcomeScreen() {
    if (welcomeOverlay || !isEnabled)
        return;

    let monitor = Main.layoutManager.primaryMonitor;
    if (!monitor) {
        _log('No primary monitor available, retrying...');
        Mainloop.timeout_add(100, _showWelcomeScreen);
        return;
    }

    _log('Showing welcome screen');
    dockSlideCompleted = false;

    _hideDockAndPanels();

    welcomeOverlay = _buildWelcomeOverlay(monitor);
    welcomeOverlay.opacity = 0;
    fading = false;

    Main.uiGroup.add_actor(welcomeOverlay);
    welcomeOverlay.raise_top();

    if (colorTimerId) {
        try { Mainloop.source_remove(colorTimerId); } catch(e) {}
        colorTimerId = null;
    }
    startTime = Date.now();
    // FIX: Use GLib.timeout_add instead of Mainloop.timeout_add for the color timer
    // GLib.timeout_add expects a function that returns GLib.SOURCE_CONTINUE/REMOVE
    colorTimerId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 16, _tickColor);
    _log('brahim-welcome-debug: started colorTimerId=' + colorTimerId + ' (welcome via GLib)');

    Tweener.addTween(welcomeOverlay, {
        opacity: 255,
        time: 0.5,
        transition: 'easeOutQuad'
    });

    persistTimerId = Mainloop.timeout_add(PERSIST_MS, () => {
        persistTimerId = null;
        _startFadeOut(FADE_OUT_MS);
        return Mainloop.SOURCE_REMOVE;
    });
}

function _showGoodbyeScreen(message, mode, dialogInstance) {
    if (goodbyeOverlay)
        return;

    let monitor = Main.layoutManager.primaryMonitor;
    if (!monitor) {
        _log('No primary monitor for goodbye');
        return;
    }

    _log(`Showing goodbye screen: ${message}`);

    _hideDockAndPanels();

    if (welcomeOverlay) {
        Main.uiGroup.remove_actor(welcomeOverlay);
        welcomeOverlay.destroy();
        welcomeOverlay = null;
        fading = false;
    }

    goodbyeOverlay = _buildGoodbyeOverlay(monitor, message);
    goodbyeOverlay.opacity = 255;
    goodbyeFading = false;

    Main.uiGroup.add_actor(goodbyeOverlay);
    goodbyeOverlay.raise_top();

    if (colorTimerId) {
        try { Mainloop.source_remove(colorTimerId); } catch(e) {}
        colorTimerId = null;
    }
    startTime = Date.now();
    // FIX: Use GLib.timeout_add instead of Mainloop.timeout_add
    colorTimerId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 16, _tickColor);
    _log('brahim-welcome-debug: started colorTimerId=' + colorTimerId + ' (goodbye via GLib)');

    goodbyeTimerId = Mainloop.timeout_add(5000, () => {
        goodbyeTimerId = null;
        _startGoodbyeFadeOut(2000);
        // Complete the real session action now that the color-cycle
        // animation has had its moment - this replaces the click on the
        // real dialog's confirm button. `mode` is only passed by the
        // EndSessionDialog.open hook below; the Meta.Session 'logout'
        // signal handler calls this with no mode, since by that point a
        // real logout is already under way elsewhere and firing another
        // action here would be redundant.
        if (mode !== undefined) _confirmSessionEnd(mode, dialogInstance);
        return Mainloop.SOURCE_REMOVE;
    });
}

// Completes the session action by calling the exact same D-Bus method the
// real "Log Out"/"Shut Down"/"Restart" button would have called.
//
// Per the actual installed endSessionDialog.js: EndSessionDialog holds a
// plain Gio.DBusProxy (this._dialogProxy) to the real session manager, and
// its buttons just call LogoutRemote()/ShutdownRemote()/RestartRemote() on
// it directly - there's no confirmation signal to fake, we just need to
// call the same method ourselves. `mode` matches that file's own
// DialogMode enum: REBOOT: 0, SHUTDOWN: 1, LOGOUT: 2 - not the 0/1/2
// logout/shutdown/restart order this code originally assumed, which is
// why nothing happened before (that, plus open() taking no `type` arg at
// all - see the open() hook below).
// The radio docklet spawns mpv as a standalone process (see radio.js's
// _start()) precisely so it survives a Cinnamon restart - but that means
// nothing kills it on an actual logout/shutdown/reboot either, since
// those don't run through extension disable(). Call this on every real
// session-end path (not the "Restart Cinnamon" hook, which must keep
// letting the stream survive) so playback actually stops when the
// session does.
function _stopRadioForSessionEnd() {
    try {
        let CinemixRadio = Shared.requireSibling('radio').CinemixRadio;
        if (CinemixRadio) CinemixRadio._stop();
    } catch (e) {
        _log('Could not stop radio for session end: ' + e);
    }
}

function _confirmSessionEnd(mode, dialogInstance) {
    _stopRadioForSessionEnd();
    if (!dialogInstance || !dialogInstance._dialogProxy) {
        _log('brahim-welcome-debug: no _dialogProxy on dialog instance, falling back to cinnamon-session-quit');
        _spawnSessionAction(mode);
        return;
    }

    try {
        if (mode === 2) dialogInstance._dialogProxy.LogoutRemote();
        else if (mode === 1) dialogInstance._dialogProxy.ShutdownRemote();
        else if (mode === 0) dialogInstance._dialogProxy.RestartRemote();
        _log('brahim-welcome-debug: called dialogProxy remote action for mode ' + mode);
    } catch (e) {
        _log('dialogProxy remote action failed: ' + e);
        _spawnSessionAction(mode);
    }

    try { dialogInstance.close(); } catch (e) {}
}

// Fallback only - matches the real DialogMode enum too (0=restart,
// 1=shutdown, 2=logout), used only if _dialogProxy wasn't available above.
function _spawnSessionAction(mode) {
    let cmd = 'cinnamon-session-quit --logout --no-prompt';
    if (mode === 1) cmd = 'cinnamon-session-quit --power-off --no-prompt';
    else if (mode === 0) cmd = 'cinnamon-session-quit --reboot --no-prompt';

    _log('brahim-welcome-debug: executing session action: ' + cmd);
    try {
        GLib.spawn_command_line_async(cmd);
    } catch (e) {
        _log('spawn of session action failed: ' + e);
    }
}

function _setupSessionHandlers() {
    try {
        let dialogClass = EndSessionDialogModule.EndSessionDialog;
        if (dialogClass && dialogClass.prototype && !_origEndSessionOpen) {
            _origEndSessionOpen = dialogClass.prototype.open;
            _endSessionDialogClass = dialogClass;
            dialogClass.prototype.open = function() {
                let dialogInstance = this;
                // The real EndSessionDialog.open() (inherited from
                // ModalDialog) takes no `type` argument - the action is
                // set on this._mode back in the constructor, using this
                // file's own DialogMode enum: REBOOT: 0, SHUTDOWN: 1,
                // LOGOUT: 2. Reading `type` off open()'s arguments (the
                // old approach) was always undefined, which is why
                // nothing downstream ever fired.
                let mode = dialogInstance._mode;
                try {
                    let message = 'Logging Out...';
                    if (mode === 1) message = 'Shutting Down...';
                    else if (mode === 0) message = 'Restarting...';
                    _log('EndSessionDialog.open() mode=' + mode + ' - ' + message);
                    _showGoodbyeScreen(message, mode, dialogInstance);
                } catch (e) {
                    _log('EndSessionDialog hook failed: ' + e);
                }
                // Deliberately NOT calling _origEndSessionOpen.apply() here.
                // That used to build the real confirmation dialog underneath
                // our goodbye overlay - invisible while the color-cycle
                // animation played, then revealed once it faded out, forcing
                // a second click on its own "Log Out" button. We now
                // complete the action ourselves from the goodbye timer in
                // _showGoodbyeScreen (see _confirmSessionEnd), so the real
                // dialog never needs to exist at all.
                return true;
            };
            _log('Patched EndSessionDialog.open');
        }
    } catch (e) {
        _log('Could not patch EndSessionDialog: ' + e);
    }

    try {
        let session = new Meta.Session();
        if (session) {
            session.connect('logout', () => {
                _log('Meta logout signal');
                _stopRadioForSessionEnd();
                _showGoodbyeScreen('Logging Out...');
            });
        }
    } catch (e) {}

    try {
        let origRestart = Main._restartCinnamon;
        if (origRestart) {
            Main._restartCinnamon = function() {
                _log('Cinnamon restart detected');
                _showGoodbyeScreen('Restarting Cinnamon...');
                Mainloop.timeout_add(100, () => {
                    origRestart.call(Main);
                    return Mainloop.SOURCE_REMOVE;
                });
            };
        }
    } catch (e) {
        _log('Could not hook restart: ' + e);
    }
}

var WelcomeScreen = {
    enable: function() {
        if (isEnabled) return;
        _log('enable() called');
        isEnabled = true;
        dockSlideCompleted = false;
        _setupSessionHandlers();
        
        _hideDockAndPanels();
        
        _showWelcomeScreen();
        
        let hideInterval = Mainloop.timeout_add(100, () => {
            if (welcomeOverlay && !dockSlideCompleted) {
                _hideDockAndPanels();
                return Mainloop.SOURCE_CONTINUE;
            }
            return Mainloop.SOURCE_REMOVE;
        });
    },

    disable: function() {
        _log('disable() called');
        isEnabled = false;
        fading = false;
        goodbyeFading = false;
        _clearTimers();
        
        if (_endSessionDialogClass && _origEndSessionOpen) {
            try { _endSessionDialogClass.prototype.open = _origEndSessionOpen; } catch(e) {}
            _origEndSessionOpen = null;
            _endSessionDialogClass = null;
        }
        
        if (welcomeOverlay) {
            Main.uiGroup.remove_actor(welcomeOverlay);
            welcomeOverlay.destroy();
            welcomeOverlay = null;
        }
        if (goodbyeOverlay) {
            Main.uiGroup.remove_actor(goodbyeOverlay);
            goodbyeOverlay.destroy();
            goodbyeOverlay = null;
        }
        
        _slideDockAndPanelsFromBottom();
    }
};