// launchpad.js
// -*- mode: js; js-indent-level: 4; indent-tabs-mode: nil -*-

const Main = imports.ui.main;
const Mainloop = imports.mainloop;
const Cinnamon = imports.gi.Cinnamon;
const Clutter = imports.gi.Clutter;
const Tweener = imports.ui.tweener;
const St = imports.gi.St;
const Gio = imports.gi.Gio;
const GLib = imports.gi.GLib;
const Util = imports.misc.util;
const Lang = imports.lang;

const Shared = imports.shared;
const Utils = imports.utils;
const SettingsStore = imports.settingsStore;

// Lazy accessor for the sibling dock.js module - see shared.js's
// requireSibling() doc comment for why this can't be a plain top-level
// `const StandaloneDock = imports.dock;` (dock.js imports this file
// right back, for its Launchpad tile / open-on-click / dockicon list).
function _dock() {
    return Shared.requireSibling('dock').StandaloneDock;
}

var Launchpad = {
    settings: null,
    _isOpen: false,
    _overlay: null,
    _allApps: [],
    _appsLoaded: false,
    _hotCorner: null,
    _modal: false,
    _escId: null,
    _captureId: null,
    _minimizedWindows: [],
    _contextMenu: null,
    _blurDirty: true,
    _hotkeyName: "dock-launchpad-open",
    _dockIcons: [],

    enable: function() {
        Launchpad.settings = SettingsStore.getLaunchpadSettings();
        Launchpad.settings = SettingsStore._seedDefaultFavoritesIfNeeded(Launchpad.settings);
        try { SettingsStore.saveLaunchpadSettings(Launchpad.settings); } catch(e) {}
        Launchpad._isOpen = false;
        Launchpad._allApps = [];
        Launchpad._appsLoaded = false;
        Launchpad._blurDirty = true;

        try {
            Launchpad._appInfoMonitor = Gio.AppInfoMonitor.get();
            Launchpad._appInfoMonitorId = Launchpad._appInfoMonitor.connect("changed", function() {
                Launchpad._appsLoaded = false;
            });
        } catch (e) {}

        try {
            Launchpad._bgSettings = new Gio.Settings({ schema_id: "org.cinnamon.desktop.background" });
            Launchpad._bgSettingsId = Launchpad._bgSettings.connect("changed::picture-uri", function() {
                Launchpad._blurDirty = true;
            });
            Launchpad._bgSettingsDarkId = Launchpad._bgSettings.connect("changed::picture-uri-dark", function() {
                Launchpad._blurDirty = true;
            });
        } catch (e) {}

        Launchpad._setupHotCorner();
        Launchpad._setupShortcut();

        if (!Shared.STANDALONE_DOCK_MODE) {
            Main.panelManager.panels.forEach(function(panel) {
                if (panelStates[panel.panelId]) Launchpad.attachDockIcon(panel);
            });
        }

        Mainloop.idle_add(function() {
            if (!Launchpad._appsLoaded) Launchpad._loadApps();
            return false;
        });
    },

    disable: function() {
        if (Launchpad._accentHoverTimeoutId) {
            Mainloop.source_remove(Launchpad._accentHoverTimeoutId);
            Launchpad._accentHoverTimeoutId = null;
        }
        if (Launchpad._searchDebounceId) {
            Mainloop.source_remove(Launchpad._searchDebounceId);
            Launchpad._searchDebounceId = null;
        }
        if (Launchpad._hotCorner) {
            Launchpad._hotCorner.disable();
            Launchpad._hotCorner = null;
        }
        try { Main.keybindingManager.removeHotKey(Launchpad._hotkeyName); } catch (e) {}

        if (Launchpad._appInfoMonitor && Launchpad._appInfoMonitorId) {
            Launchpad._appInfoMonitor.disconnect(Launchpad._appInfoMonitorId);
            Launchpad._appInfoMonitorId = null;
        }
        if (Launchpad._bgSettings) {
            if (Launchpad._bgSettingsId) Launchpad._bgSettings.disconnect(Launchpad._bgSettingsId);
            if (Launchpad._bgSettingsDarkId) Launchpad._bgSettings.disconnect(Launchpad._bgSettingsDarkId);
            Launchpad._bgSettings = null;
        }

        Launchpad.close();
        if (Launchpad._overlay) {
            Main.uiGroup.remove_actor(Launchpad._overlay);
            Launchpad._overlay.destroy();
            Launchpad._overlay = null;
        }

        Main.panelManager.panels.forEach(function(panel) {
            Launchpad.detachDockIcon(panel);
        });
    },

    applySettings: function() {
        Launchpad.settings = SettingsStore.getLaunchpadSettings();
        // A "Restore to default" in the settings UI wipes the hidden
        // launchpad-internal-state generic key (favoriteApps/
        // defaultFavoritesSeeded) back to {} without going through
        // enable(), so the seeding that normally happens there never
        // runs and the default pinned apps vanish until the dock is
        // reloaded. Re-seed here too whenever we detect that wipe, and
        // persist it immediately so it sticks.
        if (!Launchpad.settings.defaultFavoritesSeeded) {
            Launchpad.settings = SettingsStore._seedDefaultFavoritesIfNeeded(Launchpad.settings);
            try { SettingsStore.saveLaunchpadSettings(Launchpad.settings); } catch(e) {}
        }
        Launchpad._setupHotCorner();
        Launchpad._setupShortcut();
        if (Launchpad._overlay) {
            // Rebuilding the blur clone re-creates the full stack of
            // BlurEffect passes (BLUR_PASSES) on a screen-sized clone -
            // real work, not free. applySettings() fires on every single
            // dock/docklets/launchpad setting change (see extension.js's
            // "changed::" wiring), including ones that have nothing to do
            // with the background blur at all (icon size, hide delay,
            // tooltip toggle, etc). Only pay for the rebuild when the
            // blur is actually stale (wallpaper changed while closed) or
            // when frostedGlassEnabled itself was just toggled; otherwise
            // just re-apply geometry, which is cheap.
            let frostedNow = Launchpad.settings.frostedGlassEnabled;
            let frostedChanged = Launchpad._lastFrostedGlassEnabled !== undefined
                && Launchpad._lastFrostedGlassEnabled !== frostedNow;
            if (Launchpad._blurDirty || frostedChanged) {
                Launchpad._removeBlurBackground();
                Launchpad._addBlurBackground();
                Launchpad._blurDirty = false;
            }
            Launchpad._lastFrostedGlassEnabled = frostedNow;
            Launchpad._updateBlurGeometry();
        }
        if (Launchpad._isOpen && Launchpad._tintActor) {
            Launchpad._tintActor.remove_style_class_name("launchpad-dark");
            Launchpad._tintActor.remove_style_class_name("launchpad-light");
            Launchpad._tintActor.add_style_class_name(Launchpad._resolveIsDark() ? "launchpad-dark" : "launchpad-light");
            Launchpad._applyDockTint();
        }
        if (!Shared.STANDALONE_DOCK_MODE) {
            Main.panelManager.panels.forEach(function(panel) {
                if (panelStates[panel.panelId]) Launchpad.attachDockIcon(panel);
            });
        }
    },

    _setupHotCorner: function() {
        if (Launchpad._hotCorner) {
            Launchpad._hotCorner.disable();
            Launchpad._hotCorner = null;
        }
        if (Launchpad.settings.hotcornerEnabled) {
            Launchpad._hotCorner = new Utils.HotCorner(Launchpad.settings.hotcornerPosition, function() {
                Launchpad.toggle();
            });
            Launchpad._hotCorner.enable();
        }
    },

    _setupShortcut: function() {
        try { Main.keybindingManager.removeHotKey(Launchpad._hotkeyName); } catch (e) {}
        if (Launchpad.settings.openShortcut && Launchpad.settings.openShortcut !== "") {
            try {
                Main.keybindingManager.addHotKey(Launchpad._hotkeyName, Launchpad.settings.openShortcut, function() {
                    Launchpad.toggle();
                });
            } catch (e) {
                global.logError("Dock/Launchpad: failed to register shortcut '" + Launchpad.settings.openShortcut + "' - " + e);
            }
        }
    },

    attachDockIcon: function(panel) {
        if (!panel || !panel.actor) return;
        Launchpad.detachDockIcon(panel);
        if (!Launchpad.settings || !Launchpad.settings.showDockIcon) return;

        let box = panel._leftBox || panel._centerBox || panel._rightBox;
        if (!box) return;

        let panelHeight = Math.max(24, panel.actor.height || 28);
        let buttonSize = panelHeight - 4;
        let iconSize = buttonSize - 6;

        let icon;
        let bundledIconPath = Shared.EXTENSION_DIR + "/dock.png";
        if (Launchpad.settings.useCustomIcon && Launchpad.settings.panelIcon) {
            if (GLib.file_test(Launchpad.settings.panelIcon, GLib.FileTest.EXISTS)) {
                icon = new St.Icon({ gicon: Gio.icon_new_for_string(Launchpad.settings.panelIcon), icon_size: iconSize });
            } else {
                icon = new St.Icon({ icon_name: Launchpad.settings.panelIcon, icon_size: iconSize });
            }
        } else if (GLib.file_test(bundledIconPath, GLib.FileTest.EXISTS)) {
            icon = new St.Icon({ gicon: Gio.icon_new_for_string(bundledIconPath), icon_size: iconSize });
        } else {
            icon = new St.Icon({ icon_name: "view-grid-symbolic", icon_size: iconSize });
        }
        icon.x_align = Clutter.ActorAlign.CENTER;
        icon.y_align = Clutter.ActorAlign.CENTER;

        let content = new St.BoxLayout({ style: "spacing: 4px;" });
        content.add(icon, { y_fill: false, y_align: St.Align.MIDDLE, x_fill: false, x_align: St.Align.MIDDLE });
        if (Launchpad.settings.showAppletLabel) {
            content.add(new St.Label({
                text: Launchpad.settings.appletLabelText || "Launchpad",
                y_align: Clutter.ActorAlign.CENTER
            }), { y_fill: false, y_align: St.Align.MIDDLE });
        }

        let button = new St.Button({
            style_class: "launchpad-dock-button",
            style: "width: " + buttonSize + "px; height: " + buttonSize + "px;",
            reactive: true,
            can_focus: true,
            track_hover: true,
            child: content
        });
        content.x_align = Clutter.ActorAlign.CENTER;
        content.y_align = Clutter.ActorAlign.CENTER;
        button.y_align = Clutter.ActorAlign.CENTER;
        button.y_expand = false;
        button.x_expand = false;
        button.translation_x = -6;
        button.translation_y = -3;
        button._launchpadNoZoom = true;
        button.set_pivot_point(0.5, 0.85);
        button.connect("notify::hover", function() {
            Tweener.removeTweens(button);
            let targetScale = button.hover ? 1.12 : 1.0;
            Tweener.addTween(button, {
                scale_x: targetScale,
                scale_y: targetScale,
                time: 0.15,
                transition: "easeOutQuad"
            });
        });
        button.connect("clicked", function() {
            Launchpad.toggle();
        });

        try {
            box.insert_child_at_index(button, 0);
            panel._launchpadIconActor = button;
            Launchpad._dockIcons.push(button);
        } catch (e) {
            try { button.destroy(); } catch (e2) {}
        }
    },

    detachDockIcon: function(panel) {
        if (!panel || !panel._launchpadIconActor) return;
        try {
            let actor = panel._launchpadIconActor;
            let parent = actor.get_parent();
            if (parent) parent.remove_child(actor);
            actor.destroy();
        } catch (e) {}
        let idx = Launchpad._dockIcons.indexOf(panel._launchpadIconActor);
        if (idx !== -1) Launchpad._dockIcons.splice(idx, 1);
        panel._launchpadIconActor = null;
    },

    _isDescendantOfAny: function(actor, ancestors) {
        for (let i = 0; i < ancestors.length; i++) {
            if (Launchpad._isDescendantOf(actor, ancestors[i])) return true;
        }
        return false;
    },

    _isDescendantOf: function(actor, ancestor) {
        let a = actor;
        while (a) {
            if (a === ancestor) return true;
            a = a.get_parent();
        }
        return false;
    },

    // Closes Launchpad on a click that lands directly on `actor` itself -
    // i.e. genuine empty space - rather than on a reactive child (a tile,
    // the search entry, a pager dot, etc.), since those all stop their
    // own button-press-event before it bubbles up here.
    _wireEmptySpaceDismiss: function(actor) {
        actor.connect("button-press-event", function(a, event) {
            if (event.get_source() !== actor) return Clutter.EVENT_PROPAGATE;
            Launchpad.close();
            return Clutter.EVENT_STOP;
        });
    },

    _applyPanelSafeGeometry: function() {
        let m = Main.layoutManager.primaryMonitor;
        let contentX = m.x, contentY = m.y, contentW = m.width, contentH = m.height;

        try {
            let panels = Main.panelManager ? Main.panelManager.panels : [];
            panels.forEach(function(panel) {
                if (!panel || !panel.actor || !panel.actor.visible) return;
                let pos = (panel.panelPosition !== undefined) ? panel.panelPosition
                        : (panel.bottomPosition ? 1 : 0);
                let ph = Math.max(0, panel.actor.height);
                if (ph < 4) return;
                if (pos === 0 || pos === "top") {
                    contentY = m.y + ph;
                    contentH = m.height - ph;
                } else if (pos === 1 || pos === "bottom") {
                    contentH = Math.min(contentH, m.height - ph - (contentY - m.y));
                }
            });
        } catch (e) {}

        // The standalone dock isn't a Cinnamon panel, so it never showed up
        // in the panelManager loop above and the grid could size itself
        // right underneath it. It always sits flush against the bottom of
        // the monitor (see StandaloneDock._reposition), so reserve exactly
        // its height plus its floating-mode gap, plus a little breathing
        // room so the grid visibly ends above it rather than touching it.
        try {
            if (Shared.STANDALONE_DOCK_MODE && _dock().widget) {
                let dockSettings = SettingsStore.getDockSettings();
                let dockHeight = _dock()._maxHeight || 64;
                let dockGap = dockSettings.panelMode ? 0 : 8;
                let dockReserved = dockHeight + dockGap + 16;
                contentH = Math.min(contentH, m.height - dockReserved - (contentY - m.y));
            }
        } catch (e) {}

        contentH = Math.max(200, contentH);

        let bgX = m.x, bgY = m.y, bgW = m.width, bgH = m.height;

        Launchpad._contentX = contentX;
        Launchpad._contentY = contentY;
        Launchpad._contentW = contentW;
        Launchpad._contentH = contentH;
        Launchpad._bgX = bgX;
        Launchpad._bgY = bgY;
        Launchpad._bgW = bgW;
        Launchpad._bgH = bgH;

        Launchpad._overlay.set_position(bgX, bgY);
        Launchpad._overlay.set_size(bgW, bgH);

        let relX = contentX - bgX;
        let relY = contentY - bgY;
        Launchpad._overlayContent.set_position(relX, relY);
        Launchpad._overlayContent.set_size(contentW, contentH);

        if (Launchpad._tintActor) {
            Launchpad._tintActor.set_position(0, 0);
            Launchpad._tintActor.set_size(bgW, bgH);
        }

        Launchpad._updateBlurGeometry();
    },

    _raisePanelsAboveOverlay: function() {
        try {
            let panels = Main.panelManager ? Main.panelManager.panels : [];
            panels.forEach(function(panel) {
                if (!panel || !panel.actor) return;
                if (!panel._dockPrevSibling) {
                    panel._dockPrevSibling = panel.actor.get_next_sibling();
                }
                panel.actor.raise_top();
            });
        } catch (e) {}

        try {
            if (Shared.STANDALONE_DOCK_MODE && _dock().widget) {
                _dock().widget.raise_top();
            }
        } catch (e) {}
    },

    _restorePanelStacking: function() {
        try {
            let panels = Main.panelManager ? Main.panelManager.panels : [];
            panels.forEach(function(panel) {
                if (!panel || !panel.actor) return;
                let sibling = panel._dockPrevSibling;
                panel._dockPrevSibling = null;
                if (!sibling) return;
                let parent = panel.actor.get_parent();
                if (parent && sibling.get_parent && sibling.get_parent() === parent) {
                    parent.set_child_below_sibling(panel.actor, sibling);
                }
            });
        } catch (e) {}
    },

    // Uses the dock's actual rendered background color (same color + same
    // transparency it shows itself), not a separately invented alpha, so
    // the launchpad genuinely matches the dock instead of just being
    // vaguely tinted toward it.
    _applyDockTint: function() {
        if (!Launchpad._tintActor) return;
        try {
            let dockSettings = SettingsStore.getDockSettings();
            let transparency = (dockSettings.transparency !== undefined ? dockSettings.transparency : 30) / 100.0;
            let dockColor = dockSettings.dockColor || "rgba(245, 255, 255, 1.0)";
            Launchpad._tintActor.set_style("background-color: " + Utils.colorWithAlpha(dockColor, transparency) + " !important;");
        } catch(e) {}
    },

    // Driven by StandaloneDock._startAppAccent()/_endAppAccent() (dock.js)
    // when a dock icon is hovered while the Launchpad is open - eases
    // _tintActor toward the hovered app's icon accent color, then back to
    // the normal dock-matched tint on leave. No-ops if the Launchpad isn't
    // open or has no accent to clear, so the dock can call these
    // unconditionally without checking Launchpad's open state itself.
    _accentTweenState: { t: 0 },
    _accentRgb: null,
    _accentHoverApp: null,
    _accentHoverTimeoutId: null,

    applyAccent: function(rgb) {
        if (!Launchpad._isOpen || !Launchpad._tintActor || !rgb) return;
        Launchpad._accentRgb = rgb;
        Tweener.removeTweens(Launchpad._accentTweenState);
        Tweener.addTween(Launchpad._accentTweenState, {
            t: 1,
            time: 0.28,
            transition: "easeOutQuad",
            onUpdate: function() { Launchpad._applyAccentBlend(Launchpad._accentTweenState.t); }
        });
    },

    clearAccent: function() {
        if (!Launchpad._tintActor || !Launchpad._accentRgb) return;
        Tweener.removeTweens(Launchpad._accentTweenState);
        Tweener.addTween(Launchpad._accentTweenState, {
            t: 0,
            time: 0.35,
            transition: "easeOutQuad",
            onUpdate: function() { Launchpad._applyAccentBlend(Launchpad._accentTweenState.t); },
            onComplete: function() {
                Launchpad._accentRgb = null;
                Launchpad._applyDockTint();
            }
        });
    },

    _applyAccentBlend: function(t) {
        if (!Launchpad._tintActor) return;
        if (!Launchpad._accentRgb || t <= 0) {
            Launchpad._applyDockTint();
            return;
        }
        try {
            let dockSettings = SettingsStore.getDockSettings();
            let transparency = (dockSettings.transparency !== undefined ? dockSettings.transparency : 30) / 100.0;
            let dockColor = dockSettings.dockColor || "rgba(245, 255, 255, 1.0)";
            let base = Utils.colorWithAlpha(dockColor, transparency);
            let blended = Utils.blendTowardAccent(base, Launchpad._accentRgb, t, 0.55, 0.55);
            Launchpad._tintActor.set_style("background-color: " + blended + " !important;");
        } catch(e) {}
    },

    _resolveIsDark: function() {
        if (Launchpad.settings.themeMode === "dark") return true;
        if (Launchpad.settings.themeMode === "light") return false;
        try {
            let ifaceSettings = new Gio.Settings({ schema_id: "org.cinnamon.desktop.interface" });
            let gtkTheme = ifaceSettings.get_string("gtk-theme") || "";
            return gtkTheme.toLowerCase().indexOf("dark") !== -1;
        } catch (e) {
            return true;
        }
    },

    _removeBlurBackground: function() {
        if (Launchpad._blurClone) {
            Launchpad._blurClone.destroy();
            Launchpad._blurClone = null;
        }
    },

    _addBlurBackground: function() {
        Launchpad._blurClone = null;
        try {
            if (Launchpad.settings && Launchpad.settings.frostedGlassEnabled === false) return;
            if (typeof Clutter.BlurEffect !== "function") return;

            let bgGroup = Main.layoutManager && Main.layoutManager._backgroundGroup;
            let bgSource = bgGroup || global.background_actor || null;
            if (!bgSource) return;

            let clone = new Clutter.Clone({ source: bgSource, reactive: false });
            const BLUR_PASSES = 50;
            for (let i = 0; i < BLUR_PASSES; i++) {
                clone.add_effect_with_name("blur" + i, new Clutter.BlurEffect());
            }
            Launchpad._overlay.insert_child_at_index(clone, 0);
            Launchpad._blurClone = clone;
        } catch (e) {
            Launchpad._blurClone = null;
        }
    },

    _updateBlurGeometry: function() {
        if (!Launchpad._blurClone) return;
        try {
            Launchpad._blurClone.set_size(Launchpad._bgW, Launchpad._bgH);
            Launchpad._blurClone.set_position(0, 0);
            Launchpad._blurClone.remove_clip();
        } catch (e) {}
    },

    _buildOverlay: function() {
        let isDark = Launchpad._resolveIsDark();

        Launchpad._overlay = new St.Widget({
            layout_manager: new Clutter.FixedLayout(),
            reactive: true
        });

        Launchpad._tintActor = new St.BoxLayout({
            reactive: false,
            style_class: isDark ? "launchpad-dark" : "launchpad-light"
        });
        Launchpad._applyDockTint();

        Launchpad._overlayContent = new St.BoxLayout({
            vertical: true,
            reactive: true,
            style_class: "launchpad-overlay"
        });

        Launchpad._addBlurBackground();
        // Establish the change-detection baseline right now, at build time.
        // Without this, _lastFrostedGlassEnabled stays undefined until
        // applySettings() happens to run once while the overlay exists, so
        // the very first toggle of the checkbox after opening the Launchpad
        // fails the "!== undefined" guard in applySettings() and is
        // silently ignored (see applySettings() comment for detail).
        Launchpad._lastFrostedGlassEnabled = Launchpad.settings.frostedGlassEnabled;
        Launchpad._overlay.insert_child_at_index(Launchpad._tintActor, 1);
        Launchpad._overlay.add_child(Launchpad._overlayContent);

        Launchpad._overlayContent.set_pivot_point(0.5, 0.5);

        Launchpad._applyPanelSafeGeometry();

        Launchpad._wireEmptySpaceDismiss(Launchpad._overlay);
        Launchpad._wireEmptySpaceDismiss(Launchpad._overlayContent);

        let searchContainer = new St.BoxLayout({
            style_class: "launchpad-search-container",
            x_align: Clutter.ActorAlign.CENTER
        });
        let searchPill = new St.BoxLayout({
            style_class: "launchpad-search",
            reactive: true,
            track_hover: true
        });
        let searchIcon = new St.Icon({
            icon_name: "edit-find-symbolic",
            icon_size: 15,
            style_class: "launchpad-search-icon"
        });
        Launchpad._searchEntry = new St.Entry({
            style_class: "launchpad-search-entry",
            hint_text: _("Search"),
            can_focus: true,
            track_hover: true
        });
        Launchpad._searchEntry.set_width(140);
        searchPill.add(searchIcon, { x_fill: false, y_fill: false, y_align: St.Align.MIDDLE });
        searchPill.add(Launchpad._searchEntry, { x_fill: false, y_fill: false, x_align: St.Align.MIDDLE, y_align: St.Align.MIDDLE });
        searchContainer.add(searchPill, { x_fill: false, y_fill: false, x_align: St.Align.MIDDLE });
        Launchpad._overlayContent.add(searchContainer, { expand: false, x_fill: true, x_align: St.Align.MIDDLE });
        Launchpad._searchContainerActor = searchContainer;

        Launchpad._searchEntry.clutter_text.connect("text-changed", Launchpad._onSearchChanged);

        Launchpad._pagesBin = new St.Bin({
            style_class: "launchpad-pages",
            reactive: true,
            x_fill: true,
            y_fill: true
        });
        Launchpad._pagesBin.connect("scroll-event", function(actor, event) {
            let direction = event.get_scroll_direction();
            if (direction === Clutter.ScrollDirection.DOWN || direction === Clutter.ScrollDirection.RIGHT) {
                Launchpad._goToPage(Launchpad._currentPage + 1);
            } else if (direction === Clutter.ScrollDirection.UP || direction === Clutter.ScrollDirection.LEFT) {
                Launchpad._goToPage(Launchpad._currentPage - 1);
            }
            return Clutter.EVENT_STOP;
        });

        Launchpad._gridWrapper = new St.BoxLayout({
            vertical: true,
            style_class: "launchpad-grid",
            x_align: Clutter.ActorAlign.FILL
        });
        Launchpad._pagesBin.set_child(Launchpad._gridWrapper);

        Launchpad._gridLayout = new Clutter.GridLayout({
            orientation: Clutter.Orientation.HORIZONTAL,
            column_spacing: 32,
            row_spacing: 32
        });
        Launchpad._gridBox = new Clutter.Actor({ layout_manager: Launchpad._gridLayout });
        Launchpad._gridWrapper.add(Launchpad._gridBox, { expand: true, x_fill: false, y_fill: false, x_align: St.Align.MIDDLE, y_align: St.Align.MIDDLE });

        Launchpad._overlayContent.add(Launchpad._pagesBin, { expand: true, x_fill: true, y_fill: true });
        Launchpad._wireEmptySpaceDismiss(Launchpad._pagesBin);

        Launchpad._pagerBox = new St.BoxLayout({
            style_class: "launchpad-pager",
            x_align: Clutter.ActorAlign.CENTER
        });
        Launchpad._pagerBox.set_style("min-height: 16px; margin-top: 14px;");
        Launchpad._overlayContent.add(Launchpad._pagerBox, { expand: false, x_fill: true, x_align: St.Align.MIDDLE });

        Launchpad._pages = [];
        Launchpad._currentPage = 0;

        Main.uiGroup.add_actor(Launchpad._overlay);
        Launchpad._overlay.hide();
        Launchpad._overlay.opacity = 255;
    },

    toggle: function() {
        if (Launchpad._isOpen) Launchpad.close();
        else Launchpad.open();
    },

    open: function() {
        if (Launchpad._isOpen) return;
        Launchpad._isOpen = true;

        Launchpad._minimizedWindows = Utils.minimizeAllWindows();

        if (!Launchpad._overlay) Launchpad._buildOverlay();

        if (Launchpad._tintActor) {
            Launchpad._tintActor.remove_style_class_name("launchpad-dark");
            Launchpad._tintActor.remove_style_class_name("launchpad-light");
            Launchpad._tintActor.add_style_class_name(Launchpad._resolveIsDark() ? "launchpad-dark" : "launchpad-light");
            Launchpad._applyDockTint();
        }
        if (Launchpad._blurDirty || !Launchpad._blurClone) {
            Launchpad._removeBlurBackground();
            Launchpad._addBlurBackground();
            Launchpad._blurDirty = false;
        }
        Launchpad._applyPanelSafeGeometry();
        Launchpad._searchEntry.set_text("");
        Launchpad._currentPage = 0;

        Launchpad._overlay.show();
        Launchpad._overlay.raise_top();
        Launchpad._raisePanelsAboveOverlay();
        if (Launchpad._hotCorner) Launchpad._hotCorner.raiseTop();

        if (Shared.STANDALONE_DOCK_MODE) {
            try {
                if (SettingsStore.getDockSettings().intellihide) _dock()._concealDock();
            } catch(e) {}
        }

        if (Launchpad.settings.effectsEnabled) {
            Launchpad._overlay.opacity = 0;
            Tweener.addTween(Launchpad._overlay, { opacity: 255, time: 0.15, transition: "easeOutQuad" });
            Launchpad._overlayContent.scale_x = 0.9;
            Launchpad._overlayContent.scale_y = 0.9;
            Tweener.addTween(Launchpad._overlayContent, { scale_x: 1, scale_y: 1, time: 0.4, transition: "easeOutBack" });
        } else {
            Launchpad._overlay.opacity = 255;
            Launchpad._overlayContent.scale_x = 1;
            Launchpad._overlayContent.scale_y = 1;
        }

        if (Main.pushModal(Launchpad._overlay)) Launchpad._modal = true;

        if (!Launchpad._appsLoaded) Launchpad._loadApps();

        if (Launchpad.settings.effectsEnabled) {
            Mainloop.idle_add(function() {
                Launchpad._layoutApps(Launchpad._sortForDisplay(Launchpad._allApps));
                return false;
            });
        } else {
            Launchpad._layoutApps(Launchpad._sortForDisplay(Launchpad._allApps));
        }

        Launchpad._escId = global.stage.connect("key-press-event", function(actor, event) {
            if (event.get_key_symbol() === Clutter.KEY_Escape) {
                if (Launchpad._contextMenu) {
                    Launchpad._hideContextMenu();
                    return Clutter.EVENT_STOP;
                }
                Launchpad.close();
                return Clutter.EVENT_STOP;
            }
            return Clutter.EVENT_PROPAGATE;
        });

        // Handles page-switching keys, plus hiding the right-click context
        // menu on a click elsewhere while it's open. Dismissing Launchpad
        // itself on an empty-space click is wired directly on the
        // background/overlay/pages actors instead (_wireEmptySpaceDismiss),
        // since nothing is ever truly "outside" this full-screen modal
        // overlay for a capture-phase check to catch.
        Launchpad._captureId = global.stage.connect("captured-event", function(actor, event) {
            if (event.type() === Clutter.EventType.KEY_PRESS) {
                let sym = event.get_key_symbol();
                if (sym === Clutter.KEY_Right || sym === Clutter.KEY_Down) {
                    Launchpad._goToPage(Launchpad._currentPage + 1);
                    return Clutter.EVENT_STOP;
                } else if (sym === Clutter.KEY_Left || sym === Clutter.KEY_Up) {
                    Launchpad._goToPage(Launchpad._currentPage - 1);
                    return Clutter.EVENT_STOP;
                }
                return Clutter.EVENT_PROPAGATE;
            }
            if (event.type() !== Clutter.EventType.BUTTON_PRESS) return Clutter.EVENT_PROPAGATE;
            if (!Launchpad._contextMenu) return Clutter.EVENT_PROPAGATE;
            let src = event.get_source();
            if (src && Launchpad._isDescendantOf(src, Launchpad._contextMenu)) return Clutter.EVENT_PROPAGATE;
            Launchpad._hideContextMenu();
            return Clutter.EVENT_PROPAGATE;
        });

        global.stage.set_key_focus(Launchpad._searchEntry.clutter_text);
    },

    close: function() {
        if (!Launchpad._isOpen) return;
        Launchpad._isOpen = false;

        if (Launchpad._searchDebounceId) {
            Mainloop.source_remove(Launchpad._searchDebounceId);
            Launchpad._searchDebounceId = null;
        }
        Launchpad._hideContextMenu();
        Utils.restoreMinimizedWindows(Launchpad._minimizedWindows);
        Launchpad._minimizedWindows = [];

        if (Shared.STANDALONE_DOCK_MODE) {
            try {
                _dock()._revealDock();
            } catch(e) {}
        }

        if (Launchpad._escId) { global.stage.disconnect(Launchpad._escId); Launchpad._escId = null; }
        if (Launchpad._captureId) { global.stage.disconnect(Launchpad._captureId); Launchpad._captureId = null; }

        if (Launchpad._modal) { Main.popModal(Launchpad._overlay); Launchpad._modal = false; }

        let overlay = Launchpad._overlay;
        if (!overlay) return;

        if (Launchpad.settings.effectsEnabled) {
            Tweener.addTween(overlay, {
                opacity: 0,
                time: 0.12,
                transition: "easeInQuad",
                onComplete: function() {
                    overlay.hide();
                    Launchpad._restorePanelStacking();
                }
            });
            Tweener.addTween(Launchpad._overlayContent, {
                scale_x: 0.96,
                scale_y: 0.96,
                time: 0.12,
                transition: "easeInQuad",
                onComplete: function() {
                    Launchpad._overlayContent.scale_x = 1;
                    Launchpad._overlayContent.scale_y = 1;
                }
            });
        } else {
            overlay.hide();
            Launchpad._overlayContent.scale_x = 1;
            Launchpad._overlayContent.scale_y = 1;
            Launchpad._restorePanelStacking();
        }
    },

    _loadApps: function() {
        Launchpad._allApps = [];
        let apps = Gio.AppInfo.get_all();
        for (let i = 0; i < apps.length; i++) {
            let app = apps[i];
            let hideThis = (typeof app.get_nodisplay === "function")
                ? app.get_nodisplay()
                : !app.should_show();
            if (hideThis) continue;
            Launchpad._allApps.push(app);
        }
        Launchpad._allApps.sort(function(a, b) {
            let an = (a.get_display_name() || a.get_name() || "").toLowerCase();
            let bn = (b.get_display_name() || b.get_name() || "").toLowerCase();
            return an.localeCompare(bn);
        });
        Launchpad._appsLoaded = true;
    },

    _searchDebounceId: null,

    // Debounced like the tile hover-accent lookup below: typing quickly
    // used to re-run the full filter -> sort -> destroy_all_children ->
    // rebuild-grid pipeline on every single keystroke. Coalescing rapid
    // keystrokes into one pass (last one wins) cuts that down to a single
    // rebuild once typing pauses, without changing the end result.
    _onSearchChanged: function() {
        if (Launchpad._searchDebounceId) {
            Mainloop.source_remove(Launchpad._searchDebounceId);
            Launchpad._searchDebounceId = null;
        }
        Launchpad._searchDebounceId = Mainloop.timeout_add(80, function() {
            Launchpad._searchDebounceId = null;
            if (Launchpad._searchEntry) {
                Launchpad._layoutApps(Launchpad._sortForDisplay(Launchpad._currentFilteredApps()));
            }
            return false;
        });
    },

    _currentFilteredApps: function() {
        let query = Launchpad._searchEntry.get_text().toLowerCase();
        if (!query) return Launchpad._allApps;
        return Launchpad._allApps.filter(function(app) {
            let name = (app.get_display_name() || app.get_name() || "").toLowerCase();
            return name.indexOf(query) !== -1;
        });
    },

    _refreshGrid: function() {
        Launchpad._layoutApps(Launchpad._sortForDisplay(Launchpad._currentFilteredApps()));
    },

    // Fixed display order for the Launchpad grid (unlike the dock's
    // "cluster by first occurrence" grouping, favorites always come
    // first, then everything else follows this fixed category order).
    // Checked top-to-bottom against each app's XDG Categories - the first
    // bucket whose "match" list intersects wins.
    _LAUNCHPAD_CATEGORY_ORDER: [
        { key: 'internet',     match: ['Network', 'WebBrowser', 'Email', 'InstantMessaging', 'Chat', 'VideoConference', 'P2P', 'RemoteAccess', 'News', 'FileTransfer'] },
        { key: 'multimedia',   match: ['AudioVideo', 'Audio', 'Video', 'Player', 'Recorder', 'Mixer', 'TV', 'Midi', 'DiscBurning', 'Music'] },
        { key: 'office',       match: ['Office', 'WordProcessor', 'Spreadsheet', 'Presentation', 'Publishing', 'Calendar', 'ProjectManagement', 'Chart', 'Dictionary'] },
        { key: 'graphics',     match: ['Graphics', 'Photography', '2DGraphics', '3DGraphics', 'RasterGraphics', 'VectorGraphics', 'Scanning', 'Viewer'] },
        { key: 'system',       match: ['System', 'Settings', 'Monitor', 'Security', 'FileManager', 'FileTools', 'Archiving', 'Compression', 'TerminalEmulator', 'PackageManager', 'HardwareSettings'] },
        { key: 'development',  match: ['Development', 'IDE', 'TextEditor', 'GUIDesigner', 'Debugger', 'Building', 'RevisionControl'] },
        { key: 'games',        match: ['Game'] },
        { key: 'education',    match: ['Education', 'Science', 'Math', 'Languages', 'ArtificialIntelligence'] },
        { key: 'accessories',  match: ['Utility', 'Accessibility', 'Calculator', 'TextTools'] }
        // Anything matching none of the above (rank === array length)
        // falls through to a final "Other" bucket, alphabetical like the
        // rest.
    ],

    // Resolves and caches which bucket index an app belongs to. Apps with
    // no matching bucket rank after every curated one (i.e. "Other",
    // last).
    _getLaunchpadCategoryRank: function(app) {
        let id = null;
        try { id = app.get_id(); } catch(e) {}

        if (id) {
            if (!Launchpad._categoryRankCache) Launchpad._categoryRankCache = {};
            if (Launchpad._categoryRankCache.hasOwnProperty(id)) {
                return Launchpad._categoryRankCache[id];
            }
        }

        let order = Launchpad._LAUNCHPAD_CATEGORY_ORDER;
        let rank = order.length;
        try {
            let raw = (typeof app.get_categories === "function") ? app.get_categories() : null;
            if (raw) {
                let cats = raw.split(';').filter(function(c) { return c.length > 0; });
                outer:
                for (let i = 0; i < order.length; i++) {
                    for (let j = 0; j < cats.length; j++) {
                        if (order[i].match.indexOf(cats[j]) !== -1) { rank = i; break outer; }
                    }
                }
            }
        } catch(e) {}

        if (id) Launchpad._categoryRankCache[id] = rank;
        return rank;
    },

    // Sorts by category bucket rank, keeping alphabetical order (the
    // array is already alpha-sorted by _loadApps) as the tiebreak within
    // a bucket. Explicit index tiebreak rather than relying on Array.sort
    // stability across JS engines.
    _sortByCategoryOrder: function(apps) {
        return apps
            .map(function(app, idx) { return { app: app, idx: idx, rank: Launchpad._getLaunchpadCategoryRank(app) }; })
            .sort(function(a, b) { return (a.rank - b.rank) || (a.idx - b.idx); })
            .map(function(entry) { return entry.app; });
    },

    _sortForDisplay: function(apps) {
        let favs = (Launchpad.settings && Launchpad.settings.favoriteApps) || [];
        if (!favs.length) return Launchpad._sortByCategoryOrder(apps);

        let favSet = {};
        favs.forEach(function(id) { favSet[id] = true; });
        let favApps = [], rest = [];
        apps.forEach(function(app) {
            if (favSet[app.get_id()]) favApps.push(app); else rest.push(app);
        });
        return favApps.concat(Launchpad._sortByCategoryOrder(rest));
    },

    _isFavorite: function(app) {
        return ((Launchpad.settings && Launchpad.settings.favoriteApps) || []).indexOf(app.get_id()) !== -1;
    },

    _toggleFavorite: function(app) {
        let favs = ((Launchpad.settings && Launchpad.settings.favoriteApps) || []).slice();
        let id = app.get_id();
        let idx = favs.indexOf(id);
        if (idx !== -1) favs.splice(idx, 1); else favs.push(id);
        Launchpad.settings.favoriteApps = favs;
        SettingsStore.saveLaunchpadSettings(Launchpad.settings);
        Launchpad._refreshGrid();
        if (Shared.STANDALONE_DOCK_MODE) {
            try { _dock().refresh(); } catch(e) {}
        }
    },

    _getGridMetrics: function() {
        const COLUMNS = 7;
        const ROWS = 4;
        const spacing = 32;
        const maxTileSize = 220;

        let overlayW = Launchpad._contentW || Main.layoutManager.primaryMonitor.width;
        let overlayH = Launchpad._contentH || Main.layoutManager.primaryMonitor.height;

        let availW = Math.max(200, overlayW - 160);
        let searchH = (Launchpad._searchContainerActor && Launchpad._searchContainerActor.height) || 60;
        let pagerH = 60;
        let overlayVerticalPadding = 48;
        let availH = Math.max(200, overlayH - searchH - pagerH - overlayVerticalPadding);

        let tileWidthFit = Math.floor((availW - spacing * (COLUMNS - 1)) / COLUMNS);
        let tileHeightFit = Math.floor((availH - spacing * (ROWS - 1)) / ROWS);
        let tileSize = Math.min(maxTileSize, tileWidthFit, tileHeightFit);
        tileSize = Math.max(48, tileSize);
        let iconSize = Math.max(32, Math.round(tileSize * 0.58));

        return { columns: COLUMNS, rows: ROWS, tileSize: tileSize, iconSize: iconSize };
    },

    _buildPages: function(apps) {
        let grid = Launchpad._getGridMetrics();
        let perPage = Math.max(1, grid.columns * grid.rows);
        let pages = [];
        for (let i = 0; i < apps.length; i += perPage) {
            pages.push(apps.slice(i, i + perPage));
        }
        if (pages.length === 0) pages.push([]);
        return pages;
    },

    _layoutApps: function(apps) {
        Launchpad._pages = Launchpad._buildPages(apps);
        Launchpad._currentPage = 0;
        Launchpad._populateGrid(Launchpad._pages[0]);
        Launchpad._renderPager();
    },

    _renderPager: function() {
        if (!Launchpad._pagerBox) return;
        Launchpad._pagerBox.destroy_all_children();
        let pageCount = Launchpad._pages ? Launchpad._pages.length : 0;
        if (pageCount < 1) pageCount = 1;

        for (let i = 0; i < pageCount; i++) {
            let isActive = (i === Launchpad._currentPage);
            let dot = new St.Bin({
                style_class: "launchpad-dot" + (isActive ? " launchpad-dot-active" : ""),
                reactive: true,
                track_hover: true
            });
            let idx = i;
            dot.connect("button-release-event", function() {
                Launchpad._goToPage(idx);
                return Clutter.EVENT_STOP;
            });
            Launchpad._pagerBox.add(dot, { x_fill: false, y_fill: false });
        }
        Launchpad._pagerBox.queue_relayout();
    },

    _goToPage: function(index) {
        if (!Launchpad._pages || index < 0 || index >= Launchpad._pages.length) return;
        if (index === Launchpad._currentPage) return;
        Launchpad._currentPage = index;
        Launchpad._populateGrid(Launchpad._pages[index]);
        Launchpad._renderPager();
    },

    _populateGrid: function(apps) {
        Launchpad._gridBox.destroy_all_children();
        let grid = Launchpad._getGridMetrics();
        let fixedHeight = grid.rows * grid.tileSize + (grid.rows - 1) * 32;
        Launchpad._gridWrapper.set_height(fixedHeight);
        let column = 0, row = 0;
        for (let i = 0; i < apps.length; i++) {
            let tile = Launchpad._createTile(apps[i], grid.tileSize, grid.iconSize);
            Launchpad._gridLayout.attach(tile, column, row, 1, 1);
            column++;
            if (column >= grid.columns) {
                column = 0;
                row++;
            }
        }
    },

    _createTile: function(app, tileSize, iconSize) {
        tileSize = tileSize || 104;
        iconSize = iconSize || 56;
        let tile = new St.BoxLayout({
            vertical: true,
            reactive: true,
            track_hover: true,
            style_class: "launchpad-tile",
            width: tileSize,
            height: tileSize
        });

        let icon = new St.Icon({
            gicon: app.get_icon(),
            icon_size: iconSize,
            style_class: "launchpad-icon"
        });
        let iconBin = new St.Bin({ x_align: St.Align.MIDDLE });
        iconBin.set_child(icon);

        let label = new St.Label({
            text: app.get_display_name() || app.get_name() || "",
            style_class: "launchpad-label"
        });
        label.clutter_text.set_line_wrap(true);

        tile.add(iconBin, { x_fill: false, x_align: St.Align.MIDDLE });
        tile.add(label, { x_fill: false, x_align: St.Align.MIDDLE });

        // Mirror the dock's own per-app hover accent (StandaloneDock's
        // _startAppAccent()/_endAppAccent() in dock.js): tint the
        // Launchpad background toward this tile's icon's dominant color
        // while it's hovered. Reuses the dock's own resolver/cache
        // (_getAppAccentColor) instead of duplicating the icon-path ->
        // dominant-color lookup here.
        //
        // Debounced (like the dock's own _scheduleTooltip): a Launchpad
        // grid can hold dozens of distinct, not-yet-cached apps, so
        // sweeping the mouse across it fires enter-event on many tiles
        // in quick succession. Resolving the color immediately on every
        // one of those - each a fresh icon-theme lookup + image decode
        // the first time - was hitching/freezing the grid. Waiting a
        // short moment before resolving means only the tile the pointer
        // actually settles on does that work; a tile only passed over
        // has its pending lookup cancelled on leave-event before it runs.
        tile.connect("enter-event", function() {
            let dockSettings = SettingsStore.getDockSettings();
            if (dockSettings.perAppAccentEnabled === false) return Clutter.EVENT_PROPAGATE;
            Launchpad._accentHoverApp = app;
            if (Launchpad._accentHoverTimeoutId) {
                Mainloop.source_remove(Launchpad._accentHoverTimeoutId);
                Launchpad._accentHoverTimeoutId = null;
            }
            Launchpad._accentHoverTimeoutId = Mainloop.timeout_add(120, function() {
                Launchpad._accentHoverTimeoutId = null;
                _dock()._getAppAccentColor(app, function(rgb) {
                    if (Launchpad._accentHoverApp !== app || !rgb) return;
                    Launchpad.applyAccent(rgb);
                });
                return false;
            });
            return Clutter.EVENT_PROPAGATE;
        });

        tile.connect("leave-event", function() {
            Launchpad._accentHoverApp = null;
            if (Launchpad._accentHoverTimeoutId) {
                Mainloop.source_remove(Launchpad._accentHoverTimeoutId);
                Launchpad._accentHoverTimeoutId = null;
            }
            Launchpad.clearAccent();
            return Clutter.EVENT_PROPAGATE;
        });

        tile.connect("button-press-event", function(actor, event) {
            let button = event.get_button();
            if (button === 3) {
                let [x, y] = event.get_coords();
                Launchpad._showContextMenu(app, x, y);
                return Clutter.EVENT_STOP;
            }
            try {
                app.launch([], null);
            } catch (e) {
                global.logError("Dock/Launchpad: failed to launch app - " + e);
            }
            Launchpad.close();
            return Clutter.EVENT_STOP;
        });

        return tile;
    },

    _hideContextMenu: function() {
        if (Launchpad._contextMenu) {
            Launchpad._contextMenu.destroy();
            Launchpad._contextMenu = null;
        }
    },

    _showContextMenu: function(app, x, y) {
        Launchpad._hideContextMenu();

        let isDark = Launchpad._resolveIsDark();
        let menu = new St.BoxLayout({
            vertical: true,
            reactive: true,
            style_class: "launchpad-context-menu " + (isDark ? "launchpad-dark" : "launchpad-light")
        });

        let items = [
            { label: _("Add to Desktop"), action: Launchpad._addAppToDesktop },
            {
                label: Launchpad._isFavorite(app) ? _("Remove from Dock") : _("Pin to Dock"),
                action: Launchpad._toggleFavorite
            },
            { label: _("Uninstall"), action: Launchpad._uninstallApp }
        ];

        items.forEach(function(item) {
            let row = new St.Label({
                text: item.label,
                style_class: "launchpad-context-item",
                reactive: true,
                track_hover: true
            });
            row.connect("button-release-event", function() {
                Launchpad._hideContextMenu();
                item.action(app);
                return Clutter.EVENT_STOP;
            });
            menu.add(row, { x_fill: true, y_fill: false });
        });

        Main.uiGroup.add_actor(menu);
        menu.raise_top();

        let m = Main.layoutManager.primaryMonitor;
        let [menuW, menuH] = menu.get_size();
        let posX = Math.min(x, m.x + m.width - menuW - 8);
        let posY = Math.min(y, m.y + m.height - menuH - 8);
        menu.set_position(posX, posY);

        Launchpad._contextMenu = menu;
    },

    _addAppToDesktop: function(app) {
        try {
            let srcPath = app.get_filename();
            if (!srcPath) return;
            let desktopDir = GLib.get_user_special_dir(GLib.UserDirectory.DIRECTORY_DESKTOP) || (GLib.get_home_dir() + "/Desktop");
            let srcFile = Gio.File.new_for_path(srcPath);
            let destFile = Gio.File.new_for_path(GLib.build_filenamev([desktopDir, srcFile.get_basename()]));
            srcFile.copy(destFile, Gio.FileCopyFlags.OVERWRITE, null, null);
            try {
                destFile.set_attribute_string("metadata::trusted", "true", Gio.FileQueryInfoFlags.NONE, null);
            } catch (e) {}
            GLib.spawn_command_line_async("chmod +x " + GLib.shell_quote(destFile.get_path()));
        } catch (e) {
            global.logError("Dock/Launchpad: failed to add app to desktop - " + e);
        }
    },

    _uninstallApp: function(app) {
        try {
            let path = app.get_filename();
            if (path) {
                Util.spawnCommandLine("/usr/bin/cinnamon-remove-application '" + path + "'");
            }
        } catch (e) {
            global.logError("Dock/Launchpad: failed to launch uninstaller - " + e);
        }
        Launchpad.close();
    }
};
