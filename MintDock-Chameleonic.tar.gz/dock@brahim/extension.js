// -*- mode: js; js-indent-level: 4; indent-tabs-mode: nil -*-

const Settings = imports.ui.settings;
const Mainloop = imports.mainloop;

let Shared, SettingsStore, Launchpad, MediaControlsDocklet, CinemixRadio, StandaloneDock, WelcomeScreen, Effects, WeatherDocklet, WindowEffects;
let globalSettings;

function _loadSiblingModules(extensionDir) {
    let oldSearchPath = imports.searchPath.slice();
    imports.searchPath = [extensionDir];
    Shared = imports.shared;
    Shared.EXTENSION_DIR = extensionDir;
    imports.utils;
    SettingsStore = imports.settingsStore;
    Launchpad = imports.launchpad.Launchpad;
    MediaControlsDocklet = imports.mediaDocklet.MediaControlsDocklet;
    CinemixRadio = imports.radio.CinemixRadio;
    StandaloneDock = imports.dock.StandaloneDock;
    WelcomeScreen = imports.welcome.WelcomeScreen;
    Effects = imports.effects.Effects;
    WeatherDocklet = imports.weather.WeatherDocklet;
    WindowEffects = imports.windowEffects.WindowEffects;
    imports.searchPath = oldSearchPath;
}

function init(metadata) {
    _loadSiblingModules(metadata.path);
}

function enable() {
    global.log("dock@brahim: enable() called");
    try {
        globalSettings = new Settings.ExtensionSettings(this, Shared.UUID);
        Shared.globalSettings = globalSettings;

        SettingsStore.DOCK_SETTINGS_KEYMAP.concat(SettingsStore.DOCKLETS_SETTINGS_KEYMAP).forEach(function(pair) {
            globalSettings.connect("changed::" + pair[0], function() {
                try { StandaloneDock.applySettings(); } catch(e) {}
            });
        });
        SettingsStore.LAUNCHPAD_SETTINGS_KEYMAP.forEach(function(pair) {
            globalSettings.connect("changed::" + pair[0], function() {
                try { Launchpad.applySettings(); } catch(e) {}
                try { StandaloneDock.applySettings(); } catch(e) {}
            });
        });
        SettingsStore.EFFECTS_SETTINGS_KEYMAP.forEach(function(pair) {
            globalSettings.connect("changed::" + pair[0], function() {
                try { Effects.applySettings(); } catch(e) {}
            });
        });
        // "weather-city" is a plain text entry: Cinnamon's xlet-settings
        // window commits (and fires "changed::weather-city") on EVERY
        // keystroke, not just on blur/Enter. WeatherDocklet.refresh() goes
        // straight to a synchronous, blocking `curl` spawn (see weather.js's
        // _fetchAsync doc comment - the async Gio.Subprocess path doesn't
        // work in this environment, so this trades a bounded block for a
        // hang that never resolves). Without debouncing, typing a city name
        // fired one blocking network call per character - each one able to
        // sit on the main loop for up to FETCH_TIMEOUT_SEC (10s) - so
        // keystrokes queued up behind the block and only appeared once the
        // pending calls finally drained, i.e. exactly the "freezes as I
        // type then shows the full word later" symptom. Debouncing so only
        // the LAST change in a burst actually triggers a fetch (900ms after
        // typing stops) fixes that without touching the fetch mechanism
        // itself.
        let weatherCityDebounceId = null;
        SettingsStore.WEATHER_SETTINGS_KEYMAP.forEach(function(pair) {
            globalSettings.connect("changed::" + pair[0], function() {
                if (weatherCityDebounceId) {
                    Mainloop.source_remove(weatherCityDebounceId);
                    weatherCityDebounceId = null;
                }
                weatherCityDebounceId = Mainloop.timeout_add(900, function() {
                    weatherCityDebounceId = null;
                    try { WeatherDocklet.refresh(); } catch(e) {}
                    try { StandaloneDock.refresh(); } catch(e) {}
                    return Mainloop.SOURCE_REMOVE;
                });
            });
        });
    } catch(e) {
        global.logError("dock@brahim: settings-setup threw: " + e);
        if (e && e.stack) global.logError(e.stack);
        return;
    }

    // Load welcome screen FIRST
    global.log("dock@brahim: enabling WelcomeScreen");
    try { WelcomeScreen.enable(); } catch(e) { global.logError("dock@brahim: WelcomeScreen.enable() threw: " + e); }

    // Load dock components after a delay so welcome screen appears first
    Mainloop.timeout_add(500, () => {
        global.log("dock@brahim: enabling Launchpad");
        try { Launchpad.enable(); } catch(e) { global.logError("dock@brahim: Launchpad.enable() threw: " + e); }
        
        global.log("dock@brahim: enabling MediaControlsDocklet");
        try { MediaControlsDocklet.enable(); } catch(e) { global.logError("dock@brahim: MediaControlsDocklet.enable() threw: " + e); }
        
        global.log("dock@brahim: enabling CinemixRadio");
        try { CinemixRadio.enable(); } catch(e) { global.logError("dock@brahim: CinemixRadio.enable() threw: " + e); }

        global.log("dock@brahim: enabling WeatherDocklet");
        try { WeatherDocklet.enable(); } catch(e) { global.logError("dock@brahim: WeatherDocklet.enable() threw: " + e); }

        global.log("dock@brahim: enabling Effects");
        try { Effects.enable(); } catch(e) { global.logError("dock@brahim: Effects.enable() threw: " + e); }

        global.log("dock@brahim: enabling WindowEffects");
        try { WindowEffects.enable(); } catch(e) { global.logError("dock@brahim: WindowEffects.enable() threw: " + e); }

        global.log("dock@brahim: enabling StandaloneDock");
        try {
            StandaloneDock.enable();
            global.log("dock@brahim: StandaloneDock.enable() completed");
            
            // Hide dock immediately after it's created
            try {
                if (StandaloneDock.widget) {
                    StandaloneDock.widget.opacity = 0;
                    StandaloneDock.widget.reactive = false;
                    global.log("dock@brahim: Dock hidden after creation");
                }
            } catch(e) {}
        } catch(e) {
            global.logError("dock@brahim: StandaloneDock.enable() threw: " + e);
            try { StandaloneDock._teardown(); } catch(e2) {}
        }
        return Mainloop.SOURCE_REMOVE;
    });
}

function disable() {
    global.log("dock@brahim: disable() called");
    try { WelcomeScreen.disable(); } catch(e) {}
    try { StandaloneDock.disable(); } catch(e) {}
    try { Launchpad.disable(); } catch(e) {}
    try { MediaControlsDocklet.disable(); } catch(e) {}
    try { CinemixRadio.disable(); } catch(e) {}
    try { WeatherDocklet.disable(); } catch(e) {}
    try { Effects.disable(); } catch(e) {}
    try { WindowEffects.disable(); } catch(e) {}
    if (globalSettings) {
        globalSettings.finalize();
        globalSettings = null;
        Shared.globalSettings = null;
    }
}