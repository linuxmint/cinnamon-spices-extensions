// radio.js
// -*- mode: js; js-indent-level: 4; indent-tabs-mode: nil -*-

const Clutter = imports.gi.Clutter;
const Gio = imports.gi.Gio;
const GLib = imports.gi.GLib;
const St = imports.gi.St;
const Main = imports.ui.main;

const Shared = imports.shared;
const OSD = Shared.requireSibling('osd');
const Volume = Shared.requireSibling('volume');
const RadioIcons = Shared.requireSibling('radioIcons');
// Safe as a top-level import here: by the time extension.js's
// _loadSiblingModules() reaches `imports.radio.CinemixRadio` (which is what
// first evaluates this file), settingsStore.js has already been loaded and
// searchPath is still swapped to the extension dir - same reasoning osd.js
// already relies on for its own top-level SettingsStore import.
const SettingsStore = imports.settingsStore;

function _dock() {
    return Shared.requireSibling('dock').StandaloneDock;
}
function _media() {
    return Shared.requireSibling('mediaDocklet').MediaControlsDocklet;
}
function _launchpad() {
    return Shared.requireSibling('launchpad').Launchpad;
}

// ---- Station list ----------------------------------------------------
// A small, curated set of relaxation/ambient stations grouped into two
// categories for the picker menu. Real, stable "nature sound" (rain/
// ocean/forest loop) radio streams are hard to find with durable public
// URLs, so this leans on SomaFM's long-running, freely streamable ambient
// channels instead - closest reliable equivalent to "relaxation & nature"
// without hardcoding a stream URL likely to rot. The icon set in
// radioIcons.js already includes 'rain' and 'flame' glyphs, unused below,
// so a literal nature-sound stream can be dropped in later just by adding
// a station entry with icon: "rain".
const STATIONS = [
    {
        id: "cinemix",
        name: "Cinemix",
        subtitle: "Mixed genre stream",
        url: "https://kathy.torontocast.com:1825/stream",
        icon: "wave",
        // Official station logo (mirrored by the myTuner radio directory,
        // since Cinemix itself doesn't publish a stable direct-linkable
        // logo asset). Falls back to the drawn "wave" glyph above if this
        // ever 404s - see DockAlbumArt.resolve()/_updateArt() in
        // mediaDocklet.js.
        logoUrl: "https://static.mytuner.mobi/media/tvos_radios/524/cinemix.90fb67d4.png",
        category: "chill"
    },
    {
        id: "groovesalad",
        name: "Groove Salad",
        subtitle: "Chilled ambient & downtempo beats",
        url: "https://ice1.somafm.com/groovesalad-128-mp3",
        icon: "leaf",
        // SomaFM serves each channel's official cover art from this
        // predictable /img3/<channel>-400.jpg path (confirmed against
        // SomaFM's own published channel metadata).
        logoUrl: "https://somafm.com/img3/groovesalad-400.jpg",
        category: "chill"
    },
    {
        id: "fluid",
        name: "Fluid",
        subtitle: "Deep chillout & soulful downtempo",
        url: "https://ice1.somafm.com/fluid-128-mp3",
        icon: "wave",
        logoUrl: "https://somafm.com/img3/fluid-400.jpg",
        category: "chill"
    },
    {
        id: "dronezone",
        name: "Drone Zone",
        subtitle: "Slow, atmospheric ambient drones",
        url: "https://ice1.somafm.com/dronezone-128-mp3",
        icon: "moon",
        logoUrl: "https://somafm.com/img3/dronezone-400.jpg",
        category: "ambient"
    },
    {
        id: "deepspaceone",
        name: "Deep Space One",
        subtitle: "Deep ambient electronic soundscapes",
        url: "https://ice1.somafm.com/deepspaceone-128-mp3",
        icon: "moon",
        logoUrl: "https://somafm.com/img3/deepspaceone-400.jpg",
        category: "ambient"
    },
    {
        id: "missioncontrol",
        name: "Mission Control",
        subtitle: "Ambient space & mission audio",
        url: "https://ice1.somafm.com/missioncontrol-128-mp3",
        icon: "moon",
        logoUrl: "https://somafm.com/img3/missioncontrol-400.jpg",
        category: "ambient"
    },
    {
        id: "radioartnature",
        name: "Radio Art - Nature",
        subtitle: "Pure nature soundscapes",
        url: "http://air.radioart.com/fNature.mp3",
        icon: "rain",
        logoUrl: "",
        category: "nature"
    },
    {
        id: "epiclounge",
        name: "Epic Lounge - Nature Sounds",
        subtitle: "Nature sounds lounge stream",
        url: "https://stream.epic-lounge.com/nature-sounds?ref=radiobrowser",
        icon: "leaf",
        logoUrl: "",
        category: "nature"
    },
    {
        id: "natureRelax",
        name: "Nature Relax",
        subtitle: "Relaxing lounge nature sounds",
        url: "https://0nlineradio.radioho.st/lounge-nature-sounds?ref=radio-browser26",
        icon: "rain",
        logoUrl: "",
        category: "nature"
    },
    {
        id: "spaLounge",
        name: "Spa Lounge",
        subtitle: "Spa & relaxation lounge",
        url: "https://0nlineradio.radioho.st/lounge-spa-lounge?ref=radio-browser26",
        icon: "wave",
        logoUrl: "",
        category: "nature"
    },
    {
        id: "beethoven",
        name: "Beethoven Radio",
        subtitle: "All-Beethoven classical stream",
        url: "https://0nlineradio.radioho.st/0r-beethoven?ref=radio-browser26",
        icon: "moon",
        logoUrl: "",
        category: "classical"
    },
    {
        id: "mozart",
        name: "Mozart Radio",
        subtitle: "All-Mozart classical stream",
        url: "https://nl4.mystreaming.net/uber/crmozart/icecast.audio",
        icon: "leaf",
        logoUrl: "",
        category: "classical"
    },
    {
        id: "tchaikovsky",
        name: "Tchaikovsky Radio",
        subtitle: "All-Tchaikovsky classical stream",
        url: "http://drive.uber.radio/uber/crtchaikovsky/icecast.audio",
        icon: "wave",
        logoUrl: "",
        category: "classical"
    },
    {
        id: "sleep",
        name: "Classical for Sleep",
        subtitle: "Classical music for sleep",
        url: "https://0nlineradio.radioho.st/classical-classical-music-for-sleep?ref=radio-browser26",
        icon: "moon",
        logoUrl: "",
        category: "classical"
    }
];

const CATEGORY_LABELS = {
    chill: "Chill & Lounge",
    ambient: "Ambient & Space",
    nature: "Nature Sounds",
    classical: "Classical & Composers"
};

const RADIO_PLAYER_KEY = "dock-radio-station";

var CinemixRadio = {
    _state: "idle",
    _proc: null,
    _icon: null,
    _tile: null,
    _userStopped: false,
    _startedAtMs: 0,
    _trackTitle: "",
    _volume: 0.8,
    _enabledAtMs: 0,
    _ipcPath: null,
    _ipcConnection: null,
    _ipcOut: null,
    _ipcIn: null,
    _currentStationId: null,
    _userHasMoved: false,
    _motionSignalId: 0,

    enable: function() {
        CinemixRadio._state = "idle";
        CinemixRadio._proc = null;
        CinemixRadio._icon = null;
        CinemixRadio._tile = null;
        CinemixRadio._userStopped = false;
        CinemixRadio._trackTitle = "";
        CinemixRadio._volume = 0.8;
        CinemixRadio._enabledAtMs = GLib.get_monotonic_time() / 1000;
        global.log('dock@brahim: brahim-osd-debug: CinemixRadio enabled at ' + CinemixRadio._enabledAtMs);
        CinemixRadio._currentStationId = CinemixRadio._loadCurrentStationId();
        CinemixRadio._tryReattach();

        // A fixed elapsed-time grace window alone is fragile: real
        // session-to-interactive time varies (login screen -> compositor
        // handoff can easily run past any small hardcoded timeout), while
        // stray/replayed scroll ticks from touchpad/mouse driver
        // initialization at session start are the actual thing being
        // guarded against - and those arrive with NO accompanying real
        // pointer motion. So in addition to the elapsed-time check below,
        // require that the mouse has genuinely moved at least once since
        // enable() before a scroll on the radio tile is honored. This
        // disconnects itself after the first real motion - it only needs
        // to answer "has a human touched the mouse yet", not track motion
        // continuously.
        CinemixRadio._userHasMoved = false;
        if (CinemixRadio._motionSignalId) {
            try { global.stage.disconnect(CinemixRadio._motionSignalId); } catch(e) {}
            CinemixRadio._motionSignalId = 0;
        }
        CinemixRadio._motionSignalId = global.stage.connect("motion-event", function() {
            CinemixRadio._userHasMoved = true;
            if (CinemixRadio._motionSignalId) {
                try { global.stage.disconnect(CinemixRadio._motionSignalId); } catch(e) {}
                CinemixRadio._motionSignalId = 0;
            }
            return Clutter.EVENT_PROPAGATE;
        });
    },

    disable: function() {
        CinemixRadio._userStopped = true;
        CinemixRadio._stop();
        CinemixRadio._icon = null;
        CinemixRadio._tile = null;
        if (CinemixRadio._motionSignalId) {
            try { global.stage.disconnect(CinemixRadio._motionSignalId); } catch(e) {}
            CinemixRadio._motionSignalId = 0;
        }
    },

    // Cinnamon restarts (Restart Cinnamon, crash recovery, theme reloads)
    // re-run this extension's enable() from scratch, but any mpv stream
    // previously spawned by _start() is a real, independent child
    // process - it is NOT tied to Cinnamon's own lifecycle and keeps
    // playing straight through the restart. Without this, enable() had
    // no way of knowing that, so _state reset to "idle" even though
    // audio was still coming out of a live mpv process: the dock icon
    // showed "stopped", and clicking it called _start() (spawning a
    // SECOND, overlapping stream on top of the still-running first one)
    // instead of _stop(). Reconnecting to the last known IPC socket - if
    // it's still alive - restores accurate state, and _stop()/_toggle()
    // already work correctly off of _ipcOut regardless of whether we
    // have a Gio.Subprocess handle for it, so no other call site needs
    // to change.
    _tryReattach: function() {
        let ipcPath = SettingsStore.getRadioRuntimeIpcPath();
        if (!ipcPath) return;
        if (!GLib.file_test(ipcPath, GLib.FileTest.EXISTS)) {
            SettingsStore.saveRadioRuntimeIpcPath("");
            return;
        }

        let address = new Gio.UnixSocketAddress({ path: ipcPath });
        let client = new Gio.SocketClient();
        client.connect_async(address, null, function(source, res) {
            let conn;
            try {
                conn = source.connect_finish(res);
            } catch(e) {
                // Stale socket file left behind by a stream that's
                // actually gone - nothing to reattach to.
                SettingsStore.saveRadioRuntimeIpcPath("");
                return;
            }

            CinemixRadio._ipcPath = ipcPath;
            CinemixRadio._ipcConnection = conn;
            CinemixRadio._ipcOut = new Gio.DataOutputStream({ base_stream: conn.get_output_stream() });
            CinemixRadio._ipcIn = new Gio.DataInputStream({ base_stream: conn.get_input_stream() });

            try {
                CinemixRadio._ipcOut.put_string('{"command":["observe_property",1,"media-title"]}\n', null);
            } catch(e) {}

            CinemixRadio._applyVolume();
            CinemixRadio._readIpcLine();
            CinemixRadio._setState("playing");
        });
    },

    isPlaying: function() {
        return CinemixRadio._state === "playing";
    },

    // ---- Station lookups ----

    _stationById: function(id) {
        for (let i = 0; i < STATIONS.length; i++) {
            if (STATIONS[i].id === id) return STATIONS[i];
        }
        return null;
    },

    _currentStation: function() {
        return CinemixRadio._stationById(CinemixRadio._currentStationId) || STATIONS[0];
    },

    _loadCurrentStationId: function() {
        try {
            let id = SettingsStore.getRadioCurrentStation();
            if (id && CinemixRadio._stationById(id)) return id;
        } catch(e) {}
        return STATIONS[0].id;
    },

    _saveCurrentStationId: function(id) {
        try { SettingsStore.saveRadioCurrentStation(id); } catch(e) {}
    },

    // Picking a station always plays it immediately - the expected
    // "tap to play" behavior for a station picker (as opposed to the dock
    // tile's own click, which just play/pauses whatever is already
    // selected - see the button-press-event handler in getTile()).
    _selectStation: function(stationId) {
        let station = CinemixRadio._stationById(stationId);
        if (!station) return;

        let isSame = (stationId === CinemixRadio._currentStationId);
        CinemixRadio._currentStationId = stationId;
        CinemixRadio._saveCurrentStationId(stationId);

        if (isSame && CinemixRadio._state === "playing") {
            if (CinemixRadio._icon) CinemixRadio._icon.queue_repaint();
            return;
        }

        CinemixRadio._trackTitle = "";
        CinemixRadio._userStopped = false;
        if (CinemixRadio._icon) CinemixRadio._icon.queue_repaint();
        // _start() already tears down any existing mpv process/IPC socket
        // before spawning the new one (see below), so switching stations
        // while already playing is just a normal _start() call.
        CinemixRadio._start();
    },

    // ---- Dock tile ----

    getTile: function() {
        let iconSize = _dock()._renderIconSize || _dock()._iconSize;
        let tile = new St.BoxLayout({
            vertical: true,
            reactive: true,
            track_hover: true,
            style_class: "brahim-dock-tile"
        });

        let iconArea = new St.DrawingArea({ style_class: "brahim-media-icon" });
        iconArea.set_size(iconSize, iconSize);
        iconArea.connect("repaint", function(area) {
            let cr = area.get_context();
            let box = area.get_allocation_box();
            let W = box.x2 - box.x1, H = box.y2 - box.y1;
            if (W < 2 || H < 2) { cr.$dispose(); return; }
            let rgba = CinemixRadio._iconColorRGBA();
            RadioIcons.drawStationIcon(cr, W, H, "radio",
                                        rgba[0], rgba[1], rgba[2], rgba[3]);
        });

        let iconBin = new St.Bin({ x_align: St.Align.MIDDLE });
        iconBin.set_child(iconArea);
        tile.add(iconBin, { x_fill: false, x_align: St.Align.MIDDLE, y_fill: false, y_align: St.Align.MIDDLE, expand: true });

        CinemixRadio._icon = iconArea;
        CinemixRadio._tile = tile;

        _dock()._wireHoverEffects(tile, iconBin, null, function() {
            return Shared.requireSibling('utils')._(CinemixRadio._currentStation().name + " Radio");
        });

        tile.connect("button-press-event", function(actor, event) {
            _dock()._exitShowDesktopIfNeeded();
            let hadMenu = !!_dock()._menu;
            _dock()._hideContextMenu();
            _dock()._cancelThumbPreview();
            if (hadMenu) return Clutter.EVENT_STOP;

            let button = event.get_button();
            if (button === 3) {
                CinemixRadio._showStationOverlay();
                return Clutter.EVENT_STOP;
            }

            CinemixRadio._toggle();
            return Clutter.EVENT_STOP;
        });

        // Scroll to adjust system volume, show OSD, and sync with mpv.
        //
        // Guarded by a short grace window after enable(): a scroll event
        // queued by the mouse/touchpad right as the session starts (before
        // the user has actually touched anything) can land on this tile
        // the moment it becomes reactive, which was showing the volume OSD
        // on login instead of only when the user actually scrolls here.
        const SCROLL_STARTUP_GRACE_MS = 1500;
        tile.connect("scroll-event", function(actor, ev) {
            const dir = ev.get_scroll_direction();
            if (dir === Clutter.ScrollDirection.UP || dir === Clutter.ScrollDirection.DOWN) {
                let sinceEnabled = (GLib.get_monotonic_time() / 1000) - CinemixRadio._enabledAtMs;
                global.log('dock@brahim: brahim-osd-debug: scroll-event dir=' + dir + ' sinceEnabled=' + sinceEnabled + ' userHasMoved=' + CinemixRadio._userHasMoved);
                if (sinceEnabled < SCROLL_STARTUP_GRACE_MS) {
                    global.log('dock@brahim: brahim-osd-debug: suppressed (within startup grace window)');
                    return Clutter.EVENT_STOP;
                }
                if (!CinemixRadio._userHasMoved) {
                    global.log('dock@brahim: brahim-osd-debug: suppressed (no genuine pointer movement since enable yet)');
                    return Clutter.EVENT_STOP;
                }
                let direction = (dir === Clutter.ScrollDirection.UP) ? 'up' : 'down';
                let vol = Volume.stepVolume(direction);
                let muted = Volume.getMuted();
                // Sync radio's mpv volume
                CinemixRadio._volume = vol / 100;
                CinemixRadio._applyVolume();
                global.log('dock@brahim: brahim-osd-debug: calling OSD.showOSD(' + vol + ', ' + muted + ')');
                OSD.showOSD(vol, muted, false);
                return Clutter.EVENT_STOP;
            }
            return Clutter.EVENT_PROPAGATE;
        });

        tile.connect("destroy", function() {
            if (CinemixRadio._icon === iconArea) CinemixRadio._icon = null;
            if (CinemixRadio._tile === tile) CinemixRadio._tile = null;
        });

        return tile;
    },

    // ---- Launchpad-style station picker ----
    //
    // Replaces the old click-anchored dropdown (which grew straight up
    // from the click point with no height cap, so a full station list
    // could run off the top of the screen) with an overlay in the same
    // visual language as the Launchpad grid: a dimmed/tinted full-screen
    // backdrop (the exact same "launchpad-dark"/"launchpad-light" tint
    // class Launchpad's own _tintActor uses) behind a card of tappable
    // station tiles (icon + name, like Launchpad's app tiles) grouped by
    // category. The card's vertical space is capped using the same
    // dock-height/gap math Launchpad._applyPanelSafeGeometry uses to
    // reserve room for the standalone dock, so it never overlaps it, and
    // the tile grid scrolls internally if it doesn't all fit.
    //
    // Still reuses the dock's single shared _menu/_menuCatcher slot (see
    // _showContextMenu/_hideContextMenu in dock.js) so every other tile's
    // click handler keeps treating an open station picker exactly like
    // any other open dock menu - only the two actors assigned to that
    // slot are now the backdrop + card instead of a small dropdown.
    _showStationOverlay: function() {
        let dock = _dock();
        dock._hideContextMenu();
        dock._cancelThumbPreview();

        let isDark = true;
        try { isDark = _launchpad().settings.themeMode !== "light"; } catch(e) {}
        let themeClass = isDark ? "launchpad-dark" : "launchpad-light";

        let monitor = Main.layoutManager.primaryMonitor;

        // Same dock-height/gap math Launchpad._applyPanelSafeGeometry uses
        // to keep its own grid from running under the standalone dock.
        let bottomReserved = 40;
        try {
            if (Shared.STANDALONE_DOCK_MODE && dock.widget) {
                let dockSettings = SettingsStore.getDockSettings();
                let dockHeight = dock._maxHeight || 64;
                let dockGap = dockSettings.panelMode ? 0 : 8;
                bottomReserved = dockHeight + dockGap + 32;
            }
        } catch(e) {}

        let topMargin = 48;
        let availH = Math.max(260, monitor.height - topMargin - bottomReserved);
        let cardW = Math.min(560, monitor.width - 80);

        // Full-screen dimmed backdrop - same tint class Launchpad's own
        // overlay uses, so opening the picker reads as the same kind of
        // surface rather than a one-off popup.
        let backdrop = new St.Bin({
            reactive: true,
            style_class: "brahim-radio-overlay-backdrop " + themeClass,
            x: 0, y: 0,
            width: global.screen_width,
            height: global.screen_height
        });
        Main.uiGroup.add_actor(backdrop);
        backdrop.connect("button-press-event", function() {
            dock._hideContextMenu();
            return Clutter.EVENT_STOP;
        });

        let card = new St.BoxLayout({
            vertical: true,
            reactive: true,
            style_class: "brahim-radio-menu brahim-radio-overlay-card " + themeClass
        });
        // No press-stop handler needed here: the card is already stacked
        // above the backdrop (see set_child_below_sibling below), so a
        // click anywhere inside the card's bounds hits the card or one of
        // its tiles directly and never reaches the backdrop's own
        // button-press-event handler in the first place. (An earlier
        // version added a blanket stop here "just in case" - that instead
        // ended up swallowing the press half of every tile's click.)

        let header = new St.BoxLayout({ style_class: "brahim-radio-overlay-header" });
        header.add(new St.Label({
            text: Shared.requireSibling('utils')._("Radio Stations"),
            style_class: "brahim-radio-overlay-title"
        }), { expand: true, x_fill: true, y_align: St.Align.MIDDLE });
        let closeButton = new St.Button({
            style_class: "brahim-radio-overlay-close",
            reactive: true,
            track_hover: true,
            child: new St.Icon({ icon_name: "window-close-symbolic", icon_size: 12 })
        });
        closeButton.connect("clicked", function() {
            dock._hideContextMenu();
        });
        header.add(closeButton, { expand: false, x_fill: false, y_align: St.Align.MIDDLE });
        card.add(header, { x_fill: true });

        let scroll = new St.ScrollView({
            style_class: "brahim-radio-overlay-scroll",
            x_fill: true,
            y_fill: true,
            hscrollbar_policy: St.PolicyType.NEVER,
            vscrollbar_policy: St.PolicyType.AUTOMATIC
        });
        // Belt-and-braces manual scroll handling: St.ScrollView's own
        // kinetic scroll can end up not firing when nested this deep
        // under a reactive card/backdrop stack, which is what made the
        // grid look unscrollable even with a visible scrollbar track.
        // Driving the adjustment directly here guarantees the wheel
        // always moves the list.
        scroll.connect("scroll-event", function(actor, event) {
            let adjustment = scroll.vscroll ? scroll.vscroll.adjustment : null;
            if (!adjustment) return Clutter.EVENT_PROPAGATE;
            let direction = event.get_scroll_direction();
            let step = (adjustment.page_size || 200) * 0.2;
            if (direction === Clutter.ScrollDirection.UP) {
                adjustment.value = Math.max(adjustment.lower, adjustment.value - step);
                return Clutter.EVENT_STOP;
            } else if (direction === Clutter.ScrollDirection.DOWN) {
                adjustment.value = Math.min(adjustment.upper - adjustment.page_size, adjustment.value + step);
                return Clutter.EVENT_STOP;
            }
            return Clutter.EVENT_PROPAGATE;
        });

        let list = new St.BoxLayout({ vertical: true, style_class: "brahim-radio-overlay-list" });
        scroll.add_actor(list);
        card.add(scroll, { expand: true, x_fill: true, y_fill: true });

        let currentId = CinemixRadio._currentStationId;

        const COLUMNS = 4;
        const TILE_SPACING = 16;
        // BUGFIX: this used to size the grid as if the scrollbar took up
        // no horizontal space (only .brahim-radio-overlay-scroll's 2px
        // padding was reserved). Whenever a category actually had enough
        // stations to need scrolling, the real native scrollbar (well
        // wider than 2px) overlapped the rightmost tile column, and since
        // the scrollbar is reactive, it silently ate clicks meant for
        // those tiles - which is why station tiles seemed clickable in
        // some categories/positions but not others. Reserve real room for
        // it (kept in sync with the wider padding added to
        // .brahim-radio-overlay-scroll in stylesheet.css) so the grid
        // never extends underneath it.
        const SCROLLBAR_RESERVED = 16;
        let innerW = cardW - 40 - SCROLLBAR_RESERVED;
        let tileSize = Math.max(68, Math.floor((innerW - TILE_SPACING * (COLUMNS - 1)) / COLUMNS));
        let iconSize = Math.round(tileSize * 0.4);
        // BUGFIX: station tiles previously had no explicit height, only a
        // width - so each tile's cell size in the GridLayout was driven by
        // its own natural/preferred height, which differs tile to tile
        // (a station name that wraps to two lines vs. one; the active
        // station additionally carries a "Playing" checkmark line). Text
        // wrapping's preferred-height is notoriously unreliable to query
        // before an actor has an actual allocated width, so a wrapped
        // label's real rendered height could end up taller than what the
        // grid computed the row/cell to be - spilling its paint into the
        // neighboring tile below without spilling its clickable/hoverable
        // hit area (that stays exactly at the actor's own, too-small,
        // allocated box). That's what made a station's name sometimes
        // visible but not clickable/hoverable in that same spot - most
        // noticeably for longer names. Giving every tile the same fixed,
        // generous height (like Launchpad's own app tiles, which reliably
        // hover/click in the same kind of grid) removes the ambiguity
        // entirely: every cell in the grid is identical up front.
        let tileHeight = iconSize + 44;

        let byCategory = {};
        let categoryOrder = [];
        STATIONS.forEach(function(station) {
            if (!byCategory[station.category]) {
                byCategory[station.category] = [];
                categoryOrder.push(station.category);
            }
            byCategory[station.category].push(station);
        });

        categoryOrder.forEach(function(category) {
            let categoryHeader = new St.Label({
                text: Shared.requireSibling('utils')._(CATEGORY_LABELS[category] || category),
                style_class: "brahim-radio-menu-header"
            });
            list.add(categoryHeader, { x_fill: true });

            let gridLayout = new Clutter.GridLayout({
                orientation: Clutter.Orientation.HORIZONTAL,
                column_spacing: TILE_SPACING,
                row_spacing: TILE_SPACING
            });
            let gridBox = new Clutter.Actor({ layout_manager: gridLayout });
            let column = 0, row = 0;
            byCategory[category].forEach(function(station) {
                let isActive = (station.id === currentId);
                let tile = CinemixRadio._createStationTile(station, isActive, tileSize, tileHeight, iconSize, isDark, dock);
                gridLayout.attach(tile, column, row, 1, 1);
                column++;
                if (column >= COLUMNS) { column = 0; row++; }
            });
            let gridWrapper = new St.Bin({ child: gridBox, x_fill: false, x_align: St.Align.START });
            list.add(gridWrapper, { x_fill: true });
        });

        Main.uiGroup.add_actor(card);

        card.set_width(cardW);
        try {
            let headerH = (header.get_preferred_height(-1)[1]) || 40;
            let maxScrollH = Math.max(160, availH - headerH - 24);
            let [minH, natH] = list.get_preferred_height(cardW - 20);
            let contentH = natH || minH || maxScrollH;
            scroll.set_height(Math.min(contentH, maxScrollH));
        } catch(e) {
            scroll.set_height(320);
        }

        let [cardW2, cardH] = card.get_size();
        let cardX = Math.round(monitor.x + (monitor.width - cardW2) / 2);
        // Bottom-anchored within the reserved band (just clear of the
        // dock), so the picker opens right above the radio icon instead
        // of floating in the middle of the screen with a big gap under it.
        let cardY = Math.round(monitor.y + topMargin + Math.max(0, availH - cardH));
        card.set_position(cardX, cardY);

        // Light fade/scale-in, matching Launchpad's own open animation.
        card.set_pivot_point(0.5, 0.5);
        card.opacity = 0;
        card.scale_x = 0.94;
        card.scale_y = 0.94;
        backdrop.opacity = 0;
        if (card.ease) {
            card.ease({ opacity: 255, scale_x: 1, scale_y: 1, duration: 150, mode: Clutter.AnimationMode.EASE_OUT_QUAD });
        } else {
            card.opacity = 255; card.scale_x = 1; card.scale_y = 1;
        }
        if (backdrop.ease) {
            backdrop.ease({ opacity: 255, duration: 150, mode: Clutter.AnimationMode.EASE_OUT_QUAD });
        } else {
            backdrop.opacity = 255;
        }

        dock._menu = card;
        dock._menuCatcher = backdrop;
        Main.uiGroup.set_child_below_sibling(backdrop, card);

        let escId = global.stage.connect("key-press-event", function(actor, event) {
            if (event.get_key_symbol() === Clutter.KEY_Escape) {
                dock._hideContextMenu();
                return Clutter.EVENT_STOP;
            }
            return Clutter.EVENT_PROPAGATE;
        });
        backdrop.connect("destroy", function() {
            try { global.stage.disconnect(escId); } catch(e) {}
        });
    },

    // A single Launchpad-style tile (icon on top, name below) for the
    // station grid built by _showStationOverlay(). Tapping it selects and
    // plays the station, same as a row click in the old dropdown did.
    _createStationTile: function(station, isActive, tileSize, tileHeight, iconSize, isDark, dock) {
        let tile = new St.BoxLayout({
            vertical: true,
            reactive: true,
            // Matches Launchpad's own app tiles (_createTile in
            // launchpad.js), which reliably hover/click in the same kind
            // of packed GridLayout - track_hover works fine here once
            // every tile has the same fixed width AND height (see
            // tileHeight above); the earlier manual enter/leave workaround
            // was compensating for tiles whose height varied instead.
            track_hover: true,
            style_class: "brahim-radio-overlay-tile" + (isActive ? " brahim-radio-overlay-tile-active" : ""),
            width: tileSize,
            height: tileHeight
        });
        tile.connect("enter-event", function() {
            tile.add_style_class_name("brahim-radio-overlay-tile-hover");
            return Clutter.EVENT_PROPAGATE;
        });
        tile.connect("leave-event", function() {
            tile.remove_style_class_name("brahim-radio-overlay-tile-hover");
            return Clutter.EVENT_PROPAGATE;
        });

        let iconArea = new St.DrawingArea({ style_class: "brahim-radio-overlay-tile-icon" });
        iconArea.set_size(iconSize, iconSize);
        iconArea.connect("repaint", function(area) {
            let cr = area.get_context();
            let box = area.get_allocation_box();
            let W = box.x2 - box.x1, H = box.y2 - box.y1;
            if (W < 2 || H < 2) { cr.$dispose(); return; }
            let rgba = isDark ? [1, 1, 1, 0.92] : [0.11, 0.11, 0.12, 0.92];
            RadioIcons.drawStationIcon(cr, W, H, "radio", rgba[0], rgba[1], rgba[2], rgba[3]);
        });
        let iconBin = new St.Bin({ child: iconArea, x_align: St.Align.MIDDLE });
        tile.add(iconBin, { x_fill: false, x_align: St.Align.MIDDLE });

        let label = new St.Label({ text: station.name, style_class: "brahim-radio-overlay-tile-label" });
        label.clutter_text.set_line_wrap(true);
        tile.add(label, { x_fill: false, x_align: St.Align.MIDDLE });

        if (isActive) {
            let check = new St.Label({
                text: "\u2713 " + Shared.requireSibling('utils')._("Playing"),
                style_class: "brahim-radio-overlay-tile-check"
            });
            tile.add(check, { x_fill: false, x_align: St.Align.MIDDLE });
        }

        // BUGFIX: button-press-event (not button-release-event), matching
        // every other clickable tile in this codebase (dock icons,
        // Launchpad tiles). A press-driven tap is delivered up front,
        // before anything else (a scroll gesture, the pointer drifting a
        // pixel between press and release, etc.) gets a chance to change
        // what's under the cursor or otherwise interfere - which is what
        // made a station's tile only "sometimes" register a click.
        tile.connect("button-press-event", function() {
            dock._hideContextMenu();
            CinemixRadio._selectStation(station.id);
            return Clutter.EVENT_STOP;
        });

        return tile;
    },

    _applyVolume: function() {
        if (CinemixRadio._ipcOut) {
            try {
                CinemixRadio._ipcOut.put_string(
                    JSON.stringify({ command: ["set_property", "volume", Math.round(CinemixRadio._volume * 100)] }) + "\n",
                    null
                );
            } catch(e) {}
        }
    },

    _toggle: function() {
        if (CinemixRadio._state === "playing") {
            CinemixRadio._userStopped = true;
            CinemixRadio._stop();
        } else {
            CinemixRadio._userStopped = false;
            CinemixRadio._start();
        }
    },

    _start: function() {
        // If we're already connected to a running mpv - either one we
        // spawned this session, or one we reattached to via
        // _tryReattach() after a Cinnamon restart - ask it to quit
        // before tearing down and starting a new one. Without this,
        // switching stations (or just clicking Play) while reattached
        // would silently orphan the old stream instead of replacing it,
        // since there's no Gio.Subprocess handle to force_exit() below
        // in that case.
        if (CinemixRadio._ipcOut) {
            try { CinemixRadio._ipcOut.put_string('{"command":["quit"]}\n', null); } catch(e) {}
        }
        CinemixRadio._teardownIpc();
        if (CinemixRadio._proc) {
            try { CinemixRadio._proc.force_exit(); } catch(e) {}
            CinemixRadio._proc = null;
        }

        let station = CinemixRadio._currentStation();

        let runtimeDir = GLib.get_user_runtime_dir() || GLib.get_tmp_dir();
        CinemixRadio._ipcPath = GLib.build_filenamev([runtimeDir, "dock-brahim-radio-" + Date.now() + ".sock"]);
        try {
            let sockFile = Gio.File.new_for_path(CinemixRadio._ipcPath);
            if (sockFile.query_exists(null)) sockFile.delete(null);
        } catch(e) {}

        try {
            let proc = new Gio.Subprocess({
                argv: ["mpv", "--no-video", "--really-quiet", "--audio-fallback-to-null=no",
                       "--input-ipc-server=" + CinemixRadio._ipcPath, station.url],
                flags: Gio.SubprocessFlags.NONE
            });
            proc.init(null);
            CinemixRadio._proc = proc;
            CinemixRadio._startedAtMs = GLib.get_monotonic_time() / 1000;
            CinemixRadio._trackTitle = "";
            CinemixRadio._setState("playing");

            proc.wait_async(null, function(source, res) {
                try { source.wait_finish(res); } catch(e) {}
                if (CinemixRadio._proc !== source) return;
                CinemixRadio._proc = null;
                CinemixRadio._teardownIpc();
                if (CinemixRadio._userStopped) {
                    CinemixRadio._setState("idle");
                } else {
                    CinemixRadio._setState("error");
                }
                CinemixRadio._userStopped = false;
            });

            GLib.timeout_add(GLib.PRIORITY_DEFAULT, 400, function() {
                if (CinemixRadio._proc === proc) CinemixRadio._connectIpc(CinemixRadio._ipcPath, 0);
                return GLib.SOURCE_REMOVE;
            });
        } catch(e) {
            global.logError("dock@brahim: radio.js: failed to start " + station.name + " stream (is mpv installed?): " + e);
            CinemixRadio._proc = null;
            CinemixRadio._setState("error");
        }
    },

    _stop: function() {
        CinemixRadio._userStopped = true;
        let sentQuit = false;
        if (CinemixRadio._ipcOut) {
            try {
                CinemixRadio._ipcOut.put_string('{"command":["quit"]}\n', null);
                sentQuit = true;
            } catch(e) {}
        }
        CinemixRadio._teardownIpc();

        if (CinemixRadio._proc) {
            if (!sentQuit) {
                try { CinemixRadio._proc.force_exit(); } catch(e) {}
            } else {
                let proc = CinemixRadio._proc;
                GLib.timeout_add(GLib.PRIORITY_DEFAULT, 800, function() {
                    if (CinemixRadio._proc === proc) {
                        try { proc.force_exit(); } catch(e) {}
                    }
                    return GLib.SOURCE_REMOVE;
                });
            }
        }

        CinemixRadio._trackTitle = "";
        CinemixRadio._setState("idle");
    },

    _connectIpc: function(path, attempt) {
        if (!CinemixRadio._proc) return;

        let address = new Gio.UnixSocketAddress({ path: path });
        let client = new Gio.SocketClient();
        client.connect_async(address, null, function(source, res) {
            let conn;
            try {
                conn = source.connect_finish(res);
            } catch(e) {
                if (attempt < 8 && CinemixRadio._proc) {
                    GLib.timeout_add(GLib.PRIORITY_DEFAULT, 300, function() {
                        CinemixRadio._connectIpc(path, attempt + 1);
                        return GLib.SOURCE_REMOVE;
                    });
                }
                return;
            }
            if (!CinemixRadio._proc) {
                try { conn.close(null); } catch(e2) {}
                return;
            }

            CinemixRadio._ipcConnection = conn;
            CinemixRadio._ipcOut = new Gio.DataOutputStream({ base_stream: conn.get_output_stream() });
            CinemixRadio._ipcIn = new Gio.DataInputStream({ base_stream: conn.get_input_stream() });

            try {
                CinemixRadio._ipcOut.put_string('{"command":["observe_property",1,"media-title"]}\n', null);
            } catch(e) {}

            CinemixRadio._applyVolume();
            CinemixRadio._readIpcLine();
        });
    },

    _readIpcLine: function() {
        if (!CinemixRadio._ipcIn) return;
        let stream = CinemixRadio._ipcIn;
        stream.read_line_async(GLib.PRIORITY_DEFAULT, null, function(source, res) {
            if (CinemixRadio._ipcIn !== source) return;
            let line;
            try {
                [line] = source.read_line_finish_utf8(res);
            } catch(e) {
                CinemixRadio._onIpcStreamEnded();
                return;
            }
            if (line === null) {
                CinemixRadio._onIpcStreamEnded();
                return;
            }
            CinemixRadio._handleIpcLine(line);
            CinemixRadio._readIpcLine();
        });
    },

    // Only matters when there's no _proc handle (i.e. a reattached
    // stream - see _tryReattach): for a stream we spawned ourselves this
    // session, proc.wait_async()'s callback is already the authoritative
    // place that flips state on exit, so defer to it instead of racing it.
    _onIpcStreamEnded: function() {
        if (CinemixRadio._proc) return;
        CinemixRadio._teardownIpc();
        CinemixRadio._setState(CinemixRadio._userStopped ? "idle" : "error");
        CinemixRadio._userStopped = false;
    },

    _handleIpcLine: function(line) {
        let msg;
        try { msg = JSON.parse(line); } catch(e) { return; }
        if (msg.event === "property-change" && msg.name === "media-title" && typeof msg.data === "string") {
            CinemixRadio._trackTitle = msg.data;
            if (CinemixRadio._state !== "playing") CinemixRadio._setState("playing");
            CinemixRadio._pushMediaControlsUpdate();
        }
    },

    _teardownIpc: function() {
        if (CinemixRadio._ipcConnection) {
            try { CinemixRadio._ipcConnection.close(null); } catch(e) {}
        }
        CinemixRadio._ipcConnection = null;
        CinemixRadio._ipcOut = null;
        CinemixRadio._ipcIn = null;
        if (CinemixRadio._ipcPath) {
            try {
                let f = Gio.File.new_for_path(CinemixRadio._ipcPath);
                if (f.query_exists(null)) f.delete(null);
            } catch(e) {}
            CinemixRadio._ipcPath = null;
        }
    },

    _setState: function(state) {
        if (CinemixRadio._state === state) return;
        CinemixRadio._state = state;
        if (state === "playing") {
            SettingsStore.saveRadioRuntimeIpcPath(CinemixRadio._ipcPath || "");
        } else {
            SettingsStore.saveRadioRuntimeIpcPath("");
        }
        CinemixRadio._applyIconState();
        CinemixRadio._syncMediaControls();
    },

    // Colors mirror the old CSS classes (.brahim-radio-icon-playing /
    // -error / neutral .brahim-media-icon white) so the drawn glyph reads
    // exactly the same as the previous St.Icon-based one did.
    _iconColorRGBA: function() {
        if (CinemixRadio._state === "playing") return [0x34 / 255, 0xc7 / 255, 0x59 / 255, 1];
        if (CinemixRadio._state === "error")   return [0xff / 255, 0x3b / 255, 0x30 / 255, 1];
        return [1, 1, 1, 1];
    },

    _applyIconState: function() {
        if (!CinemixRadio._icon) return;
        CinemixRadio._icon.queue_repaint();
    },

    _mediaAdapter: function() {
        let station = CinemixRadio._currentStation();
        return {
            isRadio: true,
            identity: station.name + " Radio",
            songTitle: CinemixRadio._trackTitle || (station.name + " Radio"),
            songArtist: "",
            artUrl: station.logoUrl || "",
            isPlaying: CinemixRadio._state === "playing",
            mediaServerPlayer: null
        };
    },

    _syncMediaControls: function() {
        let media = _media();
        let players = media._players;
        let isUp = !!players[RADIO_PLAYER_KEY];
        let shouldBeUp = (CinemixRadio._state === "playing");

        if (shouldBeUp && !isUp) {
            let hadNone = Object.keys(players).length === 0;
            players[RADIO_PLAYER_KEY] = CinemixRadio._mediaAdapter();
            if (hadNone) media._activeName = RADIO_PLAYER_KEY;
            media._notifyDockOfListChange();
        } else if (!shouldBeUp && isUp) {
            delete players[RADIO_PLAYER_KEY];
            if (media._activeName === RADIO_PLAYER_KEY) {
                let remaining = Object.keys(players);
                media._activeName = remaining.length ? remaining[remaining.length - 1] : null;
            }
            media._notifyDockOfListChange();
        }
    },

    _pushMediaControlsUpdate: function() {
        let media = _media();
        if (!media._players[RADIO_PLAYER_KEY]) return;
        media._players[RADIO_PLAYER_KEY] = CinemixRadio._mediaAdapter();
        media._updateWidget();
    }
};
