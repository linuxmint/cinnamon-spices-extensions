// volume.js
// -*- mode: js; js-indent-level: 4; indent-tabs-mode: nil -*-
//
// System-volume backend for the radio docklet's scroll-to-adjust handler
// (see radio.js's dock tile "scroll-event" listener, which calls
// Volume.stepVolume()/Volume.getMuted()). Talks to the default
// PulseAudio/PipeWire-pulse sink via `pactl`, following the same _sh
// (sync, parse output) / _run (fire-and-forget) shell-helper pattern
// already used elsewhere in this extension (utils.js, dock.js's
// screen-blank handler).
//
// Deliberately PULL-ONLY: every function below runs a shell command and
// returns a value the moment it's called. Nothing here subscribes to
// sink-change signals, watches a mixer control, or does anything at
// module-load time - so it can't itself be the source of a volume OSD
// firing before the user has touched anything. (This file previously
// got clobbered with a stray copy of welcome.js's overlay/color-cycle
// code - see summary.md - which is why stepVolume/getMuted didn't exist
// at all until this rewrite.)

const GLib = imports.gi.GLib;

const MIN_VOLUME = 0;
const MAX_VOLUME = 150; // matches OSD_MAX_VOL in osd.js (allows boosting past 100%)
const DEFAULT_STEP = 5;
const SINK = "@DEFAULT_SINK@";

function _sh(cmd) {
    try {
        let [ok, out] = GLib.spawn_command_line_sync(cmd);
        if (ok && out) return imports.byteArray.toString(out).trim();
    } catch (e) {}
    return '';
}

function _run(cmd) {
    try { GLib.spawn_command_line_async(cmd); } catch (e) {}
}

function _clamp(v) {
    return Math.max(MIN_VOLUME, Math.min(MAX_VOLUME, Math.round(v)));
}

let _hasPactl = null;
function _pactlAvailable() {
    if (_hasPactl === null) _hasPactl = !!_sh("which pactl 2>/dev/null");
    return _hasPactl;
}

// Parses the first "NN%" out of `pactl get-sink-volume`'s multi-channel
// output. All channels are kept in lockstep by setVolume()/stepVolume()
// below (pactl applies a single percentage to every channel), so the
// first match is representative of the whole sink.
function getVolume() {
    if (!_pactlAvailable()) return 0;
    let out = _sh("pactl get-sink-volume " + SINK);
    let match = /(\d+)%/.exec(out);
    if (!match) return 0;
    return _clamp(parseInt(match[1], 10));
}

function getMuted() {
    if (!_pactlAvailable()) return false;
    let out = _sh("pactl get-sink-mute " + SINK);
    return /yes/i.test(out);
}

function setVolume(percent) {
    let clamped = _clamp(percent);
    if (_pactlAvailable()) {
        _run("pactl set-sink-volume " + SINK + " " + clamped + "%");
    }
    return clamped;
}

function setMuted(muted) {
    if (_pactlAvailable()) {
        _run("pactl set-sink-mute " + SINK + " " + (muted ? "1" : "0"));
    }
}

// Adjusts the default sink's volume by one step in `direction`
// ('up'/'down'), unmuting first so a scroll while muted takes audible
// and visible (OSD) effect immediately instead of silently changing a
// muted level underneath. Returns the resulting volume percent (0-150)
// so callers (radio.js) can feed it straight into
// CinemixRadio._applyVolume() and OSD.showOSD().
function stepVolume(direction, step) {
    let delta = (step !== undefined ? step : DEFAULT_STEP);
    if (direction === 'down') delta = -delta;

    if (getMuted()) setMuted(false);

    let current = getVolume();
    let next = _clamp(current + delta);
    return setVolume(next);
}
