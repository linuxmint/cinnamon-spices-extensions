// dock.js
// -*- mode: js; js-indent-level: 4; indent-tabs-mode: nil -*-

const Main = imports.ui.main;
const Mainloop = imports.mainloop;
const Meta = imports.gi.Meta;
const Cinnamon = imports.gi.Cinnamon;
const Clutter = imports.gi.Clutter;
const Tweener = imports.ui.tweener;
const St = imports.gi.St;
const Gtk = imports.gi.Gtk;
const Gdk = imports.gi.Gdk;
const Gio = imports.gi.Gio;
const Util = imports.misc.util;
const WindowUtils = imports.misc.windowUtils;
const GLib = imports.gi.GLib;
const Pango = imports.gi.Pango;
const Lang = imports.lang;

const Shared = imports.shared;
const Utils = imports.utils;
const SettingsStore = imports.settingsStore;
const WindowEffects = imports.windowEffects.WindowEffects;

// Panel mode spans the monitor edge-to-edge, but leaving literally zero
// margin meant the trailing docklet icons could end up sitting exactly
// flush against - or, once measurement rounding is added in, a hair past
// - the physical right edge of the screen. Force a small real margin on
// both sides (mirroring each other) instead of trusting the fit
// calculation alone to land exactly on monitor.width every time.
const PANEL_MODE_SIDE_MARGIN = 10;

// Lazy accessors for sibling xlet files - see shared.js's
// requireSibling() doc comment. StandaloneDock and Launchpad reference
// each other (the dock hosts a Launchpad tile; Launchpad reserves space
// above the dock and hides/reveals it), so neither can be a plain
// top-level `const` here without a load-order/circular-import problem.
function _launchpad() {
    return Shared.requireSibling('launchpad').Launchpad;
}
function _media() {
    return Shared.requireSibling('mediaDocklet').MediaControlsDocklet;
}
function _radio() {
    return Shared.requireSibling('radio').CinemixRadio;
}
function _weather() {
    return Shared.requireSibling('weather').WeatherDocklet;
}

// ---- Bundled Cinnamon Coverflow Alt-Tab switcher, used to drive the
// dock's scroll-to-cycle-windows feature ----
// coverflowSwitcher.js is shipped verbatim (unmodified) alongside this
// extension - it's the same js/ui/appSwitcher/coverflowSwitcher.js
// Cinnamon itself ships, imported here as a sibling xlet file so the
// dock always shows the real coverflow animation on scroll, regardless
// of which Alt-Tab style the user has configured in System Settings.
const AppSwitcherBase = imports.ui.appSwitcher.appSwitcher;
let CoverflowSwitcherModule = null;
let DockCoverflowSwitcher = null;

function _loadCoverflowSwitcher() {
    try {
        let oldSearchPath = imports.searchPath.slice();
        imports.searchPath = [Shared.EXTENSION_DIR];
        CoverflowSwitcherModule = imports.coverflowSwitcher;
        imports.searchPath = oldSearchPath;
    } catch (e) {
        global.logError("dock@brahim: failed to load bundled coverflowSwitcher.js: " + e);
        CoverflowSwitcherModule = null;
        return;
    }

    if (!CoverflowSwitcherModule || !CoverflowSwitcherModule.CoverflowSwitcher) {
        CoverflowSwitcherModule = null;
        return;
    }

    let AppSwitcher3DBase = imports.ui.appSwitcher.appSwitcher3D;

    function Ctor(reversed) {
        this._dockScrollReversed = !!reversed;
        try {
            this._init({
                get_name: function() { return "switch-windows"; },
                get_mask: function() { return 0; }
            });
        } catch (e) {
            // _init() chains AppSwitcher._init -> AppSwitcher3D._init (which
            // calls _setupModal(), grabbing input via Main.pushModal()) ->
            // CoverflowSwitcher._init (which reads this._activeMonitor.width/
            // height). If the modal grab succeeds but anything after it
            // throws (e.g. a null/invalid active monitor), Main.pushModal()
            // is left unmatched - only destroy() calls Main.popModal(), and
            // destroy() was never reached. Left like that, the grab captures
            // ALL desktop input (keyboard + pointer) until something else
            // forces a new grab - e.g. clicking a panel applet's own popup
            // menu, which does its own Main.pushModal() - which is exactly
            // the "dock freezes, clicking a panel applet unfreezes it"
            // symptom reported. Defensively release everything here so a
            // failed construction can never leave a dangling grab.
            global.logError("dock@brahim: DockCoverflowSwitcher failed to initialize: " + e);
            try {
                if (this._haveModal) {
                    Main.popModal(this.actor);
                    this._haveModal = false;
                }
            } catch (e2) {}
            try {
                if (this._background) {
                    global.overlay_group.remove_actor(this._background);
                }
            } catch (e2) {}
            try {
                if (this.actor) {
                    Main.uiGroup.remove_actor(this.actor);
                    this.actor.destroy();
                }
            } catch (e2) {}
            throw e;
        }
    }

    Ctor.prototype = {
        __proto__: CoverflowSwitcherModule.CoverflowSwitcher.prototype,

        // The stock switcher is built to be driven by a real held-down
        // Alt+Tab keypress: appSwitcher.js's _setupModal() checks that
        // the binding's modifier is still held right after the modal
        // grab succeeds, and closes the switcher immediately if not.
        // Scroll-driven use never holds a modifier, so that check
        // would otherwise close the switcher before it's shown.
        // Skipping it is safe - the stock class already closes on a
        // preview click, a click elsewhere, or Escape.
        _failedGrabAction: function() {},

        // Our fake binding's get_mask() returns 0, so _modifierMask is
        // 0, so the stock _setupModal()'s check "!(mods & this._modifierMask)"
        // is *always* true (mods & 0 is always 0) - regardless of the
        // no-op above, that stock method still does `return false` right
        // after, which means it NEVER schedules the Mainloop.timeout_add
        // that calls _show(). Net effect: the modal grab succeeds (so
        // scrolling gets swallowed) but nothing is ever shown - which is
        // exactly the "lost both scrolling and the animation" symptom.
        // Reimplemented here with the modifier check removed entirely,
        // since a scroll-driven switcher never has a modifier to check.
        _setupModal: function() {
            this._haveModal = Main.pushModal(this.actor);
            if (!this._haveModal) {
                this._haveModal = Main.pushModal(this.actor, global.get_current_time(), Meta.ModalOptions.POINTER_ALREADY_GRABBED);
            }
            if (!this._haveModal) {
                this._failedGrabAction();
            } else {
                this._disableHover();
                this.actor.connect('key-press-event', Lang.bind(this, this._keyPressEvent));
                this.actor.connect('key-release-event', Lang.bind(this, this._keyReleaseEvent));
                this.actor.connect('scroll-event', Lang.bind(this, this._scrollEvent));
                this.actor.connect('button-press-event', Lang.bind(this, this.destroy));
                let delay = global.settings.get_int("alttab-switcher-delay");
                this._initialDelayTimeoutId = Mainloop.timeout_add(delay, Lang.bind(this, this._show));
            }
            return this._haveModal;
        },

        // The stock _show() always steps to the *next* window first,
        // regardless of the invoking direction. When the dock was
        // scrolled "up" (previous), redirect that one internal call to
        // _previous() instead, then restore _next() immediately after
        // - the rest of _show()'s setup is untouched.
        // This is called via Mainloop.timeout_add from _setupModal(), i.e.
        // asynchronously, outside the constructor's own try/catch - so any
        // exception here needs its own defensive cleanup, or the modal
        // grab taken in _setupModal() would be left stuck the same way
        // described there.
        _show: function() {
            try {
                if (this._dockScrollReversed) {
                    let realNext = this._next;
                    this._next = this._previous;
                    try {
                        AppSwitcher3DBase.AppSwitcher3D.prototype._show.call(this);
                    } finally {
                        this._next = realNext;
                    }
                } else {
                    AppSwitcher3DBase.AppSwitcher3D.prototype._show.call(this);
                }
            } catch (e) {
                global.logError("dock@brahim: DockCoverflowSwitcher failed to show: " + e);
                try { this.destroy(); } catch (e2) {}
            }
        },

        _onDestroy: function() {
            AppSwitcher3DBase.AppSwitcher3D.prototype._onDestroy.call(this);
            if (StandaloneDock._scrollSwitcher === this) {
                StandaloneDock._scrollSwitcher = null;
            }
        },

        // Stock AppSwitcher3D._setCurrentWindow() (appSwitcher3D.js) places
        // the window-title label at TITLE_POSITION = 7/8 of the monitor
        // height - i.e. right in the bottom strip of the screen, which is
        // exactly where StandaloneDock lives. That's why the title text
        // and app icon were rendering on top of (and hiding) dock icons
        // whenever the scroll-driven Coverflow switcher was open.
        // Overridden here to: (1) combine the icon + label into a single
        // macOS-style frosted "pill" instead of two separately-positioned
        // actors, and (2) anchor that pill near the TOP of the monitor,
        // safely above both the coverflow previews (vertically centered)
        // and the dock (bottom edge) - so nothing ever overlaps.
        _setCurrentWindow: function() {
            const PILL_ICON_SIZE = 34;
            const PILL_TOP_POSITION = 0.09; // 9% down from the top of the monitor

            let monitor = this._activeMonitor;
            let win = this._windows[this._currentIndex];

            // Fade out and drop the previous pill, same cross-fade the
            // stock implementation used for its label/icon pair.
            if (this._windowTitle) {
                let oldPill = this._windowTitle;
                oldPill.ease({
                    opacity: 0,
                    duration: AppSwitcher3DBase.ANIMATION_TIME,
                    mode: Clutter.AnimationMode.EASE_OUT_QUAD,
                    onComplete: () => this.actor.remove_actor(oldPill)
                });
            }

            let isDark = !StandaloneDock._isDockColorLight();
            let themeClass = isDark ? "launchpad-dark" : "launchpad-light";

            let pill = new St.BoxLayout({
                style_class: 'brahim-cf-title-pill',
                opacity: 0
            });
            // Use the dock's actual rendered background color (same color
            // + same transparency it shows itself), not a separately
            // invented alpha, so the pill genuinely matches the dock.
            try {
                let tinted = StandaloneDock._getDockColorWithAlpha();
                if (tinted) pill.set_style("background-color: " + tinted + " !important;");
            } catch(e) {}

            let app = this._tracker.get_window_app(win);
            let icon = app ? app.create_icon_texture_for_window(PILL_ICON_SIZE, win) : null;
            if (!icon) {
                icon = new St.Icon({
                    icon_name: 'applications-other',
                    icon_type: St.IconType.FULLCOLOR,
                    icon_size: PILL_ICON_SIZE
                });
            }
            icon.add_style_class_name('brahim-cf-title-icon');

            let label = new St.Label({
                style_class: 'brahim-cf-title-label ' + themeClass,
                text: win.get_title() || ''
            });
            label.set_style("max-width:" + Math.round(monitor.width * 0.6) + "px; background-color: transparent !important;");
            label.clutter_text.ellipsize = imports.gi.Pango.EllipsizeMode.END;

            pill.add_actor(icon);
            pill.add_actor(label);

            this.actor.add_actor(pill);
            pill.ease({
                opacity: 255,
                duration: AppSwitcher3DBase.ANIMATION_TIME,
                mode: Clutter.AnimationMode.EASE_OUT_QUAD
            });

            // Horizontally centered, fixed distance from the top edge.
            pill.x = Math.round((monitor.width - pill.get_width()) / 2);
            pill.y = Math.round(monitor.height * PILL_TOP_POSITION);

            this._icon = icon;
            // _hide()/_onDestroy() in appSwitcher3D.js still reference both
            // this._windowTitle and this._applicationIconBox directly
            // (e.g. "this._windowTitle.hide(); this._applicationIconBox.hide();")
            // - keep both pointed at the single combined pill so those
            // calls keep working unmodified.
            this._windowTitle = pill;
            this._applicationIconBox = pill;
        }
    };

    DockCoverflowSwitcher = Ctor;
}


var StandaloneDock = {
    widget: null,
    box: null,
    _appSystem: null,
    _signals: [],
    _hiddenPanels: [],
    _sourcePanel: null,
    _menu: null,
    _menuCatcher: null,
    _launchpadTile: null,
    _autoHideEnabled: false,
    _intellihideEnabled: false,
    _autoHidePoller: null,
    // PERF: _checkForMaximizedOrFullscreen() used to re-enumerate every
    // window on the active workspace on every single 100ms auto-hide/
    // intellihide poll tick (10x/second, for as long as either feature is
    // on) even though _monitorWindowStates() already wires up real Meta
    // signals (window-state-changed, window-created, window-unmanaged,
    // switch-workspace, notify::focus-window, showing-desktop-changed)
    // that fire exactly when this could have changed. These three fields
    // let the poll reuse a cached answer between those signals instead of
    // rescanning every window 10 times a second, while a periodic forced
    // refresh (see _maxOrFullscreenCacheMaxAgeMs below) still catches any
    // Cinnamon/Muffin build where one of those signals doesn't exist.
    _maxOrFullscreenCache: false,
    _maxOrFullscreenDirty: true,
    _maxOrFullscreenCacheAtMs: 0,
    _hideTimeoutId: null,
    _isHidden: false,
    _previewTimeoutId: null,
    _previewPopup: null,
    _previewCatcher: null,
    _previewBridge: null,
    _previewWatchdogId: null,
    _mediaPreviewTimeoutId: null,
    _trashTile: null,
    _fullscreenSignalIds: [],
    _revealTimeoutId: null,
    _tooltipTimeoutId: null,
    _tooltipPopup: null,
    _appTileEntries: [],
    _dragState: null,
    _scrollSignalId: null,

    enable: function() {
        _loadCoverflowSwitcher();
        StandaloneDock._appSystem = Cinnamon.AppSystem.get_default();
        StandaloneDock._hiddenPanels = [];
        StandaloneDock._sourcePanel = null;

        try {
            StandaloneDock._build();
            if (!StandaloneDock.widget) {
                throw new Error("StandaloneDock.widget was not created");
            }

            StandaloneDock._connectSignals();
            StandaloneDock._monitorWindowStates();
            StandaloneDock._connectScrollSwitcher();
            StandaloneDock.refresh();
            StandaloneDock._updateAutoHide();
            StandaloneDock._updatePanelStruts();

            // Reported bug: right after a full session restart, intellihide
            // sometimes never engages (dock doesn't hide for a maximized
            // window) until the user manually flips the Intellihide switch
            // off and back on in settings - which just re-runs
            // _updateAutoHide() above. That symptom points at a one-time
            // race very early in the session (monitor layout/window list
            // still settling right after login) rather than anything wrong
            // with the poll or the settings value itself, so instead of
            // chasing that race, automatically repeat the same re-arm a
            // manual toggle performs, once, a couple seconds after startup -
            // by then the session has settled and this reflects the exact
            // fix the manual toggle already provides, without requiring it.
            Mainloop.timeout_add(2000, function() {
                if (!StandaloneDock.widget) return false;
                try { StandaloneDock._updateAutoHide(); } catch(e) {}
                return false;
            });

            // Apply keyboard styling after initial setup
            Mainloop.idle_add(function() {
                StandaloneDock._applyKeyboardStyling();
                return false;
            });

            // TEMP DEBUG - remove once the dock is confirmed visible again.
            Mainloop.timeout_add(1500, function() {
                try {
                    let w = StandaloneDock.widget;
                    global.log("dock@brahim DEBUG: widget=" + w +
                        " parent=" + (w ? w.get_parent() : null) +
                        " visible=" + (w ? w.visible : null) +
                        " opacity=" + (w ? w.opacity : null) +
                        " pos=" + (w ? w.get_position() : null) +
                        " size=" + (w ? w.get_size() : null) +
                        " children=" + (w ? w.get_n_children() : null) +
                        " style=" + (w ? w.get_style() : null));
                    let m = Main.layoutManager.primaryMonitor;
                    global.log("dock@brahim DEBUG: monitor=" + (m ? (m.x+","+m.y+" "+m.width+"x"+m.height) : null) +
                        " isHidden=" + StandaloneDock._isHidden);
                } catch (e) {
                    global.log("dock@brahim DEBUG: error while inspecting widget: " + e);
                }
                return false;
            });
        } catch (e) {
            global.logError("dock@brahim: StandaloneDock failed to start: " + e);
            if (e && e.stack) global.logError(e.stack);
            StandaloneDock._teardown();
        }
    },

    disable: function() {
        StandaloneDock._hideContextMenu();

        if (StandaloneDock._launchpadTile) {
            let idx = _launchpad()._dockIcons.indexOf(StandaloneDock._launchpadTile);
            if (idx !== -1) _launchpad()._dockIcons.splice(idx, 1);
            StandaloneDock._launchpadTile = null;
        }

        StandaloneDock._teardown();
    },

    _teardown: function() {
        StandaloneDock._trashIconAvailability = null;
        if (StandaloneDock._applySettingsTimeoutId) {
            try { Mainloop.source_remove(StandaloneDock._applySettingsTimeoutId); } catch(e) {}
            StandaloneDock._applySettingsTimeoutId = null;
        }
        try { _radio()._stop(); } catch(e) {}
        try { StandaloneDock._cancelKillWindowPick(); } catch(e) {}
        try { StandaloneDock._disconnectSignals(); } catch(e) {}
        try { StandaloneDock._stopAutoHidePoll(); } catch(e) {}
        try { StandaloneDock._cancelHideTimeout(); } catch(e) {}
        try { StandaloneDock._cancelRevealTimeout(); } catch(e) {}
        try { StandaloneDock._hideThumbPreview(); } catch(e) {}
        try { StandaloneDock._cancelTooltip(); } catch(e) {}
        try { StandaloneDock._disconnectScrollSwitcher(); } catch(e) {}
        try {
            if (StandaloneDock._scrollSwitcher) {
                StandaloneDock._scrollSwitcher.destroy();
            }
        } catch(e) {}
        StandaloneDock._scrollSwitcher = null;
        try { 
            StandaloneDock._fullscreenSignalIds.forEach(function(entry) {
                // Entries used to be bare ids (always disconnected against
                // global.display, which silently failed for the
                // window_manager/screen signals and leaked them). Now each
                // entry is [ownerObject, id].
                try {
                    if (Array.isArray(entry)) {
                        entry[0].disconnect(entry[1]);
                    } else {
                        global.display.disconnect(entry);
                    }
                } catch(e) {}
            });
            StandaloneDock._fullscreenSignalIds = [];
        } catch(e) {}
        StandaloneDock._autoHideEnabled = false;
        StandaloneDock._intellihideEnabled = false;
        StandaloneDock._isHidden = false;

        if (StandaloneDock.widget) {
            try { Main.layoutManager.removeChrome(StandaloneDock.widget); } catch(e) {}
            try { StandaloneDock.widget.destroy(); } catch(e) {}
            StandaloneDock.widget = null;
            StandaloneDock.box = null;
        }

        StandaloneDock._hiddenPanels.forEach(function(panel) {
            try { if (panel && panel.actor) panel.actor.show(); } catch(e) {}
        });
        StandaloneDock._hiddenPanels = [];
        StandaloneDock._sourcePanel = null;
    },

    _maxHeight: 64,
    _iconSize: 44,
    _renderIconSize: 44,

    _computeSizing: function() {
        let s = SettingsStore.getDockSettings();
        StandaloneDock._iconSize = SettingsStore.clampIconSize(s.iconSize !== undefined ? s.iconSize : 48);
        // The size tiles actually render at. Normally equal to _iconSize
        // (the user's configured size), but refresh()/_fitIconSizeToMaxWidth()
        // may shrink it below that - never above - when the dock's natural
        // width would otherwise exceed the configured maximum dock width.
        StandaloneDock._renderIconSize = StandaloneDock._iconSize;
        // Tiles now center their icon in an expanding cell above a
        // bottom-pinned dot (see _createTile/_createLaunchpadTile/
        // _createTrashTile) rather than stacking icon+dot with fixed
        // padding, so this overhead is deliberately larger than the tiles'
        // bare minimum chrome (2px widget top pad + 0px tile top pad + 2px
        // icon-to-dot spacing + 5px dot + 0px tile bottom pad + 2px widget
        // bottom pad = 11px) - the extra ~7px is the slack that gets split
        // above/below the icon so it actually reads as vertically centered
        // instead of jammed against the top with zero headroom.
        let overhead = 18;
        let iconDrivenHeight = StandaloneDock._iconSize + overhead;
        // Respect the user's configured max height directly - only fall
        // back to the icon-driven height when nothing is configured yet.
        // Previously this was floored via Math.max(iconDrivenHeight, ...),
        // which silently discarded any requested value below icon size +
        // 18px, making the "Maximum dock height" slider a no-op in that
        // range (including the 74px default once icon size reached ~56px).
        let requested = s.dockMaxHeight !== undefined ? s.dockMaxHeight : iconDrivenHeight;
        StandaloneDock._maxHeight = SettingsStore.clampDockHeight(requested);
    },

    // accentRgb/accentT (optional) blend the dock's normal background
    // toward a per-app hover accent color - see _startAppAccent() below.
    // Omitted (the normal case), this behaves exactly as before.
    _buildStyle: function(accentRgb, accentT) {
        let s = SettingsStore.getDockSettings();
        let transparency = (s.transparency !== undefined ? s.transparency : 30) / 100.0;
        let dockColor = s.dockColor || "rgba(245, 255, 255, 1.0)";
        let borderRadius = (s.borderRadius !== undefined && s.borderRadius !== null) ? s.borderRadius : 12;
        let background = Utils.colorWithAlpha(dockColor, transparency);
        if (accentRgb && accentT) {
            background = Utils.blendTowardAccent(background, accentRgb, accentT, StandaloneDock._ACCENT_MAX_BLEND, 0.55);
        }
        let panelMode = s.panelMode || false;

        StandaloneDock._computeSizing();

        let style = "background-color: " + background + ";" +
               "box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.16)," +
               "inset 0 0 0 1px rgba(255, 255, 255, 0.06)," +
               "0 8px 24px rgba(0, 0, 0, 0.4);" +
               "height: " + StandaloneDock._maxHeight + "px;" +
               "max-height: " + StandaloneDock._maxHeight + "px;";

        if (panelMode) {
            // Previously hardcoded to 0, ignoring the user's border-radius
            // setting entirely. Panel mode spans the full monitor width and
            // sits flush against the bottom edge, so only the top corners
            // are ever visible - round those to the configured radius and
            // leave the bottom flush.
            style += "border-top-left-radius: " + borderRadius + "px;" +
                     "border-top-right-radius: " + borderRadius + "px;" +
                     "border-bottom-left-radius: 0px;" +
                     "border-bottom-right-radius: 0px;" +
                     "padding: 2px " + PANEL_MODE_SIDE_MARGIN + "px; margin: 0px;";
        } else {
            style += "border-radius: " + borderRadius + "px; padding: 2px 16px;";
        }

        return style;
    },

    _build: function() {
        StandaloneDock.widget = new St.BoxLayout({
            vertical: false,
            reactive: true,
            style_class: "brahim-standalone-dock",
            style: StandaloneDock._buildStyle()
        });
        StandaloneDock.box = StandaloneDock.widget;

        Main.layoutManager.addChrome(StandaloneDock.widget, {
            affectsStruts: false
        });
        
        StandaloneDock.widget.reactive = true;
        StandaloneDock.widget.can_focus = false;
        StandaloneDock._ensureInteractive();
    },

    _applySettingsTimeoutId: null,

    // Sliders (icon size, dock height, max width %, etc) fire a
    // "changed::" signal on every intermediate value while being
    // dragged - each one used to trigger an immediate, fully synchronous
    // applySettings() -> refresh() -> destroy_all_children()/
    // _populateTiles() (up to 8 measure/rebuild passes via
    // _fitIconSizeToMaxWidth) -> _reposition(). Doing that dozens of
    // times a second is what made the dock (and the desktop underneath
    // it, since this all runs on the main/UI thread) appear to freeze
    // while resizing. Coalesce rapid-fire calls into a single rebuild
    // ~90ms after the last change instead of one per tick.
    applySettings: function() {
        if (StandaloneDock._applySettingsTimeoutId) {
            Mainloop.source_remove(StandaloneDock._applySettingsTimeoutId);
            StandaloneDock._applySettingsTimeoutId = null;
        }
        StandaloneDock._applySettingsTimeoutId = Mainloop.timeout_add(90, function() {
            StandaloneDock._applySettingsTimeoutId = null;
            StandaloneDock._applySettingsNow();
            return false;
        });
    },

    _applySettingsNow: function() {
        if (!StandaloneDock.widget) return;
        StandaloneDock.widget.set_style(StandaloneDock._buildStyle());
        StandaloneDock._ensureInteractive();
        StandaloneDock.refresh();
        StandaloneDock._updateAutoHide();
        StandaloneDock._updatePanelStruts();
        // Re‑apply keyboard styling when dock settings change
        StandaloneDock._applyKeyboardStyling();
    },

    _updatePanelStruts: function() {
        // Panel mode should behave like a real Cinnamon panel - windows
        // maximize/tile against its edge instead of running underneath it
        // - UNLESS intellihide (or plain auto-hide) is on, since then the
        // dock moves on and off screen dynamically and a fixed strut would
        // leave a permanent dead zone / make windows "remember" space for
        // a dock that isn't there half the time.
        if (!StandaloneDock.widget) return;
        let s = SettingsStore.getDockSettings();
        let panelMode = !!s.panelMode;
        let shouldReserve = panelMode && !StandaloneDock._intellihideEnabled && !StandaloneDock._autoHideEnabled;
        try {
            Main.layoutManager._chrome.modifyActorParams(StandaloneDock.widget, { affectsStruts: shouldReserve });
        } catch(e) {}
    },
    
    _ensureInteractive: function() {
        if (StandaloneDock.widget) {
            // The container itself has no click handler of its own - only
            // the individual tiles do (_createTile/_createLaunchpadTile/
            // _createTrashTile each wire their own button-press-event).
            // Forcing the *container* reactive=true just means Clutter's
            // pointer-picking falls through to it (and it "wins", eating
            // the event) over every bit of empty background/spacer space
            // inside its bounds - including, in panel mode, the true
            // bottom-left screen corner where Cinnamon's own built-in
            // hotcorner (e.g. "Show Desktop") lives. That's what was
            // silently blocking it. In panel mode we leave the container
            // itself non-reactive; children that are actually meant to be
            // clickable (tiles, dots, separators - anything with its own
            // reactive flag) are still forced reactive below, so nothing
            // about tile clicking changes. Floating mode never touches a
            // screen corner, so it keeps the old behavior unchanged.
            let s = SettingsStore.getDockSettings();
            let panelMode = !!(s && s.panelMode);
            StandaloneDock.widget.reactive = !panelMode;
            StandaloneDock.widget.can_focus = false;
            let children = StandaloneDock.widget.get_children();
            children.forEach(function(child) {
                if (child.reactive !== undefined) {
                    child.reactive = true;
                }
                if (child.get_children) {
                    let grandChildren = child.get_children();
                    grandChildren.forEach(function(gc) {
                        if (gc.reactive !== undefined) {
                            gc.reactive = true;
                        }
                    });
                }
            });
        }
    },

    // PERF: cached wrapper around _computeMaximizedOrFullscreen() - see the
    // _maxOrFullscreenCache/_maxOrFullscreenDirty field comments above.
    // Reused as-is if nothing dirtied it since the last check, forcibly
    // refreshed at most once every _MAX_OR_FULLSCREEN_CACHE_MAX_AGE_MS as a
    // safety net for any signal _monitorWindowStates() failed to bind on
    // this particular Cinnamon/Muffin build.
    _checkForMaximizedOrFullscreen: function() {
        let now = GLib.get_monotonic_time() / 1000;
        let tooOld = (now - StandaloneDock._maxOrFullscreenCacheAtMs) > StandaloneDock._MAX_OR_FULLSCREEN_CACHE_MAX_AGE_MS;
        if (!StandaloneDock._maxOrFullscreenDirty && !tooOld) {
            return StandaloneDock._maxOrFullscreenCache;
        }
        StandaloneDock._maxOrFullscreenDirty = false;
        StandaloneDock._maxOrFullscreenCacheAtMs = now;
        StandaloneDock._maxOrFullscreenCache = StandaloneDock._computeMaximizedOrFullscreen();
        return StandaloneDock._maxOrFullscreenCache;
    },

    _MAX_OR_FULLSCREEN_CACHE_MAX_AGE_MS: 1000,

    _computeMaximizedOrFullscreen: function() {
        try {
            let workspace = global.screen.get_active_workspace();
            if (!workspace) return false;
            let windows = workspace.list_windows();
            for (let i = 0; i < windows.length; i++) {
                let w = windows[i];
                if (!w) continue;
                // Only check NORMAL windows
                if (w.get_window_type && w.get_window_type() !== Meta.WindowType.NORMAL) continue;

                // showing_on_its_workspace() is Meta's own purpose-built
                // check for "would this window actually be visible right
                // now" - it internally accounts for both window.minimized
                // AND Cinnamon's "Show Desktop" hotcorner/edge mode (see
                // meta_window_showing_on_its_workspace() in Muffin's
                // window.c, which explicitly checks the workspace's
                // showing_desktop flag). Previously we only checked
                // w.minimized ourselves and tried to separately track
                // show-desktop mode via a signal, which depended on
                // guessing the right global object/signal name across
                // Cinnamon versions and kept failing. This single call
                // replaces all of that with the real, always-correct
                // source of truth straight from Meta.
                if (w.showing_on_its_workspace && !w.showing_on_its_workspace()) continue;
                // Fallback for any Meta binding that somehow lacks the
                // method above.
                if (!w.showing_on_its_workspace && w.minimized) continue;

                // Check if window is fullscreen OR maximized
                let isFullscreen = w.is_fullscreen ? w.is_fullscreen() : false;
                let isMaximized = (w.maximized_horizontally && w.maximized_vertically);
                if (isFullscreen || isMaximized) {
                    return true;
                }
            }
        } catch(e) {
            return false;
        }
        return false;
    },

    _monitorWindowStates: function() {
        try {
            let self = this;
            // NOTE: this used to call _concealDock()/_revealDock() directly,
            // which raced against the pointer poller in _checkAutoHidePointer
            // (also deciding to conceal/reveal on its own 100ms tick). Two
            // independent deciders fighting over the same widget is what
            // made the slide feel unresponsive/jittery. Now this is just a
            // trigger that asks the single source of truth to re-evaluate
            // immediately instead of waiting for the next poll tick.
            let handler = function() {
                self._maxOrFullscreenDirty = true;
                if (!self._intellihideEnabled && !self._autoHideEnabled) return;
                try { self._checkAutoHidePointer(); } catch(e) {}
            };
            
            // Monitor window state changes for fullscreen/maximized/minimized.
            // 'window-state-changed' doesn't exist on MetaDisplay on every
            // Cinnamon/Muffin build (confirmed failing here: "No signal
            // 'window-state-changed' on object 'MetaDisplay'"). Previously
            // this connect() call wasn't individually guarded, so on a build
            // that lacks it, the throw aborted every connect() below it in
            // this function too - window-created, window-unmanaged,
            // switch-workspace, and notify::focus-window never got wired up
            // either, leaving intellihide running on the 100ms poll alone
            // with none of its instant-response triggers. Isolated here,
            // matching the pattern already used for showing-desktop-changed
            // further down, so a missing signal only drops this one listener.
            try {
                let stateChangedId = global.display.connect('window-state-changed', function(display, win, changed, newState) {
                    if (changed & Meta.WindowState.FULLSCREEN || 
                        changed & Meta.WindowState.MAXIMIZED ||
                        changed & Meta.WindowState.MINIMIZED) {
                        Mainloop.idle_add(function() {
                            handler();
                            return false;
                        });
                    }
                    if ((changed & Meta.WindowState.MAXIMIZED) &&
                        win && win.maximized_horizontally && win.maximized_vertically) {
                        try { if (_launchpad()._isOpen) _launchpad().close(); } catch(e) {}
                    }
                });
                self._fullscreenSignalIds.push([global.display, stateChangedId]);
            } catch(e) {
                global.logError("dock@brahim: could not bind window-state-changed (non-fatal, falling back to poll): " + e);
            }
            
            // Monitor window creation
            try {
                let winCreatedId = global.display.connect('window-created', function() {
                    Mainloop.idle_add(function() {
                        handler();
                        return false;
                    });
                    try { if (_launchpad()._isOpen) _launchpad().close(); } catch(e) {}
                });
                self._fullscreenSignalIds.push([global.display, winCreatedId]);
            } catch(e) {
                global.logError("dock@brahim: could not bind window-created (non-fatal, falling back to poll): " + e);
            }
            
            // Monitor window unmanaged (closed)
            try {
                let winUnmanagedId = global.display.connect('window-unmanaged', function() {
                    Mainloop.idle_add(function() {
                        handler();
                        return false;
                    });
                });
                self._fullscreenSignalIds.push([global.display, winUnmanagedId]);
            } catch(e) {
                global.logError("dock@brahim: could not bind window-unmanaged (non-fatal, falling back to poll): " + e);
            }
            
            // Monitor workspace switch
            try {
                let workspaceSwitchId = global.window_manager.connect('switch-workspace', function() {
                    Mainloop.idle_add(function() {
                        handler();
                        return false;
                    });
                });
                self._fullscreenSignalIds.push([global.window_manager, workspaceSwitchId]);
            } catch(e) {
                global.logError("dock@brahim: could not bind switch-workspace (non-fatal, falling back to poll): " + e);
            }
            
            // Also monitor minimize state changes specifically (for hotcorners)
            let minimizeHandler = function() {
                Mainloop.idle_add(function() {
                    handler();
                    return false;
                });
            };
            
            // Listen for window focus changes (hotcorners minimize can change focus)
            try {
                let focusChangedId = global.display.connect('notify::focus-window', function() {
                    Mainloop.idle_add(function() {
                        // Check if any minimized window was just focused/unfocused
                        handler();
                        return false;
                    });
                });
                self._fullscreenSignalIds.push([global.display, focusChangedId]);
            } catch(e) {
                global.logError("dock@brahim: could not bind notify::focus-window (non-fatal, falling back to poll): " + e);
            }

            // Cinnamon's "Show Desktop" hotcorner/edge calls
            // global.workspace_manager.toggle_desktop() (confirmed in
            // Cinnamon's js/ui/hotCorner.js). This listener is now just an
            // optimization for instant response instead of waiting up to
            // 100ms for the next poll tick - the actual maximized/visible
            // detection in _checkForMaximizedOrFullscreen() no longer
            // depends on this firing correctly at all (it asks Meta's own
            // window.showing_on_its_workspace() directly, which is always
            // authoritative regardless of whether this signal exists on
            // this particular Cinnamon build). Wrapped in its own
            // try/catch, isolated from the rest of this function, so that
            // if some build genuinely lacks this API it doesn't take down
            // the other listeners registered above it.
            try {
                let wsManager = global.workspace_manager || global.screen;
                let showingDesktopId = wsManager.connect('showing-desktop-changed', function() {
                    Mainloop.idle_add(function() {
                        handler();
                        return false;
                    });
                });
                self._fullscreenSignalIds.push([wsManager, showingDesktopId]);
            } catch(e) {
                global.logError("dock@brahim: could not bind showing-desktop-changed (non-fatal, falling back to poll): " + e);
            }

            // Initial check
            Mainloop.idle_add(function() {
                handler();
                return false;
            });
            
        } catch(e) {
            global.logError("dock@brahim: failed to monitor window states: " + e);
        }
    },

    _updateAutoHide: function() {
        let s = SettingsStore.getDockSettings();
        let autoHideOn = !!s.autoHide;
        let intellihideOn = !!s.intellihide;
        StandaloneDock._autoHideEnabled = autoHideOn;
        StandaloneDock._intellihideEnabled = intellihideOn;
        
        if (autoHideOn && intellihideOn) {
            let settings = SettingsStore.getDockSettings();
            settings.intellihide = false;
            SettingsStore.saveDockSettings(settings);
            StandaloneDock._intellihideEnabled = false;
        }
        
        if (autoHideOn || intellihideOn) {
            StandaloneDock._startAutoHidePoll();
        } else {
            StandaloneDock._stopAutoHidePoll();
            StandaloneDock._cancelHideTimeout();
            StandaloneDock._revealDock();
        }
    },

    _startAutoHidePoll: function() {
        if (StandaloneDock._autoHidePoller) return;
        StandaloneDock._autoHidePoller = Mainloop.timeout_add(100, function() {
            if (!StandaloneDock.widget) {
                StandaloneDock._autoHidePoller = null;
                return false;
            }
            if (!StandaloneDock._autoHideEnabled && !StandaloneDock._intellihideEnabled) {
                StandaloneDock._autoHidePoller = null;
                return false;
            }
            try { StandaloneDock._checkAutoHidePointer(); } catch(e) {}
            return true;
        });
    },

    _stopAutoHidePoll: function() {
        if (StandaloneDock._autoHidePoller) {
            Mainloop.source_remove(StandaloneDock._autoHidePoller);
            StandaloneDock._autoHidePoller = null;
        }
    },

    _cancelHideTimeout: function() {
        if (StandaloneDock._hideTimeoutId) {
            Mainloop.source_remove(StandaloneDock._hideTimeoutId);
            StandaloneDock._hideTimeoutId = null;
        }
    },

    _cancelRevealTimeout: function() {
        if (StandaloneDock._revealTimeoutId) {
            Mainloop.source_remove(StandaloneDock._revealTimeoutId);
            StandaloneDock._revealTimeoutId = null;
        }
    },

    _checkAutoHidePointer: function() {
        if (!StandaloneDock.widget) return;

        let monitor = Main.layoutManager.primaryMonitor;
        if (!monitor) return;

        let launchpadOpen = !!(typeof _launchpad() !== "undefined" && _launchpad()._isOpen);
        
        let hasMaximizedOrFullscreen = StandaloneDock._checkForMaximizedOrFullscreen();
        
        let fullscreenHide = StandaloneDock._intellihideEnabled && !launchpadOpen && hasMaximizedOrFullscreen;
        let launchpadHide = StandaloneDock._intellihideEnabled && launchpadOpen;
        let hideGoverning = StandaloneDock._autoHideEnabled || fullscreenHide || launchpadHide;

        if (!hideGoverning) {
            StandaloneDock._cancelHideTimeout();
            StandaloneDock._cancelRevealTimeout();
            if (StandaloneDock._isHidden) {
                StandaloneDock._revealDock();
            }
            return;
        }

        let revealZoneHeight = Math.max(40, Math.round(StandaloneDock._maxHeight * 0.6));
        let [x, y] = global.get_pointer();
        let nearBottomEdge = (y >= monitor.y + monitor.height - revealZoneHeight);

        let overDock = false;
        try {
            let [wx, wy] = StandaloneDock.widget.get_transformed_position();
            let w = StandaloneDock.widget.width, h = StandaloneDock.widget.height;
            overDock = (x >= wx && x <= wx + w && y >= wy - 4 && y <= wy + h + 4);
        } catch(e) {}

        let keepUp = !!StandaloneDock._menu || !!StandaloneDock._previewPopup;

        if (nearBottomEdge || overDock || keepUp) {
            StandaloneDock._cancelHideTimeout();

            if (!StandaloneDock._isHidden) {
                // Already visible, nothing to do.
                StandaloneDock._cancelRevealTimeout();
            } else if (overDock || keepUp) {
                // Pointer is genuinely on the dock/menu, or a menu/preview
                // needs it kept up - reveal immediately, no debounce needed.
                StandaloneDock._cancelRevealTimeout();
                StandaloneDock._revealDock();
                StandaloneDock._ensureInteractive();
            } else if (!StandaloneDock._revealTimeoutId) {
                // nearBottomEdge only: require the pointer to sit in the
                // trigger zone for a short delay before revealing. Without
                // this, the dock pops up any time the mouse happens to
                // rest near the bottom of the screen - e.g. after clicking
                // into a chat box positioned near the bottom edge - which
                // is what was interfering with typing.
                let revealDelay = SettingsStore.getDockSettings().revealDelay;
                if (revealDelay === undefined || revealDelay === null) revealDelay = 220;
                StandaloneDock._revealTimeoutId = Mainloop.timeout_add(revealDelay, function() {
                    StandaloneDock._revealTimeoutId = null;
                    // Re-verify the pointer is still in the trigger zone
                    // before actually revealing (it may have moved away
                    // during the delay).
                    let m = Main.layoutManager.primaryMonitor;
                    if (!m) return false;
                    let [px, py] = global.get_pointer();
                    let zoneH = Math.max(40, Math.round(StandaloneDock._maxHeight * 0.6));
                    if (py >= m.y + m.height - zoneH) {
                        StandaloneDock._revealDock();
                        StandaloneDock._ensureInteractive();
                    }
                    return false;
                });
            }
        } else if (!StandaloneDock._isHidden && !StandaloneDock._hideTimeoutId) {
            StandaloneDock._cancelRevealTimeout();
            let delay = SettingsStore.getDockSettings().hideDelay;
            if (delay === undefined || delay === null) delay = 400;
            StandaloneDock._hideTimeoutId = Mainloop.timeout_add(delay, function() {
                StandaloneDock._hideTimeoutId = null;
                StandaloneDock._concealDock();
                return false;
            });
        }
    },

    // ---- Scroll-anywhere-on-dock to cycle windows ----
    // Opens Cinnamon's own bundled coverflow Alt-Tab switcher (see
    // DockCoverflowSwitcher near the top of this file) directly, so
    // the dock always shows the real coverflow animation rather than
    // whatever Alt-Tab style the user happens to have configured.
    // Listens on the stage rather than making the dock widget itself
    // reactive, so this can't interfere with the panel-mode hotcorner
    // click-passthrough that _ensureInteractive() carefully preserves.
    _connectScrollSwitcher: function() {
        if (StandaloneDock._scrollSignalId) return;
        StandaloneDock._scrollSignalId = global.stage.connect("scroll-event", function(actor, event) {
            return StandaloneDock._onDockScroll(event);
        });
    },

    _disconnectScrollSwitcher: function() {
        if (StandaloneDock._scrollSignalId) {
            try { global.stage.disconnect(StandaloneDock._scrollSignalId); } catch(e) {}
            StandaloneDock._scrollSignalId = null;
        }
    },

    _scrollSwitcher: null,

    _onDockScroll: function(event) {
        if (!StandaloneDock.widget) return Clutter.EVENT_PROPAGATE;

        let s = SettingsStore.getDockSettings();
        if (!s.scrollSwitchesWindows) return Clutter.EVENT_PROPAGATE;

        let direction = event.get_scroll_direction();
        if (direction !== Clutter.ScrollDirection.UP && direction !== Clutter.ScrollDirection.DOWN) {
            // Ignore smooth/left/right scroll - only a plain up/down
            // notch should cycle windows.
            return Clutter.EVENT_PROPAGATE;
        }

        let [x, y] = event.get_coords();
        let onDock = false;
        try {
            let [wx, wy] = StandaloneDock.widget.get_transformed_position();
            let w = StandaloneDock.widget.width, h = StandaloneDock.widget.height;
            onDock = (x >= wx && x <= wx + w && y >= wy && y <= wy + h);
        } catch(e) {}
        if (!onDock) return Clutter.EVENT_PROPAGATE;

        // Coverflow is about to take over the whole screen - a dock hover
        // preview or tooltip left showing underneath/behind it looks broken
        // and can also linger on top of it depending on stacking, so tear
        // both down before opening the switcher.
        StandaloneDock._cancelThumbPreview();
        StandaloneDock._cancelTooltip();

        StandaloneDock._triggerAltTab(direction === Clutter.ScrollDirection.DOWN);
        return Clutter.EVENT_STOP;
    },

    // True while the bundled coverflow Alt-Tab switcher is open. Used to
    // stop the dock's own hover preview/tooltip from scheduling or showing
    // themselves on top of/behind coverflow.
    _isAltTabActive: function() {
        return !!StandaloneDock._scrollSwitcher;
    },

    // forward: true for scroll-down/next, false for scroll-up/previous.
    // Opens the bundled coverflow switcher (see DockCoverflowSwitcher
    // above) so scrolling the dock always shows Cinnamon's real
    // coverflow Alt-Tab animation. Once the switcher is open, it
    // consumes further scroll events itself (that's the same
    // scroll-to-cycle behavior Cinnamon's own switcher already has) -
    // this is only responsible for the first tick that opens it.
    _triggerAltTab: function(forward) {
        if (StandaloneDock._scrollSwitcher) return;

        if (DockCoverflowSwitcher) {
            try {
                if (AppSwitcherBase.getWindowsForBinding({ get_name: function() { return "switch-windows"; } }).length === 0) {
                    return;
                }
                StandaloneDock._scrollSwitcher = new DockCoverflowSwitcher(!forward);
                return;
            } catch(e) {
                global.logError("dock@brahim: failed to open coverflow scroll switcher: " + e);
                StandaloneDock._scrollSwitcher = null;
            }
        }

        // Fallback for the rare case the bundled coverflowSwitcher.js
        // failed to load: ask Cinnamon to open whatever Alt-Tab style
        // the user has configured, so scrolling the dock still does
        // something instead of nothing.
        try {
            Main.wm._startAppSwitcher(global.display, global.screen, {
                get_name: function() { return "switch-windows"; },
                get_mask: function() { return 0; }
            });
            return;
        } catch(e) {}

        try {
            Util.spawnCommandLine(!forward
                ? "xdotool keydown alt key shift+Tab keyup alt"
                : "xdotool keydown alt key Tab keyup alt");
        } catch(e2) {}
    },

    _revealDock: function() {
        if (!StandaloneDock.widget) return;
        StandaloneDock._isHidden = false;
        Tweener.removeTweens(StandaloneDock.widget);
        StandaloneDock.widget.opacity = 255;
        StandaloneDock.widget.translation_y = 0;
        StandaloneDock.widget.reactive = true;
        // Whatever raised itself above the dock's z-order while it was
        // concealed (another chrome actor, a re-shown panel, etc.) would
        // otherwise keep intercepting clicks even after the dock animates
        // back into view - this is the most likely explanation for "looks
        // revealed but doesn't respond to clicks until I interact with
        // something else", since interacting elsewhere is exactly what
        // would incidentally restack things. Re-raise on every reveal so
        // the dock can't get left underneath something else.
        StandaloneDock.widget.raise_top();
        StandaloneDock._ensureInteractive();
        Tweener.addTween(StandaloneDock.widget, {
            translation_y: 0, opacity: 255, time: 0.18, transition: "easeOutQuad",
            onComplete: function() {
                try {
                    StandaloneDock.widget.raise_top();
                    StandaloneDock._ensureInteractive();
                } catch(e) {}
            }
        });
    },

    _concealDock: function() {
        if (!StandaloneDock.widget) return;
        StandaloneDock._isHidden = true;
        let h = StandaloneDock.widget.height || StandaloneDock._maxHeight;
        Tweener.removeTweens(StandaloneDock.widget);
        StandaloneDock.widget.reactive = false;
        Tweener.addTween(StandaloneDock.widget, { translation_y: h + 12, opacity: 0, time: 0.22, transition: "easeInQuad" });
    },

    // Coalesces every refresh trigger below into a single deferred rebuild.
    // Several of these signals can fire in the same tick (e.g. launching an
    // app emits both window-created and app-state-changed back to back) -
    // previously each one queued its own separate idle_add(refresh), so one
    // click could tear down and rebuild every dock tile two or three times
    // in a row. This collapses any such burst into one rebuild.
    _refreshQueued: false,
    _queueRefresh: function() {
        if (StandaloneDock._refreshQueued) return;
        StandaloneDock._refreshQueued = true;
        Mainloop.idle_add(function() {
            StandaloneDock._refreshQueued = false;
            StandaloneDock.refresh();
            return false;
        });
    },

    _connectSignals: function() {
        let s = StandaloneDock._signals;
        // Deferred (via _queueRefresh, which itself uses idle_add) because
        // app-state-changed and switch-workspace can also fire
        // synchronously as a side effect of _activate()'s
        // Main.activateWindow()/minimize() calls, and were still able to
        // reenter refresh() (destroying tiles) mid-click before this.
        s.push([StandaloneDock._appSystem, StandaloneDock._appSystem.connect("app-state-changed", function() {
            StandaloneDock._queueRefresh();
        })]);
        s.push([global.window_manager, global.window_manager.connect("switch-workspace", function() {
            StandaloneDock._queueRefresh();
        })]);
        s.push([global.display, global.display.connect("window-created", function() {
            StandaloneDock._queueRefresh();
        })]);
        // Closing a single window (as opposed to quitting the whole app)
        // never fired app-state-changed or window-created, so the
        // window-count badge on the dock icon kept showing the old count
        // until something else happened to trigger a refresh. Cinnamon's
        // window manager emits 'destroy' for every window close (it's what
        // drives the close animation), so hook that too.
        s.push([global.window_manager, global.window_manager.connect("destroy", function() {
            StandaloneDock._queueRefresh();
        })]);
        // NOTE: there used to be a notify::focus-window listener here that
        // also triggered a full refresh(). Nothing in _createTile() reflects
        // which window currently has focus (the running-dot is based purely
        // on app.get_n_windows() > 0, and tile order/content never changes
        // with focus) - so that listener was scheduling a full
        // destroy_all_children() + rebuild-every-tile pass on every single
        // window switch for zero visual benefit. That's the direct cause of
        // "uneasy switching": clicking a dock launcher to jump between
        // maximized windows was tearing down and rebuilding the whole dock
        // (icons, hover wiring, tooltips, button handlers) on every click,
        // fighting the 100ms intellihide poll for the same actors in the
        // process. Removed entirely - focus changes need no dock rebuild.
        // Closes Launchpad on any click landing anywhere in the dock -
        // captured-event fires before the individual tile handlers below
        // (which mostly return EVENT_STOP), and doesn't stop propagation
        // itself, so this is purely additive and doesn't change any
        // existing click behavior. The launchpad tile itself is excluded
        // so its own open/close toggle (_launchpadTile's button-press
        // handler, further down) keeps working normally.
        s.push([StandaloneDock.widget, StandaloneDock.widget.connect("captured-event", function(actor, event) {
            if (event.type() !== Clutter.EventType.BUTTON_PRESS) return Clutter.EVENT_PROPAGATE;
            try {
                let LP = _launchpad();
                if (!LP._isOpen) return Clutter.EVENT_PROPAGATE;
                let launchpadTile = StandaloneDock._launchpadTile;
                let a = event.get_source();
                while (a) {
                    if (a === launchpadTile) return Clutter.EVENT_PROPAGATE;
                    a = a.get_parent();
                }
                LP.close();
            } catch(e) {}
            return Clutter.EVENT_PROPAGATE;
        })]);
        s.push([Main.layoutManager, Main.layoutManager.connect("monitors-changed", function() { StandaloneDock._reposition(); })]);
        s.push([StandaloneDock.widget, StandaloneDock.widget.connect("notify::width", function() { StandaloneDock._reposition(); })]);
        s.push([StandaloneDock.widget, StandaloneDock.widget.connect("notify::height", function() { StandaloneDock._reposition(); })]);
    },

    _disconnectSignals: function() {
        StandaloneDock._signals.forEach(function(pair) {
            try { pair[0].disconnect(pair[1]); } catch(e) {}
        });
        StandaloneDock._signals = [];
    },

    _reposition: function() {
        if (!StandaloneDock.widget) return;
        let monitor = Main.layoutManager.primaryMonitor;
        if (!monitor) return;

        try {
            let [minW, natW] = StandaloneDock.widget.get_preferred_width(-1);
            let width = natW || minW || 0;
            let [minH, natH] = StandaloneDock.widget.get_preferred_height(-1);
            let height = natH || minH || 0;

            let s = SettingsStore.getDockSettings();
            let panelMode = s.panelMode || false;
            
            let x;
            if (panelMode) {
                x = monitor.x;
                width = monitor.width;
                StandaloneDock.widget.set_width(width);
            } else {
                let minWidth = (s.minWidth !== undefined ? s.minWidth : DEFAULT_DOCK_SETTINGS.minWidth) || 0;
                if (minWidth > 0 && width < minWidth) {
                    width = minWidth;
                    StandaloneDock.widget.set_width(width);
                } else {
                    StandaloneDock.widget.set_width(-1);
                }
                x = monitor.x + Math.floor((monitor.width - width) / 2);
            }
            // Panel mode must sit flush against the actual bottom edge of
            // the monitor (no gap) - Cinnamon's layoutManager only
            // recognizes an actor as a strut-worthy panel if its edge
            // actually touches the monitor boundary (y2 >= monitor bottom;
            // see updateRegions() in js/ui/layout.js). The floating-dock
            // look keeps its small gap so it reads as detached from the
            // edge.
            let y = panelMode
                ? (monitor.y + monitor.height - height)
                : (monitor.y + monitor.height - height - 8);

            // Safety clamp: whatever width/height St just reported (which
            // can momentarily be stale/off right after a rebuild, before a
            // pending style/layout recompute has actually settled), never
            // let the dock actually land partly off the bottom or right
            // edge of the monitor because of it.
            x = Math.min(x, monitor.x + monitor.width - width);
            x = Math.max(x, monitor.x);
            y = Math.min(y, monitor.y + monitor.height - height);
            y = Math.max(y, monitor.y);

            StandaloneDock.widget.set_position(Math.round(x), Math.round(y));

            // After repositioning, reapply keyboard styling
            StandaloneDock._applyKeyboardStyling();
        } catch(e) {}
    },

    _getFavoriteIds: function() {
        return (_launchpad().settings && _launchpad().settings.favoriteApps) || [];
    },

    // Curated buckets of XDG desktop-entry Categories
    // (https://specifications.freedesktop.org/menu-spec/latest/apa.html).
    // Checked in order - an app matches the first bucket whose "match"
    // list intersects its own Categories. Keeps e.g. a music player and a
    // media converter (both AudioVideo/Audio) or Firefox and Chrome (both
    // WebBrowser) clustered together regardless of pin/launch order.
    _APP_CATEGORY_GROUPS: [
        { key: 'browser',       match: ['WebBrowser'] },
        { key: 'media',         match: ['AudioVideo', 'Audio', 'Video', 'Player', 'Recorder', 'Mixer', 'TV', 'Midi'] },
        { key: 'graphics',      match: ['Graphics', 'Photography', '2DGraphics', '3DGraphics', 'RasterGraphics', 'VectorGraphics', 'Scanning', 'Viewer'] },
        { key: 'office',        match: ['Office', 'WordProcessor', 'Spreadsheet', 'Presentation', 'Publishing'] },
        { key: 'development',   match: ['Development', 'IDE', 'TextEditor', 'GUIDesigner', 'Debugger'] },
        { key: 'communication', match: ['Network', 'InstantMessaging', 'Email', 'Chat', 'VideoConference', 'P2P'] },
        { key: 'filemanager',   match: ['FileManager', 'FileTools', 'Archiving', 'Compression'] },
        { key: 'game',          match: ['Game'] },
        { key: 'system',        match: ['System', 'Settings', 'Monitor', 'Security'] },
        { key: 'utility',       match: ['Utility', 'Accessibility', 'Calculator'] }
    ],

    // Resolves and caches which bucket an app's .desktop Categories fall
    // into. Falls back to the app's own most-specific raw category (so
    // apps outside the curated buckets still cluster with same-category
    // siblings) and finally to 'other' if it has no categories at all.
    _getAppCategoryKey: function(app) {
        let id = null;
        try { id = app.get_id(); } catch(e) {}
        if (!id) return 'other';

        if (!StandaloneDock._categoryKeyCache) StandaloneDock._categoryKeyCache = {};
        if (StandaloneDock._categoryKeyCache.hasOwnProperty(id)) {
            return StandaloneDock._categoryKeyCache[id];
        }

        let key = 'other';
        try {
            let info = Gio.DesktopAppInfo.new(id);
            let raw = info ? info.get_categories() : null;
            if (raw) {
                let cats = raw.split(';').filter(function(c) { return c.length > 0; });
                key = StandaloneDock._mapCategoriesToGroupKey(cats);
            }
        } catch(e) {}

        StandaloneDock._categoryKeyCache[id] = key;
        return key;
    },

    _mapCategoriesToGroupKey: function(cats) {
        let groups = StandaloneDock._APP_CATEGORY_GROUPS;
        for (let i = 0; i < groups.length; i++) {
            for (let j = 0; j < cats.length; j++) {
                if (groups[i].match.indexOf(cats[j]) !== -1) return groups[i].key;
            }
        }
        return cats.length ? ('xdg:' + cats[cats.length - 1]) : 'other';
    },

    // Stable-clusters apps sharing a category key together, at the
    // position where that key first appears - so favorites order and
    // running-app order are both preserved *within* a cluster, only the
    // clustering itself changes the layout.
    _groupAppsByCategory: function(list) {
        let groups = [];
        let indexByKey = {};
        list.forEach(function(app) {
            let key = StandaloneDock._getAppCategoryKey(app);
            if (!indexByKey.hasOwnProperty(key)) {
                indexByKey[key] = groups.length;
                groups.push([]);
            }
            groups[indexByKey[key]].push(app);
        });
        let result = [];
        groups.forEach(function(g) { result = result.concat(g); });
        return result;
    },

    _getOrderedApps: function() {
        let favIds = StandaloneDock._getFavoriteIds();
        let running = [];
        try { running = StandaloneDock._appSystem.get_running() || []; } catch(e) {}

        let runningById = {};
        running.forEach(function(a) { runningById[a.get_id()] = a; });

        let list = [], seen = {};
        favIds.forEach(function(id) {
            let app = runningById[id];
            if (!app) {
                try { app = StandaloneDock._appSystem.lookup_app(id); } catch(e) { app = null; }
            }
            if (app && !seen[id]) { list.push(app); seen[id] = true; }
        });
        running.forEach(function(a) {
            let id = a.get_id();
            if (!seen[id]) { list.push(a); seen[id] = true; }
        });

        let s = SettingsStore.getDockSettings();
        if (s.groupByCategory !== false) {
            list = StandaloneDock._groupAppsByCategory(list);
        }

        return list;
    },

    refresh: function() {
        if (!StandaloneDock.box) return;

        StandaloneDock._cancelThumbPreview();

        // Always start a refresh from the user's configured icon size;
        // _fitIconSizeToMaxWidth() below will shrink _renderIconSize (and
        // trigger a rebuild at the smaller size) if the dock's natural
        // width would otherwise exceed the configured maximum dock width -
        // this is what stops the dock spreading edge-to-edge / off-screen
        // once enough app tiles (or the media controls docklet) are added.
        StandaloneDock._renderIconSize = StandaloneDock._iconSize;

        let pass = 0;
        do {
            StandaloneDock._populateTiles();
            pass++;
        } while (StandaloneDock._fitIconSizeToMaxWidth() && pass < 3);

        StandaloneDock._ensureInteractive();
        StandaloneDock._reposition();
    },

    // Measures the dock's current natural width against the configured
    // maximum (as a % of monitor width) and adjusts _renderIconSize to
    // compensate. Returns true if it changed _renderIconSize (meaning the
    // caller should rebuild tiles and re-measure), false once things have
    // converged.
    //
    // Panel mode used to be exempt entirely (it's meant to span the full
    // monitor width edge-to-edge on purpose), but that only accounted
    // for the two expanding spacers absorbing slack - it didn't account
    // for what happens once the launcher + centered app icons + trailing
    // docklet icons' *combined* natural width exceeds the monitor width:
    // the spacers bottom out at 0px and the trailing icons (radio/media/
    // trash) get pushed straight past the right edge of the screen
    // instead of shrinking. So in panel mode we still fit, just against
    // the full monitor width instead of the configured max-width-percent.
    _fitIconSizeToMaxWidth: function() {
        if (!StandaloneDock.box) return false;

        let s = SettingsStore.getDockSettings();

        let monitor = Main.layoutManager.primaryMonitor;
        if (!monitor) return false;

        let maxAllowed;
        if (s.panelMode) {
            maxAllowed = monitor.width - (PANEL_MODE_SIDE_MARGIN * 2);
        } else {
            let maxPercent = (s.maxWidthPercent !== undefined ? s.maxWidthPercent : DEFAULT_DOCK_SETTINGS.maxWidthPercent) / 100;
            maxAllowed = Math.max(200, Math.floor(monitor.width * maxPercent));
        }

        // Measure by summing each child tile's own preferred width rather
        // than asking the box (StandaloneDock.box === StandaloneDock.widget)
        // for its own get_preferred_width(). _reposition() calls
        // set_width() on that exact same actor every time it runs
        // (monitor.width in panel mode; the configured minWidth in
        // floating mode when needed), and asking it for its preferred
        // width again right afterwards was not reliably reflecting a
        // freshly-recomputed natural size - it kept echoing back
        // whatever was last forced, even after an explicit set_width(-1).
        // That's what let panel-mode overflow keep spilling past the
        // right edge, and what left the icons stuck too small for one
        // whole refresh right after switching panel mode back off (fixed
        // itself as soon as anything else nudged another refresh). Every
        // child tile here was just created fresh this same populate pass
        // and has no sizing history of its own, so summing those avoids
        // the stale container-level measurement entirely.
        let children = StandaloneDock.box.get_children();
        let width = 0;
        for (let i = 0; i < children.length; i++) {
            let [cMin, cNat] = children[i].get_preferred_width(-1);
            width += (cNat || cMin || 0);
            // .brahim-dock-separator carries CSS margin (6px 6px 6px 2px -
            // 8px combined horizontal) that the separator actor's own
            // get_preferred_width() doesn't fold in - St applies margin
            // as extra space around the child rather than as part of its
            // own preferred size - so it has to be added back in here by
            // hand or every separator quietly shorts the total by 8px.
            try {
                if (children[i].get_style_class_name && (children[i].get_style_class_name() || "").indexOf("brahim-dock-separator") !== -1) {
                    width += 8;
                }
            } catch(e) {}
        }
        // Inter-child spacing (.brahim-standalone-dock's "spacing: 12px")
        // plus this actor's own horizontal padding (set inline in
        // _buildStyle - 16px each side in floating mode, 0 in panel mode)
        // aren't reflected by the children alone.
        if (children.length > 1) width += 12 * (children.length - 1);
        width += s.panelMode ? 0 : 32;

        if (width <= maxAllowed) {
            // There's room to spare - grow back toward the configured icon
            // size if a previous pass (or a previous refresh(), before an
            // app was closed) had shrunk it.
            if (StandaloneDock._renderIconSize < StandaloneDock._iconSize) {
                StandaloneDock._renderIconSize = StandaloneDock._iconSize;
                return true;
            }
            return false;
        }

        let scale = maxAllowed / width;
        let candidate = SettingsStore.clampIconSize(Math.floor(StandaloneDock._renderIconSize * scale));
        candidate = Math.min(candidate, StandaloneDock._iconSize);

        if (candidate >= StandaloneDock._renderIconSize) {
            // Already at (or below) the floor - can't shrink further,
            // stop iterating so we don't loop forever.
            return false;
        }

        StandaloneDock._renderIconSize = candidate;
        return true;
    },

    _populateTiles: function() {
        if (StandaloneDock._launchpadTile) {
            let idx = _launchpad()._dockIcons.indexOf(StandaloneDock._launchpadTile);
            if (idx !== -1) _launchpad()._dockIcons.splice(idx, 1);
            StandaloneDock._launchpadTile = null;
        }

        // The media-controls docklet is a persistent widget (it owns live
        // MPRIS DBus signal connections) rather than something cheap to
        // rebuild on every pass - detach it from the box first so
        // destroy_all_children() below doesn't destroy it along with the
        // disposable app/trash/launcher tiles. getTile() re-adds it (and
        // rebuilds its buttons at the new size, if _renderIconSize changed)
        // further down.
        if (_media().widget && _media().widget.get_parent() === StandaloneDock.box) {
            StandaloneDock.box.remove_child(_media().widget);
        }

        StandaloneDock.box.destroy_all_children();
        StandaloneDock._appTileEntries = [];

        let s = SettingsStore.getDockSettings();
        let panelMode = s.panelMode || false;
        let showTrash = s.showTrash !== false;
        let trashSeparator = s.trashSeparator !== false;

        let dockletsSettings = SettingsStore.getDockletsSettings();
        let showMediaControls = (dockletsSettings.mediaControlsEnabled !== false) && _media().hasPlayer();
        let showRadio = dockletsSettings.radioEnabled !== false;
        let showBlankScreen = dockletsSettings.blankScreenEnabled === true;
        let showKillWindow = dockletsSettings.killWindowEnabled === true;
        let showKeyboard = dockletsSettings.keyboardEnabled !== false;
        let showWeather = dockletsSettings.weatherEnabled !== false;

        if (panelMode) {
            let showLauncher = !_launchpad().settings || _launchpad().settings.showDockIcon !== false;
            if (showLauncher) {
                try {
                    let launcherTile = StandaloneDock._createLaunchpadTile();
                    StandaloneDock.box.add(launcherTile, { x_fill: false, y_fill: true });
                    StandaloneDock._launchpadTile = launcherTile;
                    _launchpad()._dockIcons.push(launcherTile);
                } catch(e) {
                    global.logError("dock@brahim: failed to build launcher tile: " + e);
                }
            }

            let spacer1 = new St.Bin({ style: 'width: 100px;', x_expand: true });
            StandaloneDock.box.add(spacer1, { x_fill: true, y_fill: false, expand: true });

            let centerBox = new St.BoxLayout({ vertical: false, style: 'spacing: 4px;' });
            let apps = [];
            try { apps = StandaloneDock._getOrderedApps(); } catch(e) {
                global.logError("dock@brahim: failed to get ordered apps: " + e);
            }
            apps.forEach(function(app) {
                try {
                    let appTile = StandaloneDock._createTile(app);
                    centerBox.add(appTile, { x_fill: false, y_fill: true });
                    StandaloneDock._appTileEntries.push({ app: app, tile: appTile });
                } catch(e) {}
            });
            StandaloneDock.box.add(centerBox, { x_fill: false, y_fill: true });

            let spacer2 = new St.Bin({ style: 'width: 100px;', x_expand: true });
            StandaloneDock.box.add(spacer2, { x_fill: true, y_fill: false, expand: true });

            if (showTrash || showMediaControls || showRadio || showBlankScreen || showKillWindow || showKeyboard || showWeather) {
                if (trashSeparator) {
                    StandaloneDock.box.add(new St.Bin({
                        style_class: "brahim-dock-separator"
                    }), { x_fill: false, y_fill: true });
                }

                if (showMediaControls) {
                    try {
                        let mediaTile = _media().getTile();
                        StandaloneDock.box.add(mediaTile, { x_fill: false, y_fill: true });
                    } catch(e) {
                        global.logError("dock@brahim: failed to build media controls docklet: " + e);
                    }
                }

                if (showRadio) {
                    try {
                        let radioTile = _radio().getTile();
                        StandaloneDock.box.add(radioTile, { x_fill: false, y_fill: true });
                    } catch(e) {
                        global.logError("dock@brahim: failed to build radio docklet: " + e);
                    }
                }

                if (showWeather) {
                    try {
                        let weatherTile = _weather().getTile();
                        StandaloneDock.box.add(weatherTile, { x_fill: false, y_fill: true });
                    } catch(e) {
                        global.logError("dock@brahim: failed to build weather docklet: " + e);
                    }
                }

                if (showBlankScreen) {
                    try {
                        let blankTile = StandaloneDock._createBlankScreenTile();
                        StandaloneDock.box.add(blankTile, { x_fill: false, y_fill: true });
                    } catch(e) {
                        global.logError("dock@brahim: failed to build blank screen tile: " + e);
                    }
                }

                if (showKillWindow) {
                    try {
                        let killTile = StandaloneDock._createKillWindowTile();
                        StandaloneDock.box.add(killTile, { x_fill: false, y_fill: true });
                    } catch(e) {
                        global.logError("dock@brahim: failed to build kill window tile: " + e);
                    }
                }

                if (showKeyboard) {
                    try {
                        let keyboardTile = StandaloneDock._createKeyboardTile();
                        StandaloneDock.box.add(keyboardTile, { x_fill: false, y_fill: true });
                    } catch(e) {
                        global.logError("dock@brahim: failed to build keyboard tile: " + e);
                    }
                }

                if (showTrash) {
                    try {
                        let trashTile = StandaloneDock._createTrashTile();
                        StandaloneDock.box.add(trashTile, { x_fill: false, y_fill: true });
                        StandaloneDock._trashTile = trashTile;
                    } catch(e) {
                        global.logError("dock@brahim: failed to build trash tile: " + e);
                    }
                }
            }
        } else {
            let showLauncher = !_launchpad().settings || _launchpad().settings.showDockIcon !== false;
            if (showLauncher) {
                try {
                    let launcherTile = StandaloneDock._createLaunchpadTile();
                    StandaloneDock.box.add(launcherTile, { x_fill: false, y_fill: true });
                    StandaloneDock._launchpadTile = launcherTile;
                    _launchpad()._dockIcons.push(launcherTile);

                    StandaloneDock.box.add(new St.Bin({
                        style_class: "brahim-dock-separator"
                    }), { x_fill: false, y_fill: true });
                } catch(e) {
                    global.logError("dock@brahim: failed to build launcher tile: " + e);
                }
            }

            let apps = [];
            try { apps = StandaloneDock._getOrderedApps(); } catch(e) {
                global.logError("dock@brahim: failed to get ordered apps: " + e);
            }
            apps.forEach(function(app) {
                try {
                    let appTile = StandaloneDock._createTile(app);
                    StandaloneDock.box.add(appTile, { x_fill: false, y_fill: true });
                    StandaloneDock._appTileEntries.push({ app: app, tile: appTile });
                } catch(e) {}
            });

            if (showTrash || showMediaControls || showRadio || showBlankScreen || showKillWindow || showKeyboard || showWeather) {
                if (trashSeparator) {
                    StandaloneDock.box.add(new St.Bin({
                        style_class: "brahim-dock-separator"
                    }), { x_fill: false, y_fill: true });
                }

                if (showMediaControls) {
                    try {
                        let mediaTile = _media().getTile();
                        StandaloneDock.box.add(mediaTile, { x_fill: false, y_fill: true });
                    } catch(e) {
                        global.logError("dock@brahim: failed to build media controls docklet: " + e);
                    }
                }

                if (showRadio) {
                    try {
                        let radioTile = _radio().getTile();
                        StandaloneDock.box.add(radioTile, { x_fill: false, y_fill: true });
                    } catch(e) {
                        global.logError("dock@brahim: failed to build radio docklet: " + e);
                    }
                }

                if (showWeather) {
                    try {
                        let weatherTile = _weather().getTile();
                        StandaloneDock.box.add(weatherTile, { x_fill: false, y_fill: true });
                    } catch(e) {
                        global.logError("dock@brahim: failed to build weather docklet: " + e);
                    }
                }

                if (showBlankScreen) {
                    try {
                        let blankTile = StandaloneDock._createBlankScreenTile();
                        StandaloneDock.box.add(blankTile, { x_fill: false, y_fill: true });
                    } catch(e) {
                        global.logError("dock@brahim: failed to build blank screen tile: " + e);
                    }
                }

                if (showKillWindow) {
                    try {
                        let killTile = StandaloneDock._createKillWindowTile();
                        StandaloneDock.box.add(killTile, { x_fill: false, y_fill: true });
                    } catch(e) {
                        global.logError("dock@brahim: failed to build kill window tile: " + e);
                    }
                }

                if (showKeyboard) {
                    try {
                        let keyboardTile = StandaloneDock._createKeyboardTile();
                        StandaloneDock.box.add(keyboardTile, { x_fill: false, y_fill: true });
                    } catch(e) {
                        global.logError("dock@brahim: failed to build keyboard tile: " + e);
                    }
                }

                if (showTrash) {
                    try {
                        let trashTile = StandaloneDock._createTrashTile();
                        StandaloneDock.box.add(trashTile, { x_fill: false, y_fill: true });
                        StandaloneDock._trashTile = trashTile;
                    } catch(e) {
                        global.logError("dock@brahim: failed to build trash tile: " + e);
                    }
                }
            }
        }
    },

    _createLaunchpadTile: function() {
        let iconSize = StandaloneDock._renderIconSize || StandaloneDock._iconSize;
        let tile = new St.BoxLayout({
            vertical: true,
            reactive: true,
            track_hover: true,
            style_class: "brahim-dock-tile"
        });

        let icon;
        let ls = _launchpad().settings || {};
        let bundledIconPath = Shared.EXTENSION_DIR + "/dock.png";
        try {
            if (ls.useCustomIcon && ls.panelIcon) {
                if (GLib.file_test(ls.panelIcon, GLib.FileTest.EXISTS)) {
                    icon = new St.Icon({ gicon: Gio.icon_new_for_string(ls.panelIcon), icon_size: iconSize });
                } else {
                    icon = new St.Icon({ icon_name: ls.panelIcon, icon_size: iconSize });
                }
            } else if (GLib.file_test(bundledIconPath, GLib.FileTest.EXISTS)) {
                icon = new St.Icon({ gicon: Gio.icon_new_for_string(bundledIconPath), icon_size: iconSize });
            } else {
                icon = new St.Icon({ icon_name: "view-grid-symbolic", icon_size: iconSize });
            }
        } catch(e) {
            icon = new St.Icon({ icon_name: "view-grid-symbolic", icon_size: iconSize });
        }

        let iconBin = new St.Bin({ x_align: St.Align.MIDDLE });
        iconBin.set_child(icon);
        // expand:true gives iconBin all the leftover vertical space in the
        // tile (everything not used by the dot below it); y_fill:false
        // means the icon is centered within that space rather than
        // stretched, so it reads as vertically centered in the dock while
        // the dot still gets pushed down to sit right above the tile's
        // bottom edge.
        tile.add(iconBin, { x_fill: false, x_align: St.Align.MIDDLE, y_fill: false, y_align: St.Align.MIDDLE, expand: true });

        tile.add(new St.Bin({ style_class: "brahim-dock-dot brahim-dock-dot-hidden" }), { x_fill: false, x_align: St.Align.MIDDLE, y_fill: false, y_align: St.Align.END });

        StandaloneDock._wireHoverEffects(tile, iconBin, null, Utils._("Launchpad"));

        tile.connect("button-press-event", function(actor, event) {
            let button = event.get_button();

            // Right-click is only ever meant to open the dock settings
            // context menu - it must not have any side effect on window
            // state. It used to unconditionally call
            // _exitShowDesktopIfNeeded() first (like the left-click path
            // below does), which calls Meta's unshow_desktop() - a no-op
            // most of the time, but if the desktop happened to be in
            // "Show Desktop" mode, that single right-click silently
            // restored/un-minimized every window before the settings
            // menu even opened, which looked like the icon was
            // "maximizing windows" on a simple right-click.
            if (button === 3) {
                StandaloneDock._hideContextMenu();
                StandaloneDock._cancelThumbPreview();
                StandaloneDock._openDockSettings();
                return Clutter.EVENT_STOP;
            }

            StandaloneDock._exitShowDesktopIfNeeded();
            let hadOverlay = !!StandaloneDock._menu || !!StandaloneDock._previewPopup;
            StandaloneDock._hideContextMenu();
            StandaloneDock._cancelThumbPreview();
            if (hadOverlay) return Clutter.EVENT_STOP;

            _launchpad().toggle();
            return Clutter.EVENT_STOP;
        });

        return tile;
    },

    _trashHasItems: function() {
        try {
            let dir = Gio.File.new_for_uri("trash:///");
            let enumerator = dir.enumerate_children("standard::name", Gio.FileQueryInfoFlags.NONE, null);
            let info = enumerator.next_file(null);
            enumerator.close(null);
            return !!info;
        } catch(e) {
            return false;
        }
    },

    _createTrashTile: function() {
        let iconSize = StandaloneDock._renderIconSize || StandaloneDock._iconSize;
        let tile = new St.BoxLayout({
            vertical: true,
            reactive: true,
            track_hover: true,
            style_class: "brahim-dock-tile"
        });

        // A real (full-color, themed) trash icon rather than the flat
        // monochrome "-symbolic" variant, so it matches the rest of the
        // dock's real app icons - this covers both floating and panel
        // mode, since both call this same tile builder. Prefers a
        // bundled trash.png (if the user dropped one into the extension
        // directory, same pattern as radio.js's bundled radio.png) over
        // the icon theme's "-full"/plain variants, and only falls back
        // to the flat "-symbolic" glyph as a last resort for icon themes
        // that ship neither a themed icon nor a bundled PNG.
        let icon;

        if (!StandaloneDock._trashBundledIconChecked) {
            let pngPath = Shared.EXTENSION_DIR + "/trash.png";
            StandaloneDock._trashUseBundledIcon = GLib.file_test(pngPath, GLib.FileTest.EXISTS);
            StandaloneDock._trashBundledIconChecked = true;
        }

        if (StandaloneDock._trashUseBundledIcon) {
            let pngPath = Shared.EXTENSION_DIR + "/trash.png";
            try {
                icon = new St.Icon({
                    gicon: Gio.icon_new_for_string(pngPath),
                    icon_size: iconSize
                });
            } catch(e) {
                StandaloneDock._trashUseBundledIcon = false;
            }
        }

        if (!icon) {
            let trashHasItems = StandaloneDock._trashHasItems();
            let candidates = trashHasItems
                ? ["user-trash-full", "user-trash", "user-trash-symbolic"]
                : ["user-trash", "user-trash-full", "user-trash-symbolic"];
            let chosenName = candidates[candidates.length - 1];
            // Which of these icon names actually exist in the current icon
            // theme never changes mid-session, so cache that lookup instead
            // of re-probing has_icon() on every rebuild (this tile gets
            // rebuilt on every dock refresh, including every pass of the
            // icon-size fit loop) - only which candidate order to prefer
            // (driven by the live trashHasItems check above) still needs to
            // be resolved fresh each time.
            if (!StandaloneDock._trashIconAvailability) {
                StandaloneDock._trashIconAvailability = {};
                try {
                    let iconTheme = Gtk.IconTheme.get_default();
                    ["user-trash-full", "user-trash", "user-trash-symbolic"].forEach(function(name) {
                        try { StandaloneDock._trashIconAvailability[name] = iconTheme.has_icon(name); } catch(e) { StandaloneDock._trashIconAvailability[name] = false; }
                    });
                } catch(e) {}
            }
            for (let i = 0; i < candidates.length; i++) {
                if (StandaloneDock._trashIconAvailability[candidates[i]]) {
                    chosenName = candidates[i];
                    break;
                }
            }
            let isSymbolicFallback = (chosenName === "user-trash-symbolic");
            try {
                icon = new St.Icon({
                    icon_name: chosenName,
                    icon_size: iconSize,
                    style: isSymbolicFallback ? "color: #ffffff;" : null
                });
            } catch(e) {
                icon = new St.Icon({ icon_name: "user-trash-symbolic", icon_size: iconSize, style: "color: #ffffff;" });
            }
        }
        let iconBin = new St.Bin({ x_align: St.Align.MIDDLE });
        iconBin.set_child(icon);
        tile.add(iconBin, { x_fill: false, x_align: St.Align.MIDDLE, y_fill: false, y_align: St.Align.MIDDLE, expand: true });

        tile.add(new St.Bin({ style_class: "brahim-dock-dot brahim-dock-dot-hidden" }), { x_fill: false, x_align: St.Align.MIDDLE, y_fill: false, y_align: St.Align.END });

        StandaloneDock._wireHoverEffects(tile, iconBin, null, Utils._("Trash"));

        tile.connect("button-press-event", function(actor, event) {
            StandaloneDock._exitShowDesktopIfNeeded();
            let hadOverlay = !!StandaloneDock._menu || !!StandaloneDock._previewPopup;
            StandaloneDock._hideContextMenu();
            StandaloneDock._cancelThumbPreview();
            if (hadOverlay) return Clutter.EVENT_STOP;

            let button = event.get_button();
            if (button === 3) {
                let [x, y] = event.get_coords();
                StandaloneDock._showTrashContextMenu(x, y);
                return Clutter.EVENT_STOP;
            }

            try {
                Util.spawnCommandLine("xdg-open trash:///");
            } catch(e) {
                try {
                    Util.spawnCommandLine("nemo trash:///");
                } catch(e2) {}
            }
            return Clutter.EVENT_STOP;
        });

        return tile;
    },

    _showTrashContextMenu: function(x, y) {
        StandaloneDock._hideContextMenu();
        StandaloneDock._cancelThumbPreview();

        let menu = new St.BoxLayout({
            vertical: true,
            style_class: "launchpad-context-menu launchpad-dark",
            reactive: true
        });
        let item = new St.Label({
            text: Utils._("Empty Trash"),
            style_class: "launchpad-context-item",
            reactive: true,
            track_hover: true
        });
        item.connect("button-release-event", function() {
            try { Util.spawnCommandLine("gio trash --empty"); } catch(e) {}
            StandaloneDock._hideContextMenu();
            return Clutter.EVENT_STOP;
        });
        menu.add(item, { x_fill: true });

        Main.uiGroup.add_actor(menu);
        try {
            let [menuW, menuH] = menu.get_size();
            let monitor = Main.layoutManager.primaryMonitor;
            menu.set_position(
                Math.round(Math.min(x, monitor.x + monitor.width - menuW - 8)),
                Math.round(Math.min(y - menuH - 8, monitor.y + monitor.height - menuH - 8))
            );
        } catch(e) {}

        // Tracked as the shared _menu so every other tile's click handler
        // (which checks StandaloneDock._menu before doing anything) knows
        // to dismiss this too, instead of it being its own separate,
        // untracked popup.
        StandaloneDock._menu = menu;
        StandaloneDock._menuCatcher = new St.Bin({
            reactive: true,
            x: 0, y: 0,
            width: global.screen_width,
            height: global.screen_height
        });
        Main.uiGroup.add_actor(StandaloneDock._menuCatcher);
        Main.uiGroup.set_child_below_sibling(StandaloneDock._menuCatcher, menu);
        StandaloneDock._menuCatcher.connect("button-press-event", function() {
            StandaloneDock._hideContextMenu();
            return Clutter.EVENT_STOP;
        });
    },

    _openDockSettings: function() {
        try { Utils.openDockSettingsDialog(); } catch(e) {}
    },

    // ---- Blank Screen docklet ----

    _createBlankScreenTile: function() {
        let iconSize = StandaloneDock._renderIconSize || StandaloneDock._iconSize;
        let tile = new St.BoxLayout({
            vertical: true,
            reactive: true,
            track_hover: true,
            style_class: "brahim-dock-tile"
        });

        let icon = StandaloneDock._createBundledIcon("blank.png", "preferences-desktop-display-symbolic", iconSize);
        let iconBin = new St.Bin({ x_align: St.Align.MIDDLE });
        iconBin.set_child(icon);
        tile.add(iconBin, { x_fill: false, x_align: St.Align.MIDDLE, y_fill: false, y_align: St.Align.MIDDLE, expand: true });

        tile.add(new St.Bin({ style_class: "brahim-dock-dot brahim-dock-dot-hidden" }), { x_fill: false, x_align: St.Align.MIDDLE, y_fill: false, y_align: St.Align.END });

        StandaloneDock._wireHoverEffects(tile, iconBin, null, Utils._("Blank Screen"));

        tile.connect("button-press-event", function(actor, event) {
            StandaloneDock._exitShowDesktopIfNeeded();
            let hadOverlay = !!StandaloneDock._menu || !!StandaloneDock._previewPopup;
            StandaloneDock._hideContextMenu();
            StandaloneDock._cancelThumbPreview();
            if (hadOverlay) return Clutter.EVENT_STOP;

            StandaloneDock._showBlankScreen();
            return Clutter.EVENT_STOP;
        });

        return tile;
    },

    // Same cascade as global-settings@brahim's _blankScreen(): actually
    // power the monitor off via DPMS rather than drawing a black actor
    // over the desktop. A drawn overlay leaves the hardware cursor alive
    // and rendering on top of it; forcing DPMS off blanks the physical
    // output, so the cursor disappears with the rest of the screen. Any
    // key press or mouse movement wakes the monitor back up (X server's
    // normal DPMS wake behavior), no dismiss handler needed here.
    _showBlankScreen: function() {
        if (Utils._sh('which xset 2>/dev/null'))
            Utils._run('xset dpms force off');
        else if (Utils._sh('which xdg-screensaver 2>/dev/null'))
            Utils._run('xdg-screensaver activate');
        else
            Utils._run('cinnamon-screensaver-command --activate');
    },

    // ---- Kill Window docklet (xkill-style) ----

    _createKillWindowTile: function() {
        let iconSize = StandaloneDock._renderIconSize || StandaloneDock._iconSize;
        let tile = new St.BoxLayout({
            vertical: true,
            reactive: true,
            track_hover: true,
            style_class: "brahim-dock-tile"
        });

        // Prefer the bundled forcequit.png. If it's missing (deleted,
        // botched install, etc.) fall back to a hand-drawn "X in a
        // circle" glyph so the tile still looks consistent regardless of
        // the user's icon theme (most themes don't ship a dedicated
        // kill/xkill glyph).
        let icon;
        let forceQuitPngPath = Shared.EXTENSION_DIR + "/forcequit.png";
        if (GLib.file_test(forceQuitPngPath, GLib.FileTest.EXISTS)) {
            icon = new St.Icon({ gicon: Gio.icon_new_for_string(forceQuitPngPath), icon_size: iconSize });
        } else {
            icon = new St.DrawingArea({ width: iconSize, height: iconSize });
            icon.connect("repaint", function() {
                StandaloneDock._drawKillWindowIcon(icon);
            });
        }

        let iconBin = new St.Bin({ x_align: St.Align.MIDDLE });
        iconBin.set_child(icon);
        tile.add(iconBin, { x_fill: false, x_align: St.Align.MIDDLE, y_fill: false, y_align: St.Align.MIDDLE, expand: true });

        tile.add(new St.Bin({ style_class: "brahim-dock-dot brahim-dock-dot-hidden" }), { x_fill: false, x_align: St.Align.MIDDLE, y_fill: false, y_align: St.Align.END });

        StandaloneDock._wireHoverEffects(tile, iconBin, null, Utils._("Kill Window"));

        tile.connect("button-press-event", function(actor, event) {
            StandaloneDock._exitShowDesktopIfNeeded();
            let hadOverlay = !!StandaloneDock._menu || !!StandaloneDock._previewPopup;
            StandaloneDock._hideContextMenu();
            StandaloneDock._cancelThumbPreview();
            if (hadOverlay) return Clutter.EVENT_STOP;

            StandaloneDock._startKillWindowPick();
            return Clutter.EVENT_STOP;
        });

        return tile;
    },

    _drawKillWindowIcon: function(area) {
        let cr = area.get_context();
        let [w, h] = area.get_surface_size();
        let cx = w / 2, cy = h / 2;
        let r = Math.min(w, h) / 2 - Math.max(2, w * 0.08);

        cr.setSourceRGBA(1, 1, 1, 0.95);
        cr.setLineWidth(Math.max(1.5, w * 0.075));
        cr.arc(cx, cy, r, 0, 2 * Math.PI);
        cr.stroke();

        let inset = r * 0.5;
        cr.moveTo(cx - inset, cy - inset);
        cr.lineTo(cx + inset, cy + inset);
        cr.moveTo(cx + inset, cy - inset);
        cr.lineTo(cx - inset, cy + inset);
        cr.stroke();

        cr.$dispose();
    },

    _killPickActive: false,
    _killPickCatcher: null,
    _killPickKeyId: null,
    _killPickModal: false,

    // Not implemented via Clutter's actor picking: normal application
    // windows aren't reactive Clutter actors here (input for them goes
    // straight to the X11 client, bypassing the stage's picking), so
    // get_actor_at_pos() would only ever find the catcher itself. Instead
    // this drops a full-screen transparent chrome catcher (same pattern
    // as the trash/context-menu catcher above) to capture the next click,
    // then resolves the window at those coordinates directly from Meta's
    // own stacking order.
    _startKillWindowPick: function() {
        if (StandaloneDock._killPickActive) return;
        StandaloneDock._killPickActive = true;

        try { global.display.set_cursor(Meta.Cursor.CROSSHAIR); } catch(e) {}

        let catcher = new St.Bin({
            reactive: true,
            x: 0, y: 0,
            width: global.screen_width,
            height: global.screen_height
        });
        Main.uiGroup.add_actor(catcher);
        catcher.raise_top();
        StandaloneDock._killPickCatcher = catcher;

        // Without an actual input grab, a bare reactive full-screen actor
        // only receives clicks over areas the shell already owns input
        // for (the desktop, panels, WM-drawn titlebar/decorations) -
        // clicks over a real client window's own content go straight to
        // that client via X11 and never reach Clutter at all. That's
        // exactly the "only the titlebar kills the window" symptom.
        // Main.pushModal() (same mechanism DockCoverflowSwitcher and the
        // Launchpad overlay already use) redirects ALL pointer input to
        // our actor for the duration of the pick, so a click anywhere on
        // the window - titlebar or content - reaches the catcher.
        StandaloneDock._killPickModal = Main.pushModal(catcher);
        if (!StandaloneDock._killPickModal) {
            StandaloneDock._killPickModal = Main.pushModal(catcher, global.get_current_time(), Meta.ModalOptions.POINTER_ALREADY_GRABBED);
        }

        catcher.connect("button-press-event", function(actor, event) {
            let [x, y] = event.get_coords();
            StandaloneDock._cancelKillWindowPick();
            StandaloneDock._killWindowAt(x, y);
            return Clutter.EVENT_STOP;
        });

        StandaloneDock._killPickKeyId = global.stage.connect("key-press-event", function(actor, event) {
            if (event.get_key_symbol() === Clutter.KEY_Escape) {
                StandaloneDock._cancelKillWindowPick();
                return Clutter.EVENT_STOP;
            }
            return Clutter.EVENT_PROPAGATE;
        });
    },

    _cancelKillWindowPick: function() {
        if (!StandaloneDock._killPickActive) return;
        StandaloneDock._killPickActive = false;
        try { global.display.set_cursor(Meta.Cursor.DEFAULT); } catch(e) {}
        if (StandaloneDock._killPickModal) {
            try { Main.popModal(StandaloneDock._killPickCatcher); } catch(e) {}
            StandaloneDock._killPickModal = false;
        }
        if (StandaloneDock._killPickCatcher) {
            try { StandaloneDock._killPickCatcher.destroy(); } catch(e) {}
            StandaloneDock._killPickCatcher = null;
        }
        if (StandaloneDock._killPickKeyId) {
            try { global.stage.disconnect(StandaloneDock._killPickKeyId); } catch(e) {}
            StandaloneDock._killPickKeyId = null;
        }
    },

    _killWindowAt: function(x, y) {
        try {
            let workspace = global.screen.get_active_workspace();
            let windows = workspace ? workspace.list_windows() : [];
            try { windows = global.display.sort_windows_by_stacking(windows); } catch(e) {}
            for (let i = windows.length - 1; i >= 0; i--) {
                let w = windows[i];
                if (!w) continue;
                if (w.get_window_type && w.get_window_type() !== Meta.WindowType.NORMAL) continue;
                if (w.showing_on_its_workspace && !w.showing_on_its_workspace()) continue;
                let rect = w.get_frame_rect ? w.get_frame_rect() : w.get_outer_rect();
                if (!rect) continue;
                if (x >= rect.x && x <= rect.x + rect.width && y >= rect.y && y <= rect.y + rect.height) {
                    w.kill();
                    return;
                }
            }
        } catch(e) {
            global.logError("dock@brahim: kill window pick failed: " + e);
        }
    },

    _isPinned: function(app) {
        return StandaloneDock._getFavoriteIds().indexOf(app.get_id()) !== -1;
    },

    // Mirrors grouped-window-list@cinnamon.org's "middle click = close last
    // focused window in group": ask each MetaWindow directly via
    // has_focus() (same reasoning as _activate() below - global focus
    // tracking can be stale), falling back to the first window if none of
    // the app's windows currently have focus.
    _getFocusedOrFirstWindow: function(app) {
        let windows = [];
        try { windows = app.get_windows() || []; } catch(e) {}
        if (windows.length === 0) return null;
        for (let i = 0; i < windows.length; i++) {
            try { if (windows[i].has_focus()) return windows[i]; } catch(e) {}
        }
        return windows[0];
    },

    _togglePin: function(app) {
        let favs = StandaloneDock._getFavoriteIds().slice();
        let id = app.get_id();
        let idx = favs.indexOf(id);
        if (idx !== -1) favs.splice(idx, 1); else favs.push(id);

        _launchpad().settings.favoriteApps = favs;
        try { SettingsStore.saveLaunchpadSettings(_launchpad().settings); } catch(e) {}
        
        StandaloneDock.refresh();
    },

    _createTile: function(app) {
        let iconSize = StandaloneDock._renderIconSize || StandaloneDock._iconSize || 44;
        let tile = new St.BoxLayout({
            vertical: true,
            reactive: true,
            track_hover: true,
            style_class: "brahim-dock-tile"
        });

        let icon;
        try {
            icon = app.create_icon_texture(iconSize);
        } catch(e) {
            icon = new St.Icon({ icon_name: "application-x-executable", icon_size: iconSize });
        }
        let iconBin = new St.Bin({ x_align: St.Align.MIDDLE });
        iconBin.set_child(icon);

        let nWindows = 0;
        try { nWindows = app.get_n_windows(); } catch(e) {}

        // iconWrap is a plain Clutter.Actor (no layout manager, same
        // "overlay badge" pattern used for the preview thumbnails' close
        // button) so the window-count badge can sit pinned to the icon's
        // corner without disturbing iconBin's own hover-zoom tween.
        let iconWrap = new Clutter.Actor();
        iconWrap.set_size(iconSize, iconSize);
        iconBin.set_size(iconSize, iconSize);
        iconWrap.add_child(iconBin);

        if (nWindows > 1) {
            let badgeSize = 16;
            let badge = new St.Bin({
                style_class: "brahim-dock-badge",
                child: new St.Label({
                    text: nWindows > 9 ? "9+" : String(nWindows),
                    style_class: "brahim-dock-badge-label"
                })
            });
            badge.set_size(badgeSize, badgeSize);
            badge.set_position(iconSize - badgeSize + 5, -5);
            iconWrap.add_child(badge);
        }

        tile.add(iconWrap, { x_fill: false, x_align: St.Align.MIDDLE, y_fill: false, y_align: St.Align.MIDDLE, expand: true });

        let running = nWindows > 0;
        let dot = new St.Bin({
            style_class: "brahim-dock-dot" + (running ? "" : " brahim-dock-dot-hidden")
        });
        tile.add(dot, { x_fill: false, x_align: St.Align.MIDDLE, y_fill: false, y_align: St.Align.END });

        let appName = "";
        try { appName = app.get_name() || ""; } catch(e) {}
        StandaloneDock._wireHoverEffects(tile, iconBin, app, appName);

        tile.connect("button-press-event", function(actor, event) {
            // Any click on a dock icon must dismiss an already-open context
            // menu/preview first. Previously only clicking empty desktop
            // (which hits the full-screen catcher) closed the menu, so
            // clicking a *different* dock icon while a menu was open left
            // the old menu stuck on screen ("stubborn"), and could also eat
            // that first click instead of activating the app.
            StandaloneDock._exitShowDesktopIfNeeded();
            let hadOverlay = !!StandaloneDock._menu || !!StandaloneDock._previewPopup;
            StandaloneDock._hideContextMenu();
            StandaloneDock._cancelThumbPreview();
            StandaloneDock._cancelTooltip();
            if (hadOverlay) return Clutter.EVENT_STOP;

            let button = event.get_button();
            if (button === 3) {
                let [x, y] = event.get_coords();
                StandaloneDock._showContextMenu(app, x, y);
                return Clutter.EVENT_STOP;
            }

            if (button === 2) {
                let win = StandaloneDock._getFocusedOrFirstWindow(app);
                if (win) { try { WindowEffects.closeWindow(win); } catch(e) {} }
                return Clutter.EVENT_STOP;
            }

            // Pinned icons can be picked up and dragged to reorder them,
            // but only once the "Lock launcher icons" toggle is switched
            // off - locked (the default) behaves exactly as before, with
            // every click activating the app immediately.
            let ds = SettingsStore.getDockSettings();
            if (button === 1 && ds.lockLauncher === false && StandaloneDock._isPinned(app)) {
                StandaloneDock._beginDrag(app, tile, event);
                return Clutter.EVENT_STOP;
            }

            StandaloneDock._activate(app);
            return Clutter.EVENT_STOP;
        });

        return tile;
    },

    _exitShowDesktopIfNeeded: function() {
        // Cinnamon only auto-exits "show desktop" mode when a real Meta
        // window gets activated (see maybe_leave_show_desktop_mode() in
        // Muffin's window.c) - our dock is pure Clutter/St chrome, not a
        // Meta window, so clicking it never triggers that exit on its own.
        // Left lingering, that internal state can make the dock feel
        // "frozen" right after a hotcorner-driven Show Desktop. So: any
        // real interaction with the dock forces a clean exit via the real
        // API first. meta_workspace_manager_unshow_desktop() is a no-op
        // when show-desktop isn't active (checked internally in Muffin's
        // own source), so it's safe to just always call this rather than
        // gating it on our own tracking of whether we think we're in that
        // mode - that tracking is exactly what kept being unreliable.
        try {
            let wsManager = global.workspace_manager || global.screen;
            wsManager.unshow_desktop(global.get_current_time());
        } catch(e) {}
        try { StandaloneDock.widget.raise_top(); } catch(e) {}
        try { StandaloneDock._ensureInteractive(); } catch(e) {}
    },

    _activate: function(app) {
        // All of the previous approach here (a hand-rolled per-app
        // minimized/focused tracker, plus settle-timers to dodge the
        // minimize animation) was working around staleness in
        // global.display.focus_window - but that was the wrong thing to
        // read in the first place. Cinnamon's own bundled applet that does
        // exactly this job, window-list@cinnamon.org, doesn't track
        // anything itself: it asks the MetaWindow directly via
        // w.has_focus(), which Meta updates synchronously the instant
        // minimize()/activate() are called (it's the logical WM state, not
        // the compositor's visual animation state), so there's no lag to
        // work around and nothing to remember between clicks. Matching
        // that pattern here instead of maintaining our own state machine.
        StandaloneDock._exitShowDesktopIfNeeded();

        let windows = [];
        try { windows = app.get_windows() || []; } catch(e) {}

        if (windows.length === 0) {
            try { app.open_new_window(-1); }
            catch(e) { try { app.activate(); } catch(e2) {} }
            return;
        }

        if (windows.length === 1) {
            let w = windows[0];
            try {
                if (w.has_focus()) {
                    WindowEffects.minimizeWindow(w);
                } else {
                    // has_focus() being false covers both "minimized" and
                    // "focused elsewhere" - Main.activateWindow() alone
                    // doesn't reliably unminimize on every Cinnamon/Muffin
                    // build, which is what forced repeated clicks to bring
                    // a minimized window back. Unminimize explicitly first.
                    if (w.minimized) WindowEffects.unminimizeWindow(w);
                    Main.activateWindow(w);
                }
                return;
            } catch(e) {}
            // Fallback for any Cinnamon build where has_focus() isn't
            // available on this object for some reason.
            try {
                if (global.display.focus_window === w && !w.minimized) {
                    w.minimize();
                } else {
                    w.unminimize();
                    w.activate(global.get_current_time());
                }
            } catch(e2) {}
            return;
        }

        // Same staleness problem as the single-window case above, and the
        // same fix: don't trust global.display.focus_window, ask each
        // MetaWindow directly. (This path used to fall back to comparing
        // against global.display.focus_window when none of the app's
        // windows reported focus - see the BUGFIX comment below for why
        // that was removed.)
        let idx = -1;
        for (let i = 0; i < windows.length; i++) {
            try {
                if (windows[i].has_focus()) { idx = i; break; }
            } catch(e) {}
        }
        if (idx !== -1) {
            let next = windows[(idx + 1) % windows.length];
            try {
                if (next.minimized) WindowEffects.unminimizeWindow(next);
                Main.activateWindow(next);
                return;
            } catch(e) {}
            try {
                next.unminimize();
                next.activate(global.get_current_time());
                return;
            } catch(e) {}
            return;
        }

        // BUGFIX: none of this app's own windows currently has focus (the
        // "inactive icon" case - this is the click that was reported as
        // sometimes activating/maximizing a window the user didn't click
        // on). This used to fall back to
        // `windows.indexOf(global.display.focus_window)` to pick a cycle
        // start point, but global.display.focus_window is exactly the
        // globally-stale field has_focus() was adopted to work around in
        // the first place (see the rationale above _activate). When it
        // still held a reference to an old window, indexOf() could
        // resolve to some unrelated index instead of -1, and the code
        // would then activate whatever window followed it, not the app
        // the user actually clicked. Always deterministically raise this
        // app's first window instead - no stale global state involved.
        try {
            if (windows[0].minimized) WindowEffects.unminimizeWindow(windows[0]);
            Main.activateWindow(windows[0]);
            return;
        } catch(e) {}
        try {
            windows[0].unminimize();
            windows[0].activate(global.get_current_time());
            return;
        } catch(e) {}
    },

    // Loads <Shared.EXTENSION_DIR>/fileName as the docklet icon if present;
    // otherwise falls back to the given symbolic icon name so a deleted
    // or missing PNG never leaves the tile blank.
    _createBundledIcon: function(fileName, fallbackIconName, iconSize) {
        let pngPath = Shared.EXTENSION_DIR + "/" + fileName;
        if (GLib.file_test(pngPath, GLib.FileTest.EXISTS)) {
            try {
                return new St.Icon({ gicon: Gio.icon_new_for_string(pngPath), icon_size: iconSize });
            } catch (e) {}
        }
        return new St.Icon({ icon_name: fallbackIconName, icon_size: iconSize, style: "color: #ffffff;" });
    },

    // ---- Per-app hover accent ----
    // Hovering a running/pinned app's dock icon briefly tints the dock's
    // own background (and, via _showTooltip/Launchpad.applyAccent, the
    // tooltip and the Launchpad overlay when open) toward that app icon's
    // dominant color, then eases back on leave. Reuses the same 1x1-scale
    // pixbuf averaging trick DockAlbumArt.getDominantColor() already uses
    // for MPRIS album art, just pointed at the app's resolved icon file
    // instead of a track's art file.

    _ACCENT_MAX_BLEND: 0.55,
    _accentTweenState: { t: 0 },
    _accentRgb: null,
    _accentHoverApp: null,
    _appAccentCache: {},

    _resolveAppIconPath: function(app) {
        let idForLog = "?";
        try { idForLog = app.get_id ? app.get_id() : "?"; } catch(e) {}
        try {
            // Cinnamon.App has no get_icon() of its own - that's a
            // Gio.AppInfo method. (This is why every hover logged "app has
            // no icon": `app.get_icon` was truthy as a property lookup on
            // the prototype chain but always returned undefined when
            // called.) Go through Gio.DesktopAppInfo instead, resolved
            // from the app's id - the same conversion _getCategoryKey()
            // above already relies on for category lookups.
            let gicon = null;
            if (idForLog && idForLog !== "?") {
                try {
                    let desktopInfo = Gio.DesktopAppInfo.new(idForLog);
                    if (desktopInfo) gicon = desktopInfo.get_icon();
                } catch(e) {}
            }
            if (!gicon) {
                global.log("dock@brahim ACCENT_DEBUG: " + idForLog + " - app has no icon");
                return null;
            }

            // Icon= pointing at an absolute path (Gio.FileIcon) resolves
            // straight to a path without any theme lookup - covers apps
            // lookup_by_gicon can otherwise miss entirely.
            if (gicon instanceof Gio.FileIcon) {
                let f = gicon.get_file();
                let p = f ? f.get_path() : null;
                if (p) return p;
            }

            let iconSize = StandaloneDock._renderIconSize || StandaloneDock._iconSize || 48;
            let iconTheme = Gtk.IconTheme.get_default();
            let flags = Gtk.IconLookupFlags.FORCE_SIZE | Gtk.IconLookupFlags.GENERIC_FALLBACK;

            let info = iconTheme.lookup_by_gicon(gicon, iconSize, flags);
            if (!info && gicon.get_names) {
                // Themed icons often carry several fallback names (e.g.
                // ["firefox", "firefox-symbolic", "application-x-executable"]).
                // lookup_by_gicon tries the icon as a single unit; choose_icon
                // walks that name list individually and resolves some apps
                // lookup_by_gicon alone comes back empty for.
                try {
                    let names = gicon.get_names();
                    if (names && names.length) info = iconTheme.choose_icon(names, iconSize, flags);
                } catch(e2) {}
            }

            if (!info) {
                global.log("dock@brahim ACCENT_DEBUG: " + idForLog + " - no icon-theme match for " + gicon.to_string());
                return null;
            }
            let path = info.get_filename();
            if (!path) global.log("dock@brahim ACCENT_DEBUG: " + idForLog + " - icon matched but has no on-disk filename");
            return path;
        } catch(e) {
            global.logError("dock@brahim ACCENT_DEBUG: " + idForLog + " - _resolveAppIconPath threw: " + e);
        }
        return null;
    },

    // Cached per app id (a `false` cache entry means "already tried,
    // couldn't resolve a color" - so a broken/unthemed icon isn't
    // re-looked-up on every single hover).
    _getAppAccentColor: function(app, callback) {
        let id;
        try { id = app.get_id(); } catch(e) { id = null; }
        if (!id) { callback(null); return; }

        if (StandaloneDock._appAccentCache.hasOwnProperty(id)) {
            callback(StandaloneDock._appAccentCache[id] || null);
            return;
        }

        let path = StandaloneDock._resolveAppIconPath(app);
        if (!path) {
            StandaloneDock._appAccentCache[id] = false;
            callback(null);
            return;
        }

        _media().DockAlbumArt.getDominantColor(path, function(rgb) {
            StandaloneDock._appAccentCache[id] = rgb || false;
            if (rgb) {
                global.log("dock@brahim ACCENT_DEBUG: " + id + " - resolved color rgb(" + rgb.r + "," + rgb.g + "," + rgb.b + ") from " + path);
            } else {
                global.log("dock@brahim ACCENT_DEBUG: " + id + " - getDominantColor failed on " + path);
            }
            callback(rgb || null);
        });
    },

    _applyDockAccentBlend: function(t) {
        if (!StandaloneDock.widget) return;
        if (!StandaloneDock._accentRgb || t <= 0) {
            StandaloneDock.widget.set_style(StandaloneDock._buildStyle());
            return;
        }
        StandaloneDock.widget.set_style(StandaloneDock._buildStyle(StandaloneDock._accentRgb, t));
    },

    _startAppAccent: function(app) {
        let s = SettingsStore.getDockSettings();
        if (s.perAppAccentEnabled === false) return;

        StandaloneDock._accentHoverApp = app;
        StandaloneDock._getAppAccentColor(app, function(rgb) {
            // The pointer may have moved to a different tile (or left
            // entirely) while this resolved - only apply if this app is
            // still the one currently hovered.
            if (StandaloneDock._accentHoverApp !== app || !rgb) {
                if (StandaloneDock._accentHoverApp !== app) {
                    global.log("dock@brahim ACCENT_DEBUG: color resolved after pointer moved on, skipping");
                } else {
                    global.log("dock@brahim ACCENT_DEBUG: no color to apply, accent skipped");
                }
                return;
            }

            global.log("dock@brahim ACCENT_DEBUG: starting accent tween rgb(" + rgb.r + "," + rgb.g + "," + rgb.b + ")");
            StandaloneDock._accentRgb = rgb;
            Tweener.removeTweens(StandaloneDock._accentTweenState);
            Tweener.addTween(StandaloneDock._accentTweenState, {
                t: 1,
                time: 0.28,
                transition: "easeOutQuad",
                onUpdate: function() { StandaloneDock._applyDockAccentBlend(StandaloneDock._accentTweenState.t); }
            });

            try {
                let lp = _launchpad();
                if (lp && lp._isOpen && lp.applyAccent) lp.applyAccent(rgb);
            } catch(e) {}
        });
    },

    _endAppAccent: function() {
        if (!StandaloneDock._accentHoverApp && !StandaloneDock._accentRgb) return;
        StandaloneDock._accentHoverApp = null;

        Tweener.removeTweens(StandaloneDock._accentTweenState);
        Tweener.addTween(StandaloneDock._accentTweenState, {
            t: 0,
            time: 0.35,
            transition: "easeOutQuad",
            onUpdate: function() { StandaloneDock._applyDockAccentBlend(StandaloneDock._accentTweenState.t); },
            onComplete: function() {
                StandaloneDock._accentRgb = null;
                StandaloneDock.widget.set_style(StandaloneDock._buildStyle());
            }
        });

        try {
            let lp = _launchpad();
            if (lp && lp.clearAccent) lp.clearAccent();
        } catch(e) {}
    },

    _wireHoverEffects: function(tile, iconBin, app, tooltipText) {
        iconBin.set_pivot_point(0.5, 0.5);

        tile.connect("enter-event", function() {
            let s = SettingsStore.getDockSettings();
            if (s.zoomEnabled) {
                let factor = s.zoomFactor || 1.4;
                Tweener.removeTweens(iconBin);
                Tweener.addTween(iconBin, { 
                    scale_x: factor, 
                    scale_y: factor,
                    rotation_z: 0.15,
                    rotation_x: -0.08,
                    rotation_y: 0.04,
                    time: 0.18, 
                    transition: "easeOutQuad",
                    onUpdate: function() {
                        let shadowOpacity = Math.min(1.0, (iconBin.scale_x - 1.0) * 2.5);
                        if (shadowOpacity > 0.05) {
                            iconBin.set_style('box-shadow: 0 ' + (10 * shadowOpacity) + 'px ' + (20 * shadowOpacity) + 'px rgba(0,0,0,' + (0.3 * shadowOpacity) + ');');
                        } else {
                            iconBin.set_style('');
                        }
                    }
                });
            }
            if (app) {
                StandaloneDock._cancelScheduledHidePreview();
                StandaloneDock._scheduleThumbPreview(app, tile);
                StandaloneDock._startAppAccent(app);
            }
            if (tooltipText) {
                let tipText = (typeof tooltipText === "function") ? tooltipText() : tooltipText;
                if (tipText) StandaloneDock._scheduleTooltip(tile, tipText, app);
            }
            return Clutter.EVENT_PROPAGATE;
        });

        tile.connect("leave-event", function() {
            Tweener.removeTweens(iconBin);
            Tweener.addTween(iconBin, { 
                scale_x: 1, 
                scale_y: 1,
                rotation_z: 0,
                rotation_x: 0,
                rotation_y: 0,
                time: 0.18, 
                transition: "easeOutQuad",
                onComplete: function() {
                    iconBin.set_style('');
                }
            });
            // The preview popup floats above the tile with a gap in
            // between, so moving the pointer from the icon up to the
            // thumbnail always crosses this tile's boundary first. Hiding
            // immediately here was destroying the popup before the click
            // could land on it. Give it a short grace period instead -
            // cancelled the instant the pointer actually reaches the
            // popup (see its own enter-event in _showThumbPreview).
            if (app) {
                StandaloneDock._scheduleHidePreview();
                StandaloneDock._endAppAccent();
            } else {
                StandaloneDock._cancelThumbPreview();
            }
            StandaloneDock._cancelTooltip();
            return Clutter.EVENT_PROPAGATE;
        });
    },

    // ---- macOS-style speech-bubble tooltips ----

    _scheduleTooltip: function(tile, text, app) {
        StandaloneDock._cancelTooltip();
        let s = SettingsStore.getDockSettings();
        if (s.showTooltips === false) return;
        if (!text) return;
        if (StandaloneDock._isAltTabActive()) return;
        StandaloneDock._tooltipTimeoutId = Mainloop.timeout_add(550, function() {
            StandaloneDock._tooltipTimeoutId = null;
            if (StandaloneDock._isAltTabActive()) return;
            try { StandaloneDock._showTooltip(tile, text, app); } catch(e) {}
            return false;
        });
    },

    _cancelTooltip: function() {
        if (StandaloneDock._tooltipTimeoutId) {
            Mainloop.source_remove(StandaloneDock._tooltipTimeoutId);
            StandaloneDock._tooltipTimeoutId = null;
        }
        StandaloneDock._hideTooltip();
    },

    _hideTooltip: function() {
        if (StandaloneDock._tooltipPopup) {
            try { Main.uiGroup.remove_actor(StandaloneDock._tooltipPopup); } catch(e) {}
            try { StandaloneDock._tooltipPopup.destroy(); } catch(e) {}
            StandaloneDock._tooltipPopup = null;
        }
    },

    _showTooltip: function(tile, text, app) {
        StandaloneDock._hideTooltip();
        if (!tile || !tile.get_stage()) return;
        if (StandaloneDock._isAltTabActive()) return;
        // A window-thumbnail preview or a context menu already occupies
        // the space above the tile - don't stack a tooltip bubble on top
        // of either.
        if (StandaloneDock._previewPopup || StandaloneDock._menu) return;

        let isDark = !StandaloneDock._isDockColorLight();
        let themeClass = isDark ? "launchpad-dark" : "launchpad-light";

        // Use the dock's actual rendered background color (same color +
        // same transparency it shows itself), not a separately-invented
        // alpha, so the tooltip genuinely matches the dock instead of
        // just being vaguely tinted toward it.
        let tintedBg = StandaloneDock._getDockColorWithAlpha();

        // If this tooltip belongs to an app tile whose icon accent has
        // already resolved (it was kicked off the moment the hover
        // started, in _startAppAccent - well before this 550ms-delayed
        // tooltip appears), tint the bubble toward that same color so it
        // reads as part of the same hover accent as the dock itself.
        if (app) {
            let s = SettingsStore.getDockSettings();
            if (s.perAppAccentEnabled !== false) {
                let id;
                try { id = app.get_id(); } catch(e) { id = null; }
                let rgb = (id && StandaloneDock._appAccentCache[id]) ? StandaloneDock._appAccentCache[id] : null;
                if (rgb) tintedBg = Utils.blendTowardAccent(tintedBg, rgb, 1, StandaloneDock._ACCENT_MAX_BLEND, 0.7);
            }
        }

        let wrapper = new St.BoxLayout({ vertical: true, reactive: false });

        let bubble = new St.BoxLayout({
            vertical: true,
            style_class: "brahim-dock-tooltip " + themeClass,
            reactive: false
        });
        if (tintedBg) bubble.set_style("background-color: " + tintedBg + " !important;");
        let label = new St.Label({
            text: text,
            style_class: "brahim-dock-tooltip-label " + themeClass
        });
        // Belt-and-suspenders: force out any background the label might
        // otherwise inherit from the system theme, so only the bubble
        // behind it ever paints - no second rectangle behind the text.
        label.set_style("background-color: transparent !important;");
        bubble.add(label, { x_fill: true, y_fill: true });
        wrapper.add(bubble, { x_fill: false, x_align: St.Align.MIDDLE });

        let arrow = new St.DrawingArea({
            style_class: "brahim-dock-tooltip-arrow",
            reactive: false,
            width: 14,
            height: 7
        });
        arrow.connect("repaint", function() {
            StandaloneDock._drawTooltipArrow(arrow, isDark, tintedBg);
        });
        wrapper.add(arrow, { x_fill: false, x_align: St.Align.MIDDLE });

        Main.uiGroup.add_actor(wrapper);

        try {
            let [tx, ty] = tile.get_transformed_position();
            let [minW, natW] = wrapper.get_preferred_width(-1);
            let [minH, natH] = wrapper.get_preferred_height(-1);
            let w = natW || minW || 0;
            let h = natH || minH || 0;
            let tileW = tile.width || 0;
            let x = Math.round(tx + (tileW / 2) - (w / 2));
            let y = Math.round(ty - h - 10);

            let monitor = Main.layoutManager.primaryMonitor;
            if (monitor) {
                x = Math.max(monitor.x + 8, Math.min(x, monitor.x + monitor.width - w - 8));
            }
            wrapper.set_position(x, y);
        } catch(e) {
            wrapper.set_position(0, 0);
        }

        wrapper.opacity = 0;
        Tweener.addTween(wrapper, { opacity: 255, time: 0.12, transition: "easeOutQuad" });

        StandaloneDock._tooltipPopup = wrapper;
    },

    _drawTooltipArrow: function(area, isDark, tintedBg) {
        let cr = area.get_context();
        let [w, h] = area.get_surface_size();

        cr.moveTo(1, 0);
        cr.lineTo(w - 1, 0);
        cr.lineTo(w / 2, h);
        cr.closePath();

        let rgba = tintedBg ? StandaloneDock._parseRGBA(tintedBg) : null;
        if (rgba) {
            cr.setSourceRGBA(rgba[0] / 255, rgba[1] / 255, rgba[2] / 255, rgba[3]);
        } else if (isDark) {
            cr.setSourceRGBA(32 / 255, 32 / 255, 36 / 255, 0.82);
        } else {
            cr.setSourceRGBA(252 / 255, 252 / 255, 254 / 255, 0.88);
        }
        cr.fill();
        cr.$dispose();
    },

    // ---- Drag-to-reorder for pinned launcher icons ----

    _beginDrag: function(app, tile, event) {
        StandaloneDock._cancelTooltip();
        StandaloneDock._cancelThumbPreview();

        let [startX, startY] = event.get_coords();
        let state = {
            app: app,
            tile: tile,
            startX: startX,
            startY: startY,
            moved: false,
            motionId: 0,
            releaseId: 0
        };
        StandaloneDock._dragState = state;
        tile.set_pivot_point(0.5, 0.5);

        state.motionId = global.stage.connect("motion-event", function(actor, ev) {
            let cur = StandaloneDock._dragState;
            if (!cur) return Clutter.EVENT_PROPAGATE;
            let [x, y] = ev.get_coords();
            let dx = x - cur.startX;
            if (!cur.moved && Math.abs(dx) > 6) {
                cur.moved = true;
                cur.tile.set_scale(1.1, 1.1);
                cur.tile.set_opacity(180);
                try { StandaloneDock.widget.set_child_above_sibling(cur.tile, null); } catch(e) {}
            }
            if (cur.moved) {
                cur.tile.translation_x = dx;
            }
            return Clutter.EVENT_PROPAGATE;
        });

        state.releaseId = global.stage.connect("button-release-event", function(actor, ev) {
            StandaloneDock._endDrag(ev);
            return Clutter.EVENT_PROPAGATE;
        });
    },

    _endDrag: function(event) {
        let state = StandaloneDock._dragState;
        if (!state) return;
        StandaloneDock._dragState = null;

        try { global.stage.disconnect(state.motionId); } catch(e) {}
        try { global.stage.disconnect(state.releaseId); } catch(e) {}

        let tile = state.tile;
        try {
            tile.set_scale(1, 1);
            tile.set_opacity(255);
            tile.translation_x = 0;
        } catch(e) {}

        if (!state.moved) {
            // Never moved past the threshold - treat it as a normal click.
            StandaloneDock._activate(state.app);
            return;
        }

        let releaseX = state.startX;
        try { if (event) [releaseX] = event.get_coords(); } catch(e) {}
        StandaloneDock._reorderFavorite(state.app, releaseX);
    },

    _reorderFavorite: function(app, releaseX) {
        let entries = (StandaloneDock._appTileEntries || []).filter(function(entry) {
            return entry.tile && entry.tile.get_stage() && StandaloneDock._isPinned(entry.app);
        });
        if (entries.length < 2) return;

        let favIds = StandaloneDock._getFavoriteIds().slice();
        let id = app.get_id();
        let oldIdx = favIds.indexOf(id);
        if (oldIdx === -1) return;

        // Insertion index is based on how many *other* pinned tiles sit to
        // the left of the release point, using each tile's current
        // on-screen center (captured just before the drop, so it reflects
        // the actual layout the user was dragging within).
        let newIdx = 0;
        entries.forEach(function(entry) {
            if (entry.app === app) return;
            let center;
            try {
                let [ex] = entry.tile.get_transformed_position();
                center = ex + (entry.tile.width || 0) / 2;
            } catch(e) {
                center = 0;
            }
            if (releaseX > center) newIdx++;
        });

        favIds.splice(oldIdx, 1);
        if (newIdx > favIds.length) newIdx = favIds.length;
        favIds.splice(newIdx, 0, id);

        if (!_launchpad().settings) return;
        _launchpad().settings.favoriteApps = favIds;
        try { SettingsStore.saveLaunchpadSettings(_launchpad().settings); } catch(e) {}
        StandaloneDock.refresh();
    },

    _scheduleThumbPreview: function(app, tile) {
        StandaloneDock._cancelThumbPreview();
        if (StandaloneDock._isAltTabActive()) return;
        StandaloneDock._previewTimeoutId = Mainloop.timeout_add(400, function() {
            StandaloneDock._previewTimeoutId = null;
            if (StandaloneDock._isAltTabActive()) return;
            try { StandaloneDock._showThumbPreview(app, tile); } catch(e) {}
            return false;
        });
    },

    // Short grace period before actually hiding the popup, so crossing the
    // gap between the dock icon and the floating popup above it doesn't
    // destroy the popup mid-transit. Cancelled by _cancelScheduledHidePreview()
    // the moment the pointer reaches either the tile again or the popup
    // itself (see _showThumbPreview's own enter-event).
    _scheduleHidePreview: function() {
        StandaloneDock._cancelScheduledHidePreview();
        StandaloneDock._hidePreviewTimeoutId = Mainloop.timeout_add(220, function() {
            StandaloneDock._hidePreviewTimeoutId = null;
            StandaloneDock._hideThumbPreview();
            return false;
        });
    },

    _cancelScheduledHidePreview: function() {
        if (StandaloneDock._hidePreviewTimeoutId) {
            Mainloop.source_remove(StandaloneDock._hidePreviewTimeoutId);
            StandaloneDock._hidePreviewTimeoutId = null;
        }
    },

    _cancelThumbPreview: function() {
        if (StandaloneDock._previewTimeoutId) {
            Mainloop.source_remove(StandaloneDock._previewTimeoutId);
            StandaloneDock._previewTimeoutId = null;
        }
        if (StandaloneDock._mediaPreviewTimeoutId) {
            Mainloop.source_remove(StandaloneDock._mediaPreviewTimeoutId);
            StandaloneDock._mediaPreviewTimeoutId = null;
        }
        StandaloneDock._cancelScheduledHidePreview();
        StandaloneDock._hideThumbPreview();
    },

    _hideThumbPreview: function() {
        StandaloneDock._cancelScheduledHidePreview();
        StandaloneDock._stopPreviewWatchdog();
        StandaloneDock._endHoverPeek(true);
        if (StandaloneDock._previewBridge) {
            try { Main.uiGroup.remove_actor(StandaloneDock._previewBridge); } catch(e) {}
            try { StandaloneDock._previewBridge.destroy(); } catch(e) {}
            StandaloneDock._previewBridge = null;
        }
        if (StandaloneDock._previewCatcher) {
            try { Main.uiGroup.remove_actor(StandaloneDock._previewCatcher); } catch(e) {}
            try { StandaloneDock._previewCatcher.destroy(); } catch(e) {}
            StandaloneDock._previewCatcher = null;
        }
        if (StandaloneDock._previewPopup) {
            try { Main.uiGroup.remove_actor(StandaloneDock._previewPopup); } catch(e) {}
            try { StandaloneDock._previewPopup.destroy(); } catch(e) {}
            StandaloneDock._previewPopup = null;
        }
    },

    _createWindowThumb: function(win, maxW, maxH) {
        let actor = null;
        try { actor = win.get_compositor_private(); } catch(e) {}
        if (!actor) return null;

        // actor.width/height reflects the *live* composited size, which is
        // 0 for windows that aren't currently mapped on screen - i.e. any
        // window sitting on a workspace other than the active one, and
        // sometimes minimized windows. A plain Clutter.Clone of that actor
        // has nothing to show, so it used to just bail out here - meaning
        // an app with windows spread across workspaces only ever got a
        // thumbnail for whichever one happened to be on the current
        // workspace. WindowUtils.getCloneOrContent (the same helper
        // grouped-window-list uses) falls back to a static cached texture
        // for windows without a live actor size, so every window gets a
        // thumbnail regardless of which workspace it's on.
        let w = actor.width, h = actor.height;
        let hasLiveSize = !!(w && h);

        if (WindowUtils && typeof WindowUtils.getCloneOrContent === "function") {
            try {
                let targetW = hasLiveSize ? Math.round(Math.min(maxW / w, maxH / h, 1) * w) : maxW;
                let targetH = hasLiveSize ? Math.round(Math.min(maxW / w, maxH / h, 1) * h) : maxH;
                let clone = WindowUtils.getCloneOrContent(actor, targetW, targetH);
                if (clone) return clone;
            } catch(e) {}
        }

        if (!hasLiveSize) return null;

        let scale = Math.min(maxW / w, maxH / h, 1);
        let clone;
        try {
            clone = new Clutter.Clone({ source: actor });
        } catch(e) {
            return null;
        }
        clone.set_size(Math.round(w * scale), Math.round(h * scale));
        return clone;
    },

    // ---- Hover-peek (grouped-window-list style) ----
    // Rather than raising/lowering the real MetaWindow (which has no clean
    // "undo" once other windows have re-stacked), clone its compositor
    // actor into global.overlay_group at its real screen position/size and
    // fade the clone in/out. Same technique grouped-window-list's
    // WindowThumbnail.hoverPeek()/destroyOverlayPreview() use, and it's
    // inherently safe: the clone is purely visual and never touches real
    // window stacking or focus.
    _peekClone: null,

    _startHoverPeek: function(win) {
        StandaloneDock._endHoverPeek();
        if (!win) return;

        let actor = null;
        try { actor = win.get_compositor_private(); } catch(e) {}
        if (!actor) return;

        let clone;
        try { clone = new Clutter.Clone({ source: actor }); } catch(e) { return; }

        try {
            let [x, y] = actor.get_position();
            let [w, h] = actor.get_size();
            clone.set_position(x, y);
            clone.set_size(w, h);
        } catch(e) {}

        clone.set_opacity(0);
        let group = global.overlay_group || Main.uiGroup;
        try { group.add_child(clone); } catch(e) { try { group.add_actor(clone); } catch(e2) { return; } }
        try { group.set_child_above_sibling(clone, null); } catch(e) {}

        Tweener.addTween(clone, { opacity: 235, time: 0.18, transition: "easeOutQuad" });
        StandaloneDock._peekClone = clone;
    },

    // immediate=true skips the fade and tears the clone down synchronously.
    // Activating or closing a window can trigger a restack or workspace
    // switch on the very next tick, which can invalidate the clone's
    // source out from under a still-running fade tween - the visible
    // symptom is a frozen last-frame ghost of the window that never goes
    // away on its own. Any call site that's about to change window state
    // (activate/close) must pass immediate=true; only the passive
    // "pointer left the thumbnail" path should fade.
    _endHoverPeek: function(immediate) {
        let clone = StandaloneDock._peekClone;
        if (!clone) return;
        StandaloneDock._peekClone = null;

        Tweener.removeTweens(clone);

        let destroyClone = function() {
            try {
                let group = global.overlay_group || Main.uiGroup;
                try { group.remove_child(clone); } catch(e) { group.remove_actor(clone); }
            } catch(e) {}
            try { clone.destroy(); } catch(e) {}
        };

        if (immediate) {
            destroyClone();
            return;
        }

        Tweener.addTween(clone, {
            opacity: 0,
            time: 0.12,
            transition: "easeOutQuad",
            onComplete: destroyClone
        });
    },

    _showThumbPreview: function(app, tile) {
        StandaloneDock._hideThumbPreview();
        if (!tile || !tile.get_stage()) return;
        if (StandaloneDock._isAltTabActive()) return;

        let windows = [];
        try { windows = app.get_windows() || []; } catch(e) {}
        if (windows.length === 0) return;

        let isDark = !StandaloneDock._isDockColorLight();

        let popup = new St.BoxLayout({
            vertical: false,
            style_class: "brahim-dock-preview " + (isDark ? "launchpad-dark" : "launchpad-light"),
            reactive: true
        });
        // Use the dock's actual rendered background color (same color +
        // same transparency it shows itself), not a separately invented
        // alpha, so the preview genuinely matches the dock.
        try {
            let tinted = StandaloneDock._getDockColorWithAlpha();
            if (tinted) popup.set_style("background-color: " + tinted + " !important;");
        } catch(e) {}

        // Last-focused window (if any) gets the "outlined" highlight ring,
        // same rule grouped-window-list uses (highlightLastFocusedThumbnail,
        // only when the app has more than one window).
        let focusedWin = null;
        try { focusedWin = windows.find(function(w) { try { return w.has_focus(); } catch(e) { return false; } }) || null; } catch(e) {}

        let thumbMaxW = 280, thumbMaxH = 180;
        let added = 0;
        windows.forEach(function(win) {
            let thumb = StandaloneDock._createWindowThumb(win, thumbMaxW, thumbMaxH);
            if (!thumb) return;

            let isFocused = windows.length > 1 && win === focusedWin;
            let col = new St.BoxLayout({
                vertical: true,
                style_class: "brahim-dock-preview-item" + (isFocused ? " brahim-dock-preview-item-focused" : ""),
                reactive: true,
                track_hover: true
            });

            // thumbWrap is a plain Clutter.Actor (no layout manager) so the
            // close button can be pinned to a fixed corner position on top
            // of the thumbnail, the same "overlay badge" pattern Cinnamon
            // itself uses for notification/count badges.
            let thumbBin = new St.Bin({ style_class: "brahim-dock-preview-thumb" });
            // The CSS border-radius on this St.Bin only draws a rounded
            // background/border - it does NOT clip children by default, so
            // the window clone's square corners were always poking out
            // past the rounded frame. This is what was making the
            // thumbnails look like flat rectangles instead of the
            // rounded-card look macOS Tahoe uses.
            thumbBin.set_clip_to_allocation(true);
            thumbBin.set_child(thumb);

            let tw = thumb.width || thumbMaxW, th = thumb.height || thumbMaxH;
            thumbBin.set_size(tw, th);

            let thumbWrap = new Clutter.Actor();
            thumbWrap.set_size(tw, th);
            thumbWrap.add_child(thumbBin);

            let closeBtn = new St.Button({ style_class: "brahim-dock-preview-close", reactive: true, opacity: 0 });
            closeBtn.set_child(new St.Icon({ icon_name: "window-close-symbolic", icon_size: 11 }));
            closeBtn.set_size(18, 18);
            // macOS puts the traffic-light close control at the top-LEFT
            // of a window/thumbnail, not the top-right.
            closeBtn.set_position(-5, -5);
            thumbWrap.add_child(closeBtn);

            col.add(thumbWrap, { x_fill: false, x_align: St.Align.MIDDLE });

            let title = "";
            try { title = win.get_title() || ""; } catch(e) {}
            let label = new St.Label({
                text: title,
                style_class: "brahim-dock-preview-label " + (isDark ? "launchpad-dark" : "launchpad-light")
            });
            label.set_style("background-color: transparent !important;");
            label.clutter_text.set_ellipsize(imports.gi.Pango.EllipsizeMode.END);
            col.add(label, { x_fill: false, x_align: St.Align.MIDDLE });

            let closeWindow = function() {
                StandaloneDock._endHoverPeek(true);
                try { win.delete(global.get_current_time()); } catch(e) {}
                StandaloneDock._hideThumbPreview();
            };
            closeBtn.connect("clicked", function() {
                closeWindow();
                return Clutter.EVENT_STOP;
            });

            // Hover-peek: bring the real window forward as a translucent
            // overlay while the pointer rests on its thumbnail, and reveal
            // the close button. Only fires for events landing on the item
            // itself, not ones already claimed by closeBtn.
            col.connect("enter-event", function(actor, event) {
                if (event.get_source() === closeBtn) return Clutter.EVENT_PROPAGATE;
                closeBtn.set_opacity(255);
                StandaloneDock._startHoverPeek(win);
                return Clutter.EVENT_PROPAGATE;
            });
            col.connect("leave-event", function() {
                closeBtn.set_opacity(0);
                StandaloneDock._endHoverPeek();
                return Clutter.EVENT_PROPAGATE;
            });

            col.connect("button-release-event", function(actor, event) {
                if (event.get_source() === closeBtn) return Clutter.EVENT_PROPAGATE;
                let btn = event.get_button();
                if (btn === 2) {
                    closeWindow();
                    return Clutter.EVENT_STOP;
                }
                // BUGFIX: only a left-click on a thumbnail should activate
                // that window. This used to fall through for ANY button
                // besides middle-click, including right-click (btn === 3).
                // If this preview card was still on screen (fading out
                // during its grace-period hide delay, or just wide enough
                // to visually extend over a neighboring dock icon) and the
                // user's right-click on that icon actually landed on this
                // leftover thumbnail instead, it would silently activate/
                // unminimize a completely unrelated app's window instead
                // of doing nothing (or letting the icon's own right-click
                // handler open its context menu).
                if (btn !== 1) {
                    StandaloneDock._hideThumbPreview();
                    return Clutter.EVENT_STOP;
                }
                StandaloneDock._endHoverPeek(true);
                try {
                    if (win.minimized) win.unminimize();
                    Main.activateWindow(win);
                } catch(e) {
                    try { win.unminimize(); win.activate(global.get_current_time()); } catch(e2) {}
                }
                StandaloneDock._hideThumbPreview();
                return Clutter.EVENT_STOP;
            });

            popup.add(col, { x_fill: false, y_fill: false });
            added++;
        });

        if (added === 0) {
            try { popup.destroy(); } catch(e) {}
            return;
        }

        Main.uiGroup.add_actor(popup);

        let gapX = 0, gapY = 0, gapW = 0, gapH = 0;
        try {
            let [tx, ty] = tile.get_transformed_position();
            let [minH, natH] = popup.get_preferred_height(-1);
            let [minW, natW] = popup.get_preferred_width(-1);
            let popH = natH || minH || 0;
            let popW = natW || minW || 0;
            let tileW = tile.width || 0;
            let x = Math.round(tx + (tileW / 2) - (popW / 2));
            let y = Math.round(ty - popH - 12);

            let monitor = Main.layoutManager.primaryMonitor;
            if (monitor) {
                x = Math.max(monitor.x + 8, Math.min(x, monitor.x + monitor.width - popW - 8));
            }
            popup.set_position(x, y);

            // The popup floats 12px above the tile so it reads as a
            // detached card rather than touching it - but that gap is a
            // dead zone for hit-testing: moving the pointer from the tile
            // up to the thumbnail crosses it, and if the pointer lingers
            // there even briefly with nothing reactive underneath it, nothing
            // is cancelling the scheduled hide, so the popup can vanish
            // before the click lands. Cover that dead zone with an
            // invisible reactive strip so the whole tile-to-popup path counts
            // as "still hovering".
            gapX = x; gapY = ty; gapW = popW; gapH = Math.max(0, ty - (y + popH));
        } catch(e) {
            popup.set_position(0, 0);
        }

        StandaloneDock._previewPopup = popup;

        popup.connect("enter-event", function() {
            StandaloneDock._cancelScheduledHidePreview();
            return Clutter.EVENT_PROPAGATE;
        });
        popup.connect("leave-event", function() {
            StandaloneDock._scheduleHidePreview();
            return Clutter.EVENT_PROPAGATE;
        });

        if (gapH > 0) {
            let bridge = new St.Bin({ reactive: true, opacity: 0 });
            bridge.set_position(gapX, gapY - gapH);
            bridge.set_size(gapW, gapH);
            Main.uiGroup.add_actor(bridge);
            Main.uiGroup.set_child_below_sibling(bridge, popup);
            bridge.connect("enter-event", function() {
                StandaloneDock._cancelScheduledHidePreview();
                return Clutter.EVENT_PROPAGATE;
            });
            bridge.connect("leave-event", function() {
                StandaloneDock._scheduleHidePreview();
                return Clutter.EVENT_PROPAGATE;
            });
            StandaloneDock._previewBridge = bridge;
        }

        StandaloneDock._previewCatcher = new St.Bin({
            reactive: true,
            x: 0, y: 0,
            width: global.screen_width,
            height: global.screen_height
        });
        Main.uiGroup.add_actor(StandaloneDock._previewCatcher);
        Main.uiGroup.set_child_below_sibling(StandaloneDock._previewCatcher, popup);
        StandaloneDock._previewCatcher.connect("button-press-event", function() {
            StandaloneDock._hideThumbPreview();
            // Match _menuCatcher's behavior (EVENT_STOP): a click that
            // reaches this full-screen catcher should just dismiss the
            // preview, not fall through further down the scene graph.
            return Clutter.EVENT_STOP;
        });

        StandaloneDock._startPreviewWatchdog(tile);
    },

    // ---- Pointer-position watchdog (grouped-window-list style safety net) ----
    // The show/hide of this popup is driven by enter/leave crossing events,
    // which Clutter can occasionally fail to deliver for one of the actors
    // involved when the pointer moves fast enough (events get coalesced).
    // When that happens the scheduled hide never gets queued and the popup
    // is stuck open until something else (like a click) forces it closed -
    // matching grouped-window-list's own documented "dangling menu" issue,
    // which it works around the same way: poll the real pointer position
    // and close if it's genuinely not over the tile or the popup anymore.
    _pointInActor: function(actor, x, y) {
        try {
            let [ax, ay] = actor.get_transformed_position();
            let [aw, ah] = actor.get_transformed_size();
            return x >= ax && x <= ax + aw && y >= ay && y <= ay + ah;
        } catch(e) {
            return false;
        }
    },

    _startPreviewWatchdog: function(tile) {
        StandaloneDock._stopPreviewWatchdog();
        StandaloneDock._previewWatchdogId = Mainloop.timeout_add(600, function() {
            let popup = StandaloneDock._previewPopup;
            if (!popup || !popup.get_stage()) {
                StandaloneDock._previewWatchdogId = null;
                return false;
            }
            try {
                let [px, py] = global.get_pointer();
                let overPopup = StandaloneDock._pointInActor(popup, px, py);
                let overTile = !!(tile && tile.get_stage() && StandaloneDock._pointInActor(tile, px, py));
                let overBridge = !!(StandaloneDock._previewBridge && StandaloneDock._pointInActor(StandaloneDock._previewBridge, px, py));
                if (!overPopup && !overTile && !overBridge) {
                    StandaloneDock._previewWatchdogId = null;
                    StandaloneDock._hideThumbPreview();
                    return false;
                }
            } catch(e) {}
            return true;
        });
    },

    _stopPreviewWatchdog: function() {
        if (StandaloneDock._previewWatchdogId) {
            Mainloop.source_remove(StandaloneDock._previewWatchdogId);
            StandaloneDock._previewWatchdogId = null;
        }
    },

    // ---- Chameleonic "Now Playing" preview (media docklet hover) ----
    // Same popup/catcher/positioning machinery as the window-thumbnail
    // preview above, but shows just the current track's album art + info,
    // tinted to the art's own dominant colour instead of the fixed
    // launchpad-dark/launchpad-light theme.

    _scheduleMediaPreview: function(pill) {
        StandaloneDock._cancelMediaPreview();
        StandaloneDock._mediaPreviewTimeoutId = Mainloop.timeout_add(400, function() {
            StandaloneDock._mediaPreviewTimeoutId = null;
            try { StandaloneDock._showMediaPreview(pill); } catch(e) {}
            return false;
        });
    },

    _cancelMediaPreview: function() {
        if (StandaloneDock._mediaPreviewTimeoutId) {
            Mainloop.source_remove(StandaloneDock._mediaPreviewTimeoutId);
            StandaloneDock._mediaPreviewTimeoutId = null;
        }
        StandaloneDock._hideThumbPreview();
    },

    _showMediaPreview: function(pill) {
        StandaloneDock._hideThumbPreview();
        if (!pill || !pill.get_stage()) return;

        let p = _media()._activePlayer();
        if (!p) return;

        let artPath = _media()._lastArtPath;

        // No album art to derive a chameleonic accent from - match the
        // dock's actual rendered color (same treatment as the tooltip/
        // thumbnail/coverflow pill) instead of the old fixed theme
        // background. When art IS present this stays exactly as before:
        // the fixed theme background is just a brief placeholder until
        // _applyMediaPreviewAccent() below replaces it with the chameleonic
        // color picked up from the art itself.
        let isDark = true;
        try { isDark = _launchpad().settings.themeMode !== "light"; } catch(e) {}
        if (!artPath) isDark = !StandaloneDock._isDockColorLight();
        let themeClass = isDark ? "launchpad-dark" : "launchpad-light";

        let card = new St.BoxLayout({
            vertical: true,
            style_class: "brahim-media-preview " + themeClass,
            reactive: true
        });
        if (!artPath) {
            try {
                let tinted = StandaloneDock._getDockColorWithAlpha();
                if (tinted) card.set_style("background-color: " + tinted + " !important;");
            } catch(e) {}
        }

        // Widescreen (16:9) art crop, sized like the existing
        // window-thumbnail previews (the ones shown hovering a Chrome/
        // Firefox tile) rather than the small app-icon tile size.
        let artW = 220, artH = Math.round(artW * 9 / 16);
        let artBin = new St.Bin({
            style_class: "brahim-media-preview-art",
            style: "width: " + artW + "px; height: " + artH + "px;"
        });
        if (artPath) {
            artBin.style += " background-image: url(\"file://" + artPath + "\"); background-size: cover;";
        } else {
            artBin.set_child(new St.Icon({
                icon_name: "audio-x-generic-symbolic",
                icon_size: Math.round(Math.min(artW, artH) * 0.55),
                style_class: "brahim-media-art-placeholder-icon"
            }));
        }
        card.add(artBin, { x_fill: false, x_align: St.Align.MIDDLE });

        let textMaxWidth = Math.max(artW, 110);

        let titleLabel = new St.Label({
            text: p.songTitle || p.identity || "",
            style_class: "brahim-media-preview-title " + themeClass
        });
        titleLabel.clutter_text.set_line_wrap(false);
        titleLabel.clutter_text.set_ellipsize(imports.gi.Pango.EllipsizeMode.END);
        titleLabel.set_style("max-width: " + textMaxWidth + "px; background-color: transparent !important;");
        card.add(titleLabel, { x_fill: false, x_align: St.Align.MIDDLE });

        if (p.songArtist) {
            let artistLabel = new St.Label({
                text: p.songArtist,
                style_class: "brahim-media-preview-artist " + themeClass
            });
            artistLabel.clutter_text.set_line_wrap(false);
            artistLabel.clutter_text.set_ellipsize(imports.gi.Pango.EllipsizeMode.END);
            artistLabel.set_style("max-width: " + textMaxWidth + "px; background-color: transparent !important;");
            card.add(artistLabel, { x_fill: false, x_align: St.Align.MIDDLE });
        }

        Main.uiGroup.add_actor(card);

        try {
            let [tx, ty] = pill.get_transformed_position();
            let [minH, natH] = card.get_preferred_height(-1);
            let [minW, natW] = card.get_preferred_width(-1);
            let cardH = natH || minH || 0;
            let cardW = natW || minW || 0;
            let pillW = pill.width || 0;
            let x = Math.round(tx + (pillW / 2) - (cardW / 2));
            let y = Math.round(ty - cardH - 12);

            let monitor = Main.layoutManager.primaryMonitor;
            if (monitor) {
                x = Math.max(monitor.x + 8, Math.min(x, monitor.x + monitor.width - cardW - 8));
            }
            card.set_position(x, y);
        } catch(e) {
            card.set_position(0, 0);
        }

        StandaloneDock._previewPopup = card;

        StandaloneDock._previewCatcher = new St.Bin({
            reactive: true,
            x: 0, y: 0,
            width: global.screen_width,
            height: global.screen_height
        });
        Main.uiGroup.add_actor(StandaloneDock._previewCatcher);
        Main.uiGroup.set_child_below_sibling(StandaloneDock._previewCatcher, card);
        StandaloneDock._previewCatcher.connect("button-press-event", function() {
            StandaloneDock._hideThumbPreview();
            // Match _menuCatcher's behavior (EVENT_STOP): a click that
            // reaches this full-screen catcher should just dismiss the
            // preview, not fall through further down the scene graph.
            return Clutter.EVENT_STOP;
        });

        // Chameleonic tint: colour the card to match the album art's own
        // dominant colour once it resolves, instead of leaving it on the
        // fixed dark/light theme background applied above. If there's no
        // art (or extraction fails) the card just stays on that fallback.
        if (artPath) {
            _media().DockAlbumArt.getDominantColor(artPath, (rgb) => {
                // The user may have moved on to a different track (or
                // closed the preview) while this was resolving.
                if (StandaloneDock._previewPopup !== card || !card.get_stage()) return;
                if (!rgb) return;
                StandaloneDock._applyMediaPreviewAccent(card, rgb);
            });
        }
    },

    _applyMediaPreviewAccent: function(card, rgb) {
        let r = rgb.r, g = rgb.g, b = rgb.b;
        card.style =
            "background-color: rgba(" + r + ", " + g + ", " + b + ", 0.38); " +
            "border: 1px solid rgba(" + r + ", " + g + ", " + b + ", 0.5); " +
            "box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.18), " +
                "0 16px 40px rgba(" + r + ", " + g + ", " + b + ", 0.45);";
    },

    _hideContextMenu: function() {
        if (StandaloneDock._menu) {
            try { StandaloneDock._menu.destroy(); } catch(e) {}
            StandaloneDock._menu = null;
        }
        if (StandaloneDock._menuCatcher) {
            try { Main.uiGroup.remove_actor(StandaloneDock._menuCatcher); } catch(e) {}
            try { StandaloneDock._menuCatcher.destroy(); } catch(e) {}
            StandaloneDock._menuCatcher = null;
        }
    },

    _showContextMenu: function(app, x, y) {
        StandaloneDock._hideContextMenu();
        StandaloneDock._cancelThumbPreview();

        let isDark = true;
        try { isDark = _launchpad().settings.themeMode !== "light"; } catch(e) {}

        let menu = new St.BoxLayout({
            vertical: true,
            style_class: "launchpad-context-menu " + (isDark ? "launchpad-dark" : "launchpad-light"),
            reactive: true
        });

        function addItem(text, callback) {
            let item = new St.Label({
                text: text,
                style_class: "launchpad-context-item",
                reactive: true,
                track_hover: true
            });
            item.connect("button-release-event", function() {
                StandaloneDock._hideContextMenu();
                callback();
                return Clutter.EVENT_STOP;
            });
            menu.add(item, { x_fill: true });
        }

        let windows = [];
        try { windows = app.get_windows() || []; } catch(e) {}

        addItem(windows.length > 0 ? Utils._("New Window") : Utils._("Open"), function() {
            try { app.open_new_window(-1); } catch(e) { try { app.activate(); } catch(e2) {} }
        });

        addItem(StandaloneDock._isPinned(app) ? Utils._("Remove from Dock") : Utils._("Pin to Dock"), function() {
            StandaloneDock._togglePin(app);
        });

        if (windows.length > 0) {
            addItem(Utils._("Quit"), function() {
                windows.forEach(function(w) {
                    try { w.delete(global.get_current_time()); } catch(e) {}
                });
            });
        }

        Main.uiGroup.add_actor(menu);

        try {
            let [minH, natH] = menu.get_preferred_height(-1);
            menu.set_position(Math.round(x), Math.round(y) - (natH || minH || 0) - 8);
        } catch(e) {
            menu.set_position(Math.round(x), Math.round(y));
        }

        StandaloneDock._menu = menu;

        StandaloneDock._menuCatcher = new St.Bin({
            reactive: true,
            x: 0, y: 0,
            width: global.screen_width,
            height: global.screen_height
        });
        Main.uiGroup.add_actor(StandaloneDock._menuCatcher);
        Main.uiGroup.set_child_below_sibling(StandaloneDock._menuCatcher, menu);
        StandaloneDock._menuCatcher.connect("button-press-event", function() {
            StandaloneDock._hideContextMenu();
            return Clutter.EVENT_STOP;
        });
    },

    // ---- On‑Screen Keyboard docklet ----

    // Helper to get dock color with alpha
    _getDockColorWithAlpha: function() {
        let s = SettingsStore.getDockSettings();
        let transparency = (s.transparency !== undefined ? s.transparency : 30) / 100.0;
        let dockColor = s.dockColor || "rgba(245, 255, 255, 1.0)";
        return Utils.colorWithAlpha(dockColor, transparency);
    },

    // Whether the dock's OWN color (not the separate dark/light theme-mode
    // toggle) reads as visually light, using the standard perceptual
    // luminance formula. Used to pick white-on-dark vs black-on-light text
    // for anything whose background now mirrors the dock's real color
    // (tooltip, window-thumbnail preview, coverflow title pill) - since
    // that background can be any color the user picked, not just "dark" or
    // "light" mode.
    _isDockColorLight: function() {
        try {
            let s = SettingsStore.getDockSettings();
            let dockColor = s.dockColor || "rgba(245, 255, 255, 1.0)";
            let rgba = StandaloneDock._parseRGBA(dockColor);
            if (!rgba) return false;
            let luminance = (0.299 * rgba[0] + 0.587 * rgba[1] + 0.114 * rgba[2]) / 255;
            return luminance > 0.55;
        } catch(e) {
            return false;
        }
    },

    // Pulls the r,g,b,a numbers back out of an "rgba(r, g, b, a)" string
    // (e.g. one produced by _getDockColorWithAlpha) for use with Cairo's
    // setSourceRGBA, which needs the components separately rather than as
    // a CSS color string.
    _parseRGBA: function(colorStr) {
        let match = /rgba?\(\s*([\d.]+)[,\s]+([\d.]+)[,\s]+([\d.]+)(?:[,\s]+([\d.]+))?\s*\)/.exec(colorStr || "");
        if (!match) return null;
        return [parseFloat(match[1]), parseFloat(match[2]), parseFloat(match[3]), match[4] !== undefined ? parseFloat(match[4]) : 1];
    },

    // Helper to get dock geometry
    _getDockGeometry: function() {
        if (!StandaloneDock.widget) return null;
        let monitor = Main.layoutManager.primaryMonitor;
        if (!monitor) return null;
        let [x, y] = StandaloneDock.widget.get_transformed_position();
        let w = StandaloneDock.widget.width;
        let h = StandaloneDock.widget.height;
        return { x, y, width: w, height: h, screenWidth: monitor.width, screenHeight: monitor.height };
    },

    // Apply styling to the on‑screen keyboard: position, width, background
    _applyKeyboardStyling: function() {
        let a11ySettings = new Gio.Settings({ schema_id: 'org.cinnamon.desktop.a11y.applications' });
        if (!a11ySettings.get_boolean("screen-keyboard-enabled")) {
            a11ySettings.run_dispose();
            return;
        }

        // 1. Set position to bottom using GSettings (if the key exists)
        try {
            a11ySettings.set_string("screen-keyboard-position", "bottom");
        } catch(e) {
            // The key may not exist on all Cinnamon versions; ignore
        }

        // 2. Resize and reposition the keyboard to match the dock
        let geom = StandaloneDock._getDockGeometry();
        if (geom && geom.width > 0) {
            // Try multiple window classes and names
            let classes = ["caribou", "onboard", "cinnamon-keyboard", "keyboard"];
            let found = false;
            let retries = 5;
            let attempt = 0;

            let tryFindAndResize = function() {
                if (found || attempt >= retries) return;
                attempt++;
                for (let i = 0; i < classes.length; i++) {
                    let cmd = 'xdotool search --class "' + classes[i] + '" 2>/dev/null | head -1';
                    let [ok, out] = GLib.spawn_command_line_sync(cmd);
                    if (ok && out) {
                        let winId = imports.byteArray.toString(out).trim();
                        if (winId) {
                            found = true;
                            // Resize to dock width, keep height as is (0 means don't change)
                            let resizeCmd = 'xdotool windowsize ' + winId + ' ' + geom.width + ' 0';
                            GLib.spawn_command_line_async(resizeCmd);
                            // Move to just above the dock (assume keyboard height ~150)
                            let keyboardHeight = 150;
                            let moveY = geom.y - keyboardHeight;
                            if (moveY < 0) moveY = 0;
                            let moveCmd = 'xdotool windowmove ' + winId + ' ' + geom.x + ' ' + moveY;
                            GLib.spawn_command_line_async(moveCmd);
                            return;
                        }
                    }
                }
                // If not found, retry after 300ms
                if (!found && attempt < retries) {
                    Mainloop.timeout_add(300, tryFindAndResize);
                }
            };
            tryFindAndResize();
        }

        // 3. Apply CSS to the keyboard (if it's a GTK window)
        let color = StandaloneDock._getDockColorWithAlpha();
        // Target all possible keyboard style classes
        let css = ".caribou, .onboard, .keyboard, .cinnamon-keyboard, .osk { background-color: " + color + "; }";
        try {
            let provider = new Gtk.CssProvider();
            provider.load_from_data(css);
            Gtk.StyleContext.add_provider_for_screen(Gdk.Screen.get_default(), provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION);
        } catch(e) {}

        a11ySettings.run_dispose();
    },

    // Create the keyboard tile itself
    _createKeyboardTile: function() {
        let iconSize = StandaloneDock._renderIconSize || StandaloneDock._iconSize;
        let tile = new St.BoxLayout({
            vertical: true,
            reactive: true,
            track_hover: true,
            style_class: "brahim-dock-tile"
        });

        // GSettings for the a11y keyboard
        let a11ySettings = new Gio.Settings({ schema_id: 'org.cinnamon.desktop.a11y.applications' });
        let isEnabled = a11ySettings.get_boolean("screen-keyboard-enabled");

        // Prefers a bundled keyboard.svg (dropped into the extension
        // directory, same pattern as radio.js's bundled radio.png and
        // the trash tile's bundled trash.png) over the icon theme's
        // on-screen-keyboard glyphs. The bundled PNG doesn't have a
        // separate "disabled" variant, so enabled/disabled state is
        // shown via opacity instead of swapping icon names; falls back
        // to the theme's on-screen-keyboard/on-screen-keyboard-disabled
        // icon-name swap when no bundled PNG is present.
        if (!StandaloneDock._keyboardBundledIconChecked) {
            let pngPath = Shared.EXTENSION_DIR + "/keyboard.svg";
            StandaloneDock._keyboardUseBundledIcon = GLib.file_test(pngPath, GLib.FileTest.EXISTS);
            StandaloneDock._keyboardBundledIconChecked = true;
        }

        let icon;
        if (StandaloneDock._keyboardUseBundledIcon) {
            let pngPath = Shared.EXTENSION_DIR + "/keyboard.svg";
            try {
                icon = new St.Icon({
                    gicon: Gio.icon_new_for_string(pngPath),
                    icon_size: iconSize,
                    opacity: isEnabled ? 255 : 140
                });
            } catch(e) {
                StandaloneDock._keyboardUseBundledIcon = false;
            }
        }
        if (!icon) {
            icon = new St.Icon({
                icon_name: isEnabled ? 'on-screen-keyboard' : 'on-screen-keyboard-disabled',
                icon_size: iconSize,
                style_class: "brahim-dock-keyboard-icon"
            });
        }

        let iconBin = new St.Bin({ x_align: St.Align.MIDDLE });
        iconBin.set_child(icon);
        tile.add(iconBin, { x_fill: false, x_align: St.Align.MIDDLE, y_fill: false, y_align: St.Align.MIDDLE, expand: true });

        tile.add(new St.Bin({ style_class: "brahim-dock-dot brahim-dock-dot-hidden" }), { x_fill: false, x_align: St.Align.MIDDLE, y_fill: false, y_align: St.Align.END });

        StandaloneDock._wireHoverEffects(tile, iconBin, null, Utils._("On‑Screen Keyboard"));

        // Update icon when setting changes
        let updateIcon = function() {
            let enabled = a11ySettings.get_boolean("screen-keyboard-enabled");
            if (StandaloneDock._keyboardUseBundledIcon) {
                icon.opacity = enabled ? 255 : 140;
            } else {
                icon.icon_name = enabled ? 'on-screen-keyboard' : 'on-screen-keyboard-disabled';
            }
        };
        let signalId = a11ySettings.connect('changed::screen-keyboard-enabled', updateIcon);

        // Cleanup when tile is destroyed
        tile.connect('destroy', function() {
            try { a11ySettings.disconnect(signalId); } catch(e) {}
            try { a11ySettings.run_dispose(); } catch(e) {}
        });

        tile.connect("button-press-event", function(actor, event) {
            StandaloneDock._exitShowDesktopIfNeeded();
            let hadOverlay = !!StandaloneDock._menu || !!StandaloneDock._previewPopup;
            StandaloneDock._hideContextMenu();
            StandaloneDock._cancelThumbPreview();
            if (hadOverlay) return Clutter.EVENT_STOP;

            let button = event.get_button();
            if (button === 3) {
                // Right‑click: open settings (optional)
                StandaloneDock._openDockSettings();
                return Clutter.EVENT_STOP;
            }

            // Toggle the keyboard
            let current = a11ySettings.get_boolean("screen-keyboard-enabled");
            a11ySettings.set_boolean("screen-keyboard-enabled", !current);
            // Also manually toggle the virtual keyboard manager (as in the applet)
            try { Main.virtualKeyboardManager.manualToggle(); } catch(e) {}

            // Apply styling after a short delay to let the keyboard appear
            Mainloop.timeout_add(200, function() {
                StandaloneDock._applyKeyboardStyling();
                return false;
            });

            return Clutter.EVENT_STOP;
        });

        // Apply styling immediately if keyboard is enabled
        if (isEnabled) {
            Mainloop.idle_add(function() {
                StandaloneDock._applyKeyboardStyling();
                return false;
            });
        }

        return tile;
    }
};
