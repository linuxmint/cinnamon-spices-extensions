// weather.js
// -*- mode: js; js-indent-level: 4; indent-tabs-mode: nil -*-
//
// Weather docklet for dock@brahim's dock tray. Shows a live temperature
// reading and a condition glyph for the city typed into Settings (see
// "weather-city" in settings-schema.json / getWeatherSettings() in
// settingsStore.js), pulled from Open-Meteo (open-meteo.com) - free, no
// API key. Two calls: geocoding (city name -> lat/lon), then forecast
// (lat/lon -> current temperature_2m + weather_code + is_day). Both go
// through `curl` via GLib.spawn_command_line_sync() (bounded by curl's
// own -m timeout) - see _fetchAsync()'s comment for why this isn't the
// async Gio.Subprocess path the file originally used.
//
// An earlier version of this file was deliberately network-free (a
// fixed glyph, city name only in the tooltip) - see summary.md. This
// replaces that with the live fetch the tile always needed; clicking
// the tile still opens Settings (where the city can be changed) and now
// also forces an immediate refresh rather than waiting for the 15-
// minute timer.
//
// Loaded via Shared.requireSibling('weather') from extension.js and
// dock.js's _weather() lazy accessor, same pattern as
// mediaDocklet.js/radio.js.

const St = imports.gi.St;
const Clutter = imports.gi.Clutter;
const GLib = imports.gi.GLib;

const Shared = imports.shared;
// Safe as top-level imports here: by the time extension.js's
// _loadSiblingModules() reaches `imports.weather.WeatherDocklet` (which
// is what first evaluates this file), settingsStore.js/utils.js have
// already been loaded and searchPath is still swapped to the extension
// dir - same reasoning osd.js/radio.js already rely on for their own
// top-level SettingsStore/Utils imports.
const SettingsStore = imports.settingsStore;
const Utils = imports.utils;

function _dock() {
    return Shared.requireSibling('dock').StandaloneDock;
}

const DEFAULT_CITY = "Chorbane";
const REFRESH_INTERVAL_SEC = 900; // 15 minutes
const FETCH_TIMEOUT_SEC = 10;
const GEOCODE_URL = "https://geocoding-api.open-meteo.com/v1/search?count=1&language=en&format=json&name=";
const FORECAST_URL = "https://api.open-meteo.com/v1/forecast?current=temperature_2m,weather_code,is_day&timezone=auto&latitude=%LAT%&longitude=%LON%";

// WMO weather_code -> { icon, text }
// Uses the same icon naming convention as Almanac's weatherProvider.js.
// (An intermediate version of this file swapped these for hand-drawn,
// per-condition colorful Cairo glyphs from radioIcons.js - reverted back
// to plain symbolic icons on request; see .brahim-weather-icon in
// stylesheet.css for the white recolor, which is the part that was
// actually wanted out of that detour.)
function _codeInfo(code, isDay) {
    // Map weather codes to icon names and descriptions
    // Using the same symbolic icon names as Almanac
    const table = {
        0:  { icon: "weather-clear-symbolic", text: "Clear" },
        1:  { icon: "weather-few-clouds-symbolic", text: "Mostly Clear" },
        2:  { icon: "weather-few-clouds-symbolic", text: "Partly Cloudy" },
        3:  { icon: "weather-overcast-symbolic", text: "Overcast" },
        45: { icon: "weather-fog-symbolic", text: "Fog" },
        48: { icon: "weather-fog-symbolic", text: "Fog" },
        51: { icon: "weather-showers-scattered-symbolic", text: "Light Drizzle" },
        53: { icon: "weather-showers-scattered-symbolic", text: "Drizzle" },
        55: { icon: "weather-showers-symbolic", text: "Dense Drizzle" },
        56: { icon: "weather-showers-scattered-symbolic", text: "Freezing Drizzle" },
        57: { icon: "weather-showers-symbolic", text: "Freezing Drizzle" },
        61: { icon: "weather-showers-scattered-symbolic", text: "Light Rain" },
        63: { icon: "weather-showers-symbolic", text: "Rain" },
        65: { icon: "weather-showers-symbolic", text: "Heavy Rain" },
        66: { icon: "weather-showers-symbolic", text: "Freezing Rain" },
        67: { icon: "weather-showers-symbolic", text: "Freezing Rain" },
        71: { icon: "weather-snow-symbolic", text: "Light Snow" },
        73: { icon: "weather-snow-symbolic", text: "Snow" },
        75: { icon: "weather-snow-symbolic", text: "Heavy Snow" },
        77: { icon: "weather-snow-symbolic", text: "Snow Grains" },
        80: { icon: "weather-showers-symbolic", text: "Rain Showers" },
        81: { icon: "weather-showers-symbolic", text: "Rain Showers" },
        82: { icon: "weather-showers-symbolic", text: "Violent Showers" },
        85: { icon: "weather-snow-symbolic", text: "Snow Showers" },
        86: { icon: "weather-snow-symbolic", text: "Snow Showers" },
        95: { icon: "weather-storm-symbolic", text: "Thunderstorm" },
        96: { icon: "weather-storm-symbolic", text: "Thunderstorm w/ Hail" },
        99: { icon: "weather-storm-symbolic", text: "Thunderstorm w/ Hail" }
    };

    let entry = table[code] || { icon: "weather-severe-alert-symbolic", text: "Unknown" };

    // For night time, use night variants when available
    if (isDay === 0) {
        if (code === 0 || code === 1) {
            entry.icon = "weather-clear-night-symbolic";
        } else if (code === 2) {
            entry.icon = "weather-few-clouds-night-symbolic";
        }
    }

    return entry;
}

var WeatherDocklet = {
    widget: null,
    _icon: null,
    _label: null,

    _gen: 0,              // bumped on enable()/disable()/refresh() so any
                           // in-flight fetch's async callback becomes a
                           // no-op once it's stale.
    _timerId: null,
    _hasCurl: null,

    _city: null,           // the city string _lat/_lon were geocoded for
    _lat: null,
    _lon: null,
    _temp: null,           // last known-good rounded °C, or null if none yet
    _condText: null,       // last known-good condition text
    _iconName: "weather-clear-symbolic", // last known-good icon name
    _error: false,         // true if the most recent fetch attempt failed

    enable: function() {
        WeatherDocklet.widget = null;
        WeatherDocklet._icon = null;
        WeatherDocklet._label = null;
        WeatherDocklet._gen++;
        WeatherDocklet._city = null;
        WeatherDocklet._lat = null;
        WeatherDocklet._lon = null;
        WeatherDocklet._temp = null;
        WeatherDocklet._condText = null;
        WeatherDocklet._iconName = "weather-clear-symbolic";
        WeatherDocklet._error = false;

        WeatherDocklet._fetchNow();
        WeatherDocklet._timerId = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, REFRESH_INTERVAL_SEC, function() {
            WeatherDocklet._fetchNow();
            return GLib.SOURCE_CONTINUE;
        });
    },

    disable: function() {
        WeatherDocklet._gen++; // invalidate any in-flight fetch's callback
        if (WeatherDocklet._timerId) {
            GLib.source_remove(WeatherDocklet._timerId);
            WeatherDocklet._timerId = null;
        }
        if (WeatherDocklet.widget) {
            try { WeatherDocklet.widget.destroy(); } catch(e) {}
        }
        WeatherDocklet.widget = null;
        WeatherDocklet._icon = null;
        WeatherDocklet._label = null;
    },

    getCity: function() {
        try {
            let s = SettingsStore.getWeatherSettings();
            return (s.city && s.city.trim()) ? s.city.trim() : DEFAULT_CITY;
        } catch(e) {
            return DEFAULT_CITY;
        }
    },

    _curlAvailable: function() {
        if (WeatherDocklet._hasCurl === null) {
            try {
                let [ok, out] = GLib.spawn_command_line_sync("which curl");
                WeatherDocklet._hasCurl = !!(ok && out && imports.byteArray.toString(out).trim());
            } catch(e) {
                WeatherDocklet._hasCurl = false;
            }
        }
        return WeatherDocklet._hasCurl;
    },

    // Confirmed via logging that Gio.Subprocess's async communicate
    // path (both the two-step new()+init() form and the Gio.Subprocess.new()
    // static-factory form) never invokes its callback in this environment -
    // not even once curl's own `-m` timeout should have elapsed, and not
    // even a synchronous construction exception. _curlAvailable()'s
    // GLib.spawn_command_line_sync("which curl") call, by contrast,
    // reliably completes (hasCurl=true in every log) - that's the same
    // synchronous spawn pattern utils.js/volume.js already use for their
    // own shell calls in this extension, so this uses it here too rather
    // than the broken async path. Trade-off: this blocks the shell for up
    // to FETCH_TIMEOUT_SEC while curl runs, instead of being non-blocking -
    // worse than the original design intent, but a bounded block beats an
    // unbounded hang that never resolves at all.
    _fetchAsync: function(url, cb) {
        if (!WeatherDocklet._curlAvailable()) { cb(null); return; }
        try {
            let cmd = "curl -s -m " + FETCH_TIMEOUT_SEC + " -- " + GLib.shell_quote(url);
            let [ok, out] = GLib.spawn_command_line_sync(cmd);
            let text = (ok && out) ? imports.byteArray.toString(out).trim() : null;
            cb(text || null);
        } catch(e) {
            global.log("brahim-weather-debug: _fetchAsync threw: " + e);
            cb(null);
        }
    },

    // Kicks off geocoding (only if the configured city changed since we
    // last resolved coordinates, or we never have) then the forecast
    // fetch. Every callback checks `myGen` against the live `_gen`
    // before touching shared state, so a stale in-flight request from a
    // previous enable()/city change can never clobber a newer one.
    _fetchNow: function() {
        let myGen = WeatherDocklet._gen;
        let city = WeatherDocklet.getCity();
        global.log("brahim-weather-debug: _fetchNow city=" + city + " gen=" + myGen + " hasCurl=" + WeatherDocklet._curlAvailable());

        if (WeatherDocklet._lat !== null && WeatherDocklet._city === city) {
            WeatherDocklet._fetchForecast(myGen);
            return;
        }

        let queryCity = (city.split(",")[0] || city).trim() || city;
        let url = GEOCODE_URL + encodeURIComponent(queryCity);
        global.log("brahim-weather-debug: geocoding queryCity=\"" + queryCity + "\" (from full city=\"" + city + "\")");
        WeatherDocklet._fetchAsync(url, function(text) {
            global.log("brahim-weather-debug: geocode raw=" + (text === null ? "null" : text.slice(0, 200)));
            if (myGen !== WeatherDocklet._gen) return; // stale, ignore

            let lat = null, lon = null;
            try {
                let data = JSON.parse(text);
                if (data && data.results && data.results.length) {
                    lat = data.results[0].latitude;
                    lon = data.results[0].longitude;
                }
            } catch(e) {
                global.log("brahim-weather-debug: geocode JSON.parse threw: " + e);
            }
            global.log("brahim-weather-debug: geocode parsed lat=" + lat + " lon=" + lon);

            if (lat === null || lon === null) {
                WeatherDocklet._error = true;
                WeatherDocklet._repaintAll();
                return;
            }

            WeatherDocklet._city = city;
            WeatherDocklet._lat = lat;
            WeatherDocklet._lon = lon;
            WeatherDocklet._fetchForecast(myGen);
        });
    },

    _fetchForecast: function(myGen) {
        let url = FORECAST_URL
            .replace("%LAT%", encodeURIComponent(WeatherDocklet._lat))
            .replace("%LON%", encodeURIComponent(WeatherDocklet._lon));

        WeatherDocklet._fetchAsync(url, function(text) {
            if (myGen !== WeatherDocklet._gen) return; // stale, ignore

            try {
                let data = JSON.parse(text);
                let cur = data && data.current;
                if (!cur || cur.temperature_2m === undefined || cur.temperature_2m === null) {
                    throw new Error("no current block");
                }
                let info = _codeInfo(cur.weather_code, cur.is_day);
                WeatherDocklet._temp = Math.round(cur.temperature_2m);
                WeatherDocklet._iconName = info.icon;
                WeatherDocklet._condText = info.text;
                WeatherDocklet._error = false;
            } catch(e) {
                WeatherDocklet._error = true;
            }

            WeatherDocklet._repaintAll();
        });
    },

    // Re-paints the icon and re-renders the label on the existing tile
    // (if built) without a full rebuild - called whenever new data (or a
    // fresh error) comes back.
    _repaintAll: function() {
        // Update the icon
        if (WeatherDocklet._icon) {
            WeatherDocklet._icon.set_icon_name(WeatherDocklet._iconName);
            WeatherDocklet._icon.queue_repaint();
        }
        
        // Update the label
        let hasLabel = !!WeatherDocklet._label;
        let onStage = hasLabel && !!WeatherDocklet._label.get_stage();
        let text = WeatherDocklet._tempLabelText();
        global.log("brahim-weather-debug: _repaintAll hasLabel=" + hasLabel + " onStage=" + onStage + " text=" + text);
        if (WeatherDocklet._label) WeatherDocklet._label.set_text(text);
    },

    _tempLabelText: function() {
        if (WeatherDocklet._temp === null) return WeatherDocklet._error ? "--" : "\u2026";
        return WeatherDocklet._temp + "\u00b0";
    },

    _tooltipText: function() {
        let city = WeatherDocklet.getCity();
        if (WeatherDocklet._temp === null) {
            return WeatherDocklet._error
                ? Utils._("Weather") + " \u2014 " + city + " (" + Utils._("unavailable") + ")"
                : Utils._("Weather") + " \u2014 " + city + " (" + Utils._("loading") + "\u2026)";
        }
        return Utils._("Weather") + " \u2014 " + city + ", " + WeatherDocklet._temp + "\u00b0C, " + WeatherDocklet._condText;
    },

    // Unlike a truly persistent widget (mediaDocklet.js's, which holds a
    // live DBus subscription and is explicitly detached from the box
    // before dock.js's destroy_all_children() sweep so it survives), this
    // tile is cheap to rebuild - so, like radio.js's getTile(), it always
    // builds a fresh one rather than caching by icon size. Caching here
    // used to hand back an already-destroyed actor: dock.js's
    // _populateTiles() calls box.destroy_all_children() on every single
    // refresh (icon-size fit passes, app open/close, settings changes,
    // ...), which destroys the previously-added tile - but a "same icon
    // size, reuse the cached widget" check doesn't know that and returns
    // the now-dead actor anyway. That dead actor still occupies layout
    // space and still fires hover events (empty box that reacts to
    // hover but never paints) - which is exactly the symptom this was
    // causing.
    getTile: function() {
        let iconSize = _dock()._renderIconSize || _dock()._iconSize || 44;

        let tile = new St.BoxLayout({
            vertical: true,
            reactive: true,
            track_hover: true,
            style_class: "brahim-dock-tile"
        });

        // Use a nice size for the icon - same as Almanac's approach
        // Using St.Icon directly for proper rendering. Recolored to white
        // via .brahim-weather-icon in stylesheet.css - symbolic icons
        // otherwise inherit the icon theme's default (often black)
        // foreground, which read as flat and hard to see on the dock.
        let icon = new St.Icon({
            icon_name: WeatherDocklet._iconName,
            icon_type: St.IconType.SYMBOLIC,
            icon_size: Math.max(20, iconSize - 4),
            style_class: "brahim-weather-icon"
        });
        WeatherDocklet._icon = icon;

        let iconBin = new St.Bin({ x_align: St.Align.MIDDLE });
        iconBin.set_child(icon);
        tile.add(iconBin, { x_fill: false, x_align: St.Align.MIDDLE, y_fill: false, y_align: St.Align.MIDDLE, expand: true });

        let fontSize = Math.max(10, Math.min(16, Math.round(iconSize / 3.8)));
        let initialText = WeatherDocklet._tempLabelText();
        let label = new St.Label({
            text: initialText,
            style_class: "brahim-weather-temp",
            style: "font-size: " + fontSize + "px; font-weight: 600;"
        });
        WeatherDocklet._label = label;
        tile.add(label, { x_fill: false, x_align: St.Align.MIDDLE, y_fill: false, y_align: St.Align.END });
        global.log("brahim-weather-debug: getTile iconSize=" + iconSize + " icon.icon_size=" + icon.icon_size + " fontSize=" + fontSize + " initialText=" + initialText);

        // Tooltip text is a function (re-read on every hover, same trick
        // radio.js uses for its station name) so a new city typed into
        // Settings, or a background refresh landing while the pointer
        // is elsewhere, takes effect the next time the pointer enters -
        // no tile rebuild needed.
        _dock()._wireHoverEffects(tile, iconBin, null, function() {
            return WeatherDocklet._tooltipText();
        });

        tile.connect("button-press-event", function(actor, event) {
            _dock()._exitShowDesktopIfNeeded();
            let hadOverlay = !!_dock()._menu || !!_dock()._previewPopup;
            _dock()._hideContextMenu();
            _dock()._cancelThumbPreview();
            if (hadOverlay) return Clutter.EVENT_STOP;

            // Force an immediate refresh in addition to opening Settings
            // (where the city can be changed) - useful right after
            // typing a new city, instead of waiting for the 15-minute
            // background timer.
            WeatherDocklet._fetchNow();
            Utils.openDockSettingsDialog();
            return Clutter.EVENT_STOP;
        });

        WeatherDocklet.widget = tile;
        return tile;
    },

    // Called by extension.js whenever a WEATHER_SETTINGS_KEYMAP key
    // ("weather-city") changes - forces an immediate re-geocode/refetch
    // instead of waiting up to 15 minutes for the background timer, and
    // repaints the icon/label as soon as the new data lands.
    refresh: function() {
        WeatherDocklet._gen++;
        WeatherDocklet._city = null; // force re-geocode even if lat/lon are still set
        WeatherDocklet._fetchNow();
    }
};
