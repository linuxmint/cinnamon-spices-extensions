// effects.js
// -*- mode: js; js-indent-level: 4; indent-tabs-mode: nil -*-
//
// Desktop-wide visual effects for dock@brahim, layered above every
// window via Main.uiGroup (same layer StandaloneDock/Launchpad already
// use). Currently just the colorful floating bubbles effect ported from
// rainy@brahim's BubbleEffect - kept as its own module (rather than
// folded into dock.js) since it's desktop-wide chrome, not dock chrome,
// and off by default so nobody gets bubbles they didn't ask for.
//
// Loaded via Shared.requireSibling('effects') from extension.js, same
// pattern as dock.js/launchpad.js/mediaDocklet.js/radio.js.

const Main  = imports.ui.main;
const St    = imports.gi.St;
const GLib  = imports.gi.GLib;
const Cairo = imports.cairo;

const Shared = imports.shared;
// Safe as a top-level import here: by the time extension.js's
// _loadSiblingModules() reaches `imports.effects.Effects` (which is what
// first evaluates this file), settingsStore.js has already been loaded
// and searchPath is still swapped to the extension dir - same reasoning
// osd.js/radio.js already rely on for their own top-level SettingsStore
// import.
const SettingsStore = imports.settingsStore;

function _random(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}
function _randomFloat(min, max) {
    return Math.random() * (max - min) + min;
}

const MACOS_PALETTE = [
    { r: 1.00, g: 0.27, b: 0.23 },
    { r: 1.00, g: 0.58, b: 0.00 },
    { r: 1.00, g: 0.80, b: 0.00 },
    { r: 0.20, g: 0.78, b: 0.35 },
    { r: 0.00, g: 0.75, b: 0.90 },
    { r: 0.00, g: 0.48, b: 1.00 },
    { r: 0.34, g: 0.34, b: 0.84 },
    { r: 0.69, g: 0.32, b: 0.87 },
    { r: 1.00, g: 0.18, b: 0.58 },
    { r: 0.64, g: 0.52, b: 0.37 },
];

// ---- BubbleEffect: spawns/animates/tears-down the floating bubbles.
// Ported as-is from rainy@brahim's applet.js (colorful-bubbles mode
// only - the rain/snow/matrix/fire/wet-desktop modes from that extension
// are out of scope here).
function BubbleEffect() {
    this._bubbles = [];
    this._isRunning = false;
    this._colorful = true;
    this._opacity = 0.75;
    this._density = 1.0;
}

BubbleEffect.prototype = {
    start: function(density, colorful, opacity) {
        if (this._isRunning) return;
        this._isRunning = true;
        this._density = density || 1.0;
        this._colorful = (colorful !== undefined) ? colorful : true;
        this._opacity = (opacity !== undefined) ? opacity : 0.75;
        this._scheduleSpawn();
        this._startAnimation();
    },

    stop: function() {
        this._isRunning = false;
        for (let b of this._bubbles) {
            if (b.canvas && b.canvas.get_parent()) Main.uiGroup.remove_child(b.canvas);
            if (b.canvas) b.canvas.destroy();
        }
        this._bubbles = [];
    },

    setColorful: function(colorful) { this._colorful = colorful; },
    setOpacity: function(opacity) { this._opacity = opacity; },
    setDensity: function(density) { this._density = density; },

    _scheduleSpawn: function() {
        if (!this._isRunning) return;
        GLib.timeout_add(GLib.PRIORITY_DEFAULT, _random(300, 800), () => {
            if (this._isRunning) {
                this._spawnBubbles();
                this._scheduleSpawn();
            }
            return GLib.SOURCE_REMOVE;
        });
    },

    _spawnBubbles: function() {
        let monitor = Main.layoutManager.primaryMonitor;
        if (!monitor) return;
        let count = Math.floor(2 * this._density);
        for (let i = 0; i < count; i++) {
            let x = _random(20, monitor.width - 20);
            let y = monitor.height + _random(10, 60);
            let size = _random(15, 45);
            let vx = _randomFloat(-0.5, 0.5);
            let vy = -_randomFloat(1.0, 2.2);
            let color = this._colorful ? MACOS_PALETTE[_random(0, MACOS_PALETTE.length - 1)] : null;
            this._createBubble(x, y, vx, vy, size, color);
        }
    },

    _createBubble: function(x, y, vx, vy, size, color) {
        let canvas = new St.DrawingArea({ reactive: false });
        canvas.set_size(size * 2, size * 2);
        Main.uiGroup.add_child(canvas);
        canvas.set_position(Math.round(x - size), Math.round(y - size));
        let bubble = { canvas, x, y, vx, vy, size, color };
        this._bubbles.push(bubble);

        canvas.connect('repaint', () => {
            let cr = canvas.get_context();
            let [w, h] = canvas.get_surface_size();
            cr.save();
            cr.setOperator(Cairo.Operator.CLEAR);
            cr.paint();
            cr.restore();
            let alpha = this._opacity;
            if (color) {
                cr.setSourceRGBA(color.r, color.g, color.b, alpha * 0.3);
                cr.arc(w / 2, h / 2, size, 0, 2 * Math.PI);
                cr.fill();
                cr.setSourceRGBA(color.r, color.g, color.b, alpha * 0.6);
                cr.arc(w / 2, h / 2, size * 0.7, 0, 2 * Math.PI);
                cr.fill();
            } else {
                cr.setSourceRGBA(0.7, 0.85, 1.0, alpha * 0.3);
                cr.arc(w / 2, h / 2, size, 0, 2 * Math.PI);
                cr.fill();
                cr.setSourceRGBA(0.5, 0.7, 0.95, alpha * 0.5);
                cr.arc(w / 2, h / 2, size * 0.7, 0, 2 * Math.PI);
                cr.fill();
            }
            cr.setSourceRGBA(1.0, 1.0, 1.0, alpha * 0.5);
            cr.ellipse(w / 2 - size * 0.2, h / 2 - size * 0.2, size * 0.2, size * 0.15);
            cr.fill();
            cr.$dispose();
        });
        canvas.queue_repaint();

        GLib.timeout_add(GLib.PRIORITY_DEFAULT, _random(8000, 12000), () => {
            let idx = this._bubbles.indexOf(bubble);
            if (idx > -1) this._bubbles.splice(idx, 1);
            if (canvas && canvas.get_parent()) Main.uiGroup.remove_child(canvas);
            canvas.destroy();
            return GLib.SOURCE_REMOVE;
        });
    },

    _startAnimation: function() {
        let animate = () => {
            if (!this._isRunning) return;
            let monitor = Main.layoutManager.primaryMonitor;
            for (let b of this._bubbles) {
                if (b.canvas && b.canvas.get_parent()) {
                    b.x += b.vx;
                    b.y += b.vy;
                    b.vx *= 0.99;
                    b.vy *= 0.99;
                    if (b.y + b.size < -100 || b.y - b.size > (monitor ? monitor.height + 200 : 1000)) {
                        let idx = this._bubbles.indexOf(b);
                        if (idx > -1) this._bubbles.splice(idx, 1);
                        if (b.canvas && b.canvas.get_parent()) Main.uiGroup.remove_child(b.canvas);
                        if (b.canvas) b.canvas.destroy();
                        continue;
                    }
                    b.canvas.set_position(Math.round(b.x - b.size), Math.round(b.y - b.size));
                }
            }
            GLib.timeout_add(GLib.PRIORITY_DEFAULT, 33, animate);
        };
        animate();
    }
};

// ---- Effects: the module singleton extension.js enables/disables and
// re-applies on settings changes, same shape as StandaloneDock/Launchpad/
// CinemixRadio/MediaControlsDocklet.
var Effects = {
    _bubbleEffect: null,

    enable: function() {
        Effects._bubbleEffect = new BubbleEffect();
        Effects.applySettings();
    },

    disable: function() {
        if (Effects._bubbleEffect) {
            Effects._bubbleEffect.stop();
            Effects._bubbleEffect = null;
        }
    },

    // Starts/stops/retunes the bubble effect based on the current
    // "effects-bubbles-enabled" (off by default) setting - called both
    // right after enable() and whenever that setting changes.
    applySettings: function() {
        if (!Effects._bubbleEffect) return;
        let settings;
        try {
            settings = SettingsStore.getEffectsSettings();
        } catch (e) {
            settings = { bubblesEnabled: false, bubblesIntensity: 1.0 };
        }
        let intensity = (settings.bubblesIntensity !== undefined) ? settings.bubblesIntensity : 1.0;

        if (settings.bubblesEnabled) {
            if (!Effects._bubbleEffect._isRunning) {
                Effects._bubbleEffect.start(intensity, true, 0.75);
            } else {
                Effects._bubbleEffect.setDensity(intensity);
            }
        } else if (Effects._bubbleEffect._isRunning) {
            Effects._bubbleEffect.stop();
        }
    }
};
